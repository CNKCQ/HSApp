/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./55/Tool/ActionManager.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./55/Tool/ActionManager.js":
/*!**********************************!*\
  !*** ./55/Tool/ActionManager.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nvar _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();\n\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n\nvar ActionManager = function () {\n    function ActionManager() {\n        _classCallCheck(this, ActionManager);\n\n        this.KACTION_URL_PREFIX = \"txvideo://v.qq.com/\"; //action 的固定前缀\n        this.ACTION_VIDEO_LIST = \"ONAOperationModelActivity\"; //个人页跳转到视频列表页面\n    }\n\n    // 公开外界访问接口\n    // 跳转native页面\n\n\n    _createClass(ActionManager, [{\n        key: \"justDoAction\",\n        value: function justDoAction(action) {\n            // 跳转native页面\n            console.log(\"ActionManager------doAction\");\n            QLVN.doAction(action);\n        }\n    }, {\n        key: \"doActionWithVn\",\n        value: function doActionWithVn(action) {\n            // 预处理跳转地址，如果是跳转vn的页面，在这里进行调整，其他页面由native来进行跳转\n            console.log(\"ActionManager------doActionWithVn\");\n            if (!this.jumpToVN(action)) {\n                this.justDoAction(action);\n            } else {\n                var reportObj = { \"eventId\": \"video_jce_action_click\", \"mta_prop\": { \"reportKey\": \"\" + action.reportKey, \"reportParams\": \"\" + action.reportParams } };\n                ktRemoteSdk.report(JSON.stringify(reportObj));\n                console.log(\"-------doActionWithVn Reportt--\" + JSON.stringify(reportObj));\n            }\n        }\n    }, {\n        key: \"jumpToVN\",\n        value: function jumpToVN(action) {\n            //是否跳转VN页面\n            console.log(\"ActionManager------jumpToVN\");\n            if (action == null) {\n                return false;\n            }\n            var actionName = this.getActionName(action.url);\n            console.log(\"ActionManager------jumpToVN------actionName:\" + actionName);\n            if (actionName == null) {\n                return false;\n            }\n\n            if (actionName == this.ACTION_VIDEO_LIST) {\n                this.goVrssHomeActivity(action.url);\n                return true;\n            }\n            return false;\n        }\n    }, {\n        key: \"getActionName\",\n        value: function getActionName(actionUrl) {\n            //获取actionName\n            if (actionUrl == null || actionUrl.length == 0) {\n                return null;\n            }\n            var startIndex = actionUrl.indexOf(this.KACTION_URL_PREFIX);\n            if (startIndex == -1) {\n                return null;\n            }\n            var endIndex = actionUrl.indexOf(\"?\");\n\n            if (endIndex == -1) {\n                return actionUrl.substring(startIndex + this.KACTION_URL_PREFIX.length);\n            } else {\n                if (endIndex < startIndex) {\n                    return null;\n                }\n                return actionUrl.substring(startIndex + this.KACTION_URL_PREFIX.length, endIndex);\n            }\n        }\n    }, {\n        key: \"getActionParams\",\n        value: function getActionParams(actionUrl) {\n            if (actionUrl == null || actionUrl.length == 0) {\n                return null;\n            }\n            var startIndex = actionUrl.indexOf(\"?\");\n            if (startIndex == -1) {\n                return null;\n            }\n            return this.getKVFromStr(actionUrl.substring(startIndex + 1));\n        }\n    }, {\n        key: \"getKVFromStr\",\n        value: function getKVFromStr(paramsString) {\n            console.log(\"ActionManager------getKVFromStr:\" + paramsString);\n            if (paramsString == null || paramsString.length == 0) {\n                return null;\n            }\n            var paramsObj = {};\n            var keyValueSplit = paramsString.split(\"&\");\n            for (var i = 0; i < keyValueSplit.length; i++) {\n                var kvString = keyValueSplit[i];\n                var keyValue = kvString.split(\"=\");\n                if (keyValue.length == 2) {\n                    var key = keyValue[0];\n                    var value = keyValue[1];\n                    if (key != null && key.length > 0 && value != null && value.length > 0) {\n                        console.log(\"ActionManager------getKVFromStr-----key:\" + key);\n                        console.log(\"ActionManager------getKVFromStr-----value:\" + value);\n                        paramsObj[key] = value;\n                    }\n                }\n            }\n            return paramsObj;\n        }\n    }, {\n        key: \"goVrssHomeActivity\",\n        value: function goVrssHomeActivity(url) {\n            var parms = this.getActionParams(url);\n            console.log(\"ActionManager------goVrssHomeActivity------action.url:\" + url);\n            if (parms != null) {\n                parms.isVideoListPage = true;\n            }\n            //跳转个人页视频列表\n            vn.navigate.navigateTo({\n                \"pageUrl\": \"vn://videoList/index\",\n                \"params\": parms\n            });\n        }\n    }]);\n\n    return ActionManager;\n}();\n\nexports.default = ActionManager;\n\n//# sourceURL=webpack:///./55/Tool/ActionManager.js?");

/***/ })

/******/ });