/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./55/Tool/ReportTool.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./55/Tool/ReportTool.js":
/*!*******************************!*\
  !*** ./55/Tool/ReportTool.js ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\n\nvar _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();\n\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n\nvar ReportTool = function () {\n    function ReportTool() {\n        _classCallCheck(this, ReportTool);\n\n        this.lastAllReportEvents = [];\n        this.lastShortListReportEvents = [];\n        this.enterTime = 0;\n        this.lastEnterTime = 0;\n    }\n\n    //----------- 接口公开外界访问 begin----------------\n    //页面开始可见\n\n\n    _createClass(ReportTool, [{\n        key: \"onPageShow\",\n        value: function onPageShow() {\n            this.enterTime = Date.parse(new Date());\n            console.log(\"-------ReportTool.onPageShow-------\");\n        }\n        //页面隐藏 \n        //停留时长上报\n\n    }, {\n        key: \"onPageHide\",\n        value: function onPageHide(callBack) {\n            console.log(\"-------ReportTool.onPageHide--begin  \");\n            var currentTime = Date.parse(new Date());\n            if (this.enterTime > 0 && this.enterTime != this.lastEnterTime) {\n                var duration = currentTime - this.enterTime;\n                //reportObj.mta_prop.stay_duration = duration;\n                //ktRemoteSdk.report(JSON.stringify(reportObj));\n                this.lastEnterTime = this.enterTime;\n                callBack(duration);\n                console.log(\"-------ReportTool.onPageHide-- duration\" + duration);\n            }\n            console.log(\"-------ReportTool.onPageHide--end\");\n        }\n\n        //上报 reportObj = {\"eventId\": \"eventId\", \"mta_prop\":{\"type\":\"1\"}}\n\n    }, {\n        key: \"reportEvent\",\n        value: function reportEvent(reportObj) {\n            var reportStr = JSON.stringify(reportObj);\n            ktRemoteSdk.report(reportStr);\n            console.log(\"-------ReportTool.reportEvent--\" + reportStr);\n        }\n\n        // 竖直滑动的时候，对整个页面的可见node 进行上报\n\n    }, {\n        key: \"reportAllNodeExposure\",\n        value: function reportAllNodeExposure() {\n            console.log(\"-------ReportTool.reportAllNodeExposure--begin\");\n            try {\n                var updatedReportEvents = this.baseNodeExposureReport('list_view', this.lastAllReportEvents);\n                this.lastAllReportEvents = updatedReportEvents;\n                console.log(\"-------ReportTool.reportAllNodeExposure--end\");\n            } catch (error) {\n                console.log(\"ReportTool.reportAllNodeExposure error:\" + error);\n            }\n        }\n\n        // 横向滑动的时候，对短视频进行上报\n\n    }, {\n        key: \"reportShortListExposure\",\n        value: function reportShortListExposure() {\n            // 获取 myHistoryList 及其递归可视子节点的所有上报信息\n            // 横向滑动的时候不做diff 所以传入一个空的[]\n            var updatedReportEvents = this.baseNodeExposureReport('short_vide_list', this.lastShortListReportEvents);\n            this.lastShortListReportEvents = updatedReportEvents;\n        }\n\n        // 页面不见的时候调用\n\n    }, {\n        key: \"clearLastReportInfo\",\n        value: function clearLastReportInfo() {\n            this.lastAllReportEvents = [];\n            this.lastShortListReportEvents = [];\n        }\n\n        //----------- 接口公开外界访问 end----------------\n\n    }, {\n        key: \"map\",\n        value: function map(ele) {\n            return ele.reportKey + ele.reportParams;\n        }\n    }, {\n        key: \"getDiff\",\n        value: function getDiff(oldArray, newArray) {\n\n            console.log(\"ReportTool.getDiff: oldArray=\" + JSON.stringify(oldArray));\n            console.log(\"ReportTool.getDiff: newArray=\" + JSON.stringify(newArray));\n            var oldStringArray = oldArray.map(this.map);\n            var newStringArray = newArray.map(this.map);\n\n            var resultIndexs = [];\n            var diff = newStringArray.filter(function (val, index) {\n                if (oldStringArray.indexOf(val) < 0) {\n                    resultIndexs.push(index);\n                    return false;\n                }\n                return true;\n            });\n\n            var results = [];\n            resultIndexs.forEach(function (val) {\n                results.push(newArray[val]);\n            });\n            return results;\n        }\n\n        // 上报的统一回调\n\n    }, {\n        key: \"reportEvents\",\n        value: function reportEvents(events) {\n            console.log(\"QLVN.reportEvents  begin   events: \" + JSON.stringify(events));\n            if (events.length) {\n                var eventID = events.reportEventId ? events.reportEventId : 'video_jce_poster_exposure';\n                // 有数据才调用native 的数据上报\n                if (QLVN != null && QLVN.reportEvents != null) {\n                    QLVN.reportEvents(eventID, events);\n                    console.log(\"-------ReportTool.reportEvents--  eventID= \" + eventID + \"  events:\" + JSON.stringify(events));\n                }\n            }\n        }\n\n        // 获取一个node 包含其子节点，子节点的子节点.... 的所有上报信息\n\n    }, {\n        key: \"getAllReportInfo\",\n        value: function getAllReportInfo(nodeId) {\n            console.log(\"ReportTool.getAllReportInfo  --begin--\");\n            var node = vn.dom.getElementById(nodeId);\n            if (!node) {\n                console.log(\"ReportTool.getAllReportInfo  \" + nodeId + \" ==null\");\n                return [];\n            }\n            var tempLastReportEvents = [];\n            this.traversalNode(node, function (reportKey, reportParams, reportEventId) {\n                tempLastReportEvents.push({\n                    reportKey: reportKey,\n                    reportParams: reportParams,\n                    reportEventId: reportEventId\n                });\n            });\n            console.log(\"ReportTool.getAllReportInfo  --end--\");\n            return tempLastReportEvents;\n        }\n    }, {\n        key: \"baseNodeExposureReport\",\n        value: function baseNodeExposureReport(nodeId, specificOriginEvents) {\n            // 获取 nodeId 对应的node 的递归可视子节点的所有上报信息\n            var tempLastReportEvents = this.getAllReportInfo(nodeId);\n\n            // 对数据做一个diff\n            var diff = this.getDiff(specificOriginEvents, tempLastReportEvents);\n            // 对diff上报\n            this.reportEvents(diff);\n            // 函数不对传入的变量做改变 ，所以返回\n            return tempLastReportEvents;\n        }\n\n        // 递归遍历子节点 获取遍历的数据\n\n    }, {\n        key: \"traversalNode\",\n        value: function traversalNode(node, callBack) {\n            if (!node) {\n                return;\n            }\n            var childNodes = node.getVisibleChildElements();\n            for (var index in childNodes) {\n                // 获取上报信息\n                if (!childNodes[index]) {\n                    continue;\n                }\n\n                if (!(typeof childNodes[index].getDataSet == 'function')) {\n                    continue;\n                }\n\n                console.log('ReportTool childNodes[' + index + '] = ' + childNodes[index]);\n                var childDataSet = childNodes[index].getDataSet();\n                console.log('ReportTool childDataSet =' + JSON.stringify(childDataSet));\n                var reportInfo = childDataSet.report;\n                if (reportInfo) {\n                    console.log('ReportTool reportInfo  reportKey= ' + reportInfo.reportKey + \"  reportParams=\" + reportInfo.reportParams);\n                    callBack(reportInfo.reportKey, reportInfo.reportParams, reportInfo.reportEventId);\n                } else {\n                    var reportKey = childDataSet.reportkey;\n                    var reportParams = childDataSet.reportparams;\n                    var reportEventId = 'video_jce_poster_exposure';\n                    if (reportKey || reportParams) {\n                        console.log('ReportTool reportInfo  by reportKey');\n                        callBack(reportKey, reportParams, reportEventId);\n                    }\n                }\n                // 是否遍历子节点\n                var traversalChild = childDataSet.reportchild && childDataSet.reportchild == 'true';\n                console.log('ReportTool traversalChild=' + traversalChild);\n                if (traversalChild) {\n                    this.traversalNode(childNodes[index], callBack);\n                }\n            }\n        }\n    }]);\n\n    return ReportTool;\n}();\n\nexports.default = ReportTool;\n\n\nArray.prototype.indexOf = function (searchElement, fromIndex) {\n    if (searchElement != null) {\n        var fromi = fromIndex != null ? fromIndex : 0;\n        for (var i = fromi; i < this.length; ++i) {\n            if (this[i] == searchElement) {\n                return i;\n            }\n        }\n    }\n    return -1;\n};\n\n//# sourceURL=webpack:///./55/Tool/ReportTool.js?");

/***/ })

/******/ });