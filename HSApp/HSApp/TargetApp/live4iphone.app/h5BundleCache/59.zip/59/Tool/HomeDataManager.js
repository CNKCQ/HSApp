/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./source/Tool/HomeDataManager.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./source/Tool/HomeDataManager.js":
/*!****************************************!*\
  !*** ./source/Tool/HomeDataManager.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("Object.defineProperty(exports,\"__esModule\",{value:true});var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if(\"value\"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();// import \"babel-polyfill\"\n__webpack_require__(/*! ../polyfill/polyfill */ \"./source/polyfill/polyfill.js\");var _ReportTool=__webpack_require__(/*! ../Tool/ReportTool.js */ \"./source/Tool/ReportTool.js\");var _ReportTool2=_interopRequireDefault(_ReportTool);function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError(\"Cannot call a class as a function\");}}var reportTool=new _ReportTool2.default();var HomeDataManager=function(){function HomeDataManager(){_classCallCheck(this,HomeDataManager);}_createClass(HomeDataManager,[{key:'fetchHomeData',value:function fetchHomeData(urlPreFix,location,_success,failure){var _this=this;vn.request.request({url:urlPreFix+location,dataType:\"json\",success:function success(data){if(_success){_success(_this.makeHomeUIData(urlPreFix,data));console.log(\"首页数据请求success\");}},fail:function fail(reason){if(failure){failure({});}},complete:function complete(){console.log(\"首页数据请求完毕\");}});}},{key:'makeHomeUIData',value:function makeHomeUIData(urlPreFix,data){if(!data)return;var _data=Object.assign({},data);var pagerData=[];var listData=[];var bannerTitles=[];var hasNextPage=data['has_next_page'];var nextPageLocation=data['next_list'];// 从data 的module_list里面取数据\nvar moduleList=_data['module_list'];if(!moduleList)return listData;console.log('开始解析module_list数据');for(var index=0;index<moduleList.length;index++){var moduleItem=moduleList[index];var moduleType=moduleItem['module_type'];if(!moduleType)continue;// 取 'item_view_list'\nvar moduleItemViewList=moduleItem['item_view_list'];if(!moduleItemViewList)continue;// viewPager数据\nif(moduleType==1){pagerData=this.parseItemViewList(moduleItemViewList,urlPreFix,'image');pagerData.forEach(function(item){var title=item['title'];if(title){bannerTitles.push(title);}var reportKey=\"vn_focus_poster\";var reportParams=reportTool.getParamsInfo(reportKey,item);QLVN.reportEvents(\"vn_video_jce_poster_exposure\",[{reportKey:reportKey,reportParams:reportParams}]);});}else if(moduleType==2){// 单独的板块 电影，综艺等\n// 制作标题\nvar titleData=Object.assign({},moduleItem['title_action']);titleData['cellType']='title';listData.push(titleData);var reportKey=\"vn_home_title\";var reportParams=reportTool.getParamsInfo(reportKey,titleData);QLVN.reportEvents(\"vn_video_jce_poster_exposure\",[{reportKey:reportKey,reportParams:reportParams}]);// 开始制作doubleImage 组\nvar sectionData=this.parseItemViewList(moduleItemViewList,urlPreFix);var itemCount=sectionData.length;if(itemCount%2){itemCount-=1;}var step=0;for(var i=0;i<itemCount/2;i++){var movies=[];var cellType='doubleImage';var leftItem=sectionData[i+step];var rightItem=sectionData[i+step+1];step+=1;movies.push(leftItem);movies.push(rightItem);listData.push({cellType:cellType,movies:movies});var _reportKey=\"vn_home_poster\";var _reportParams=reportTool.getParamsInfo(_reportKey,leftItem);QLVN.reportEvents(\"vn_video_jce_poster_exposure\",[{reportKey:_reportKey,reportParams:_reportParams}]);_reportParams=reportTool.getParamsInfo(_reportKey,rightItem);;QLVN.reportEvents(\"vn_video_jce_poster_exposure\",[{reportKey:_reportKey,reportParams:_reportParams}]);if(i+step!=itemCount-1){listData.push({cellType:\"seperator\"});}}// 最后一个section 多加一个\nif(index==moduleList.length-1){listData.push({cellType:\"seperator\"});}}}// 头部加入一个 'viewPager' 的数据\nlistData=[{\"cellType\":\"viewPager\",\"movies\":pagerData}].concat(listData);return{bannerTitles:bannerTitles,listData:listData,hasNextPage:hasNextPage,nextPageLocation:nextPageLocation};}},{key:'parseItemViewList',value:function parseItemViewList(itemViewList,urlPreFix,cellType){var results=[];itemViewList.forEach(function(item){var posterList=item['poster_list'];posterList.forEach(function(item,index){var newPoster=Object.assign({},item);newPoster['action_cover']=urlPreFix+newPoster['action_cover'];newPoster['poster_pic_hz_url']=urlPreFix+newPoster['poster_pic_hz_url'];newPoster['poster_pic_vt_url']=urlPreFix+newPoster['poster_pic_vt_url'];newPoster['imageURL']=newPoster['poster_pic_hz_url'];if(cellType){newPoster['cellType']=cellType;}results.push(newPoster);});});return results;}}]);return HomeDataManager;}();exports.default=HomeDataManager;\n\n//# sourceURL=webpack:///./source/Tool/HomeDataManager.js?");

/***/ }),

/***/ "./source/Tool/ReportTool.js":
/*!***********************************!*\
  !*** ./source/Tool/ReportTool.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("Object.defineProperty(exports,\"__esModule\",{value:true});var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if(\"value\"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();// import \"babel-polyfill\"\n__webpack_require__(/*! ../polyfill/polyfill */ \"./source/polyfill/polyfill.js\");function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError(\"Cannot call a class as a function\");}}var ReportTool=function(){function ReportTool(){_classCallCheck(this,ReportTool);}_createClass(ReportTool,[{key:'sayHello',value:function sayHello(){console.log('hello');}},{key:'getParamsInfo',value:function getParamsInfo(key,clickItem){if(clickItem){var values=new Array();// console.log(\"key =\"+key + \"   \"+JSON.stringify(clickItem));\nif(key==\"vn_home_title\"){// console.log(JSON.stringify(clickItem));\nvalues.push(\"title=\"+(\"title\"in clickItem?clickItem['title']:\"\"));values.push(\"list_url=\"+(\"gt_list_url\"in clickItem?clickItem['gt_list_url']:\"\"));}else{values.push(\"title=\"+(\"title\"in clickItem?clickItem['title']:\"\"));values.push(\"cid=\"+(\"cid\"in clickItem?clickItem['cid']:\"\"));values.push(\"play_url=\"+(\"gt_play_url\"in clickItem?clickItem['gt_play_url']:\"\"));}return values.join(\"&\");}else{return\"\";}}}]);return ReportTool;}();exports.default=ReportTool;\n\n//# sourceURL=webpack:///./source/Tool/ReportTool.js?");

/***/ }),

/***/ "./source/polyfill/polyfill.js":
/*!*************************************!*\
  !*** ./source/polyfill/polyfill.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("console.log(\"PolyFill js \");if(!Object.assign){console.log(\"PolyFill Object assign \");Object.defineProperty(Object,'assign',{enumerable:false,configurable:true,writable:true,value:function value(target){'use strict';if(target===undefined||target===null){throw new TypeError('Cannot convert first argument to object');}var to=Object(target);for(var i=1;i<arguments.length;i++){var nextSource=arguments[i];if(nextSource===undefined||nextSource===null){continue;}nextSource=Object(nextSource);var keysArray=Object.keys(Object(nextSource));for(var nextIndex=0,len=keysArray.length;nextIndex<len;nextIndex++){var nextKey=keysArray[nextIndex];var desc=Object.getOwnPropertyDescriptor(nextSource,nextKey);if(desc!==undefined&&desc.enumerable){to[nextKey]=nextSource[nextKey];}}}return to;}});}if(!Array.prototype.indexOf){console.log(\"PolyFill Array.prototype.indexOf \");Array.prototype.indexOf=function(searchElement,fromindex){if(searchElement!=null){var fromi=fromIndex!=null?fromIndex:0;for(var i=fromi;i<this.length;++i){if(this[i]==searchElement){return i;}}}return-1;};}\n\n//# sourceURL=webpack:///./source/polyfill/polyfill.js?");

/***/ })

/******/ });