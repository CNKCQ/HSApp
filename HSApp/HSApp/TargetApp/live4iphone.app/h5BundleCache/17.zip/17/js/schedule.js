/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	var loadingPop = __webpack_require__(38);
	var errorPop = __webpack_require__(24);
	var lruStorage = __webpack_require__(13)('h5piao', {limit: 20, maxAge: 10 * 60 * 1000});
	
	var ngModule = angular.module('mobileTicket', []);//一个页面相当于一个angular module
	
	__webpack_require__(39)(ngModule);//修复jsonp
	__webpack_require__(40)(ngModule);//getUrlParam
	__webpack_require__(42)(ngModule, 'app_v_schedule');
	
	ngModule
		//定义filter, filter相当于art模板的helper
		.filter("scheduleDate", function() {
			var DAY = ['日', '一', '二', '三', '四', '五', '六'];
			return function(d) {
				d = d.split('-');
				d = new Date(d[0], d[1] - 1, d[2]);
				var dtime = Date.now() - d,
					str = [d.getMonth() + 1, d.getDate()].join('.');
				if (Math.abs(dtime) < 86400000) {
					if (dtime > 0) {
						str = '今天' + str;
					} else {
						str = '明天' + str;
					}
				} else if (dtime < 0 && dtime > -172800000) {
					str = '后天' + str;
				} else {
					str = '周' + DAY[d.getDay()] + str;
				}
				return str;
			};
		})
		.filter('filmName', ['$getUrlParam', function($getUrlParam) {
			return function(schedule, v) {
	
				/**
				 * 为了不影响之前的schedule，这里把schedule复制一份，并且去掉了不需要的channel字段
				 **/
				var obj = JSON.parse(JSON.stringify(schedule));
				delete obj.channel;			
				obj.fid = $getUrlParam('film_id');
				obj.tid = $getUrlParam('theater_id');
	
				if(v && v.discount) {
					obj.discount_price = v.discount.d_price;
					obj.discount_id = v.discount.d_id;
				}
	
				if(v) {
					obj.c_id = v.c_id;
					obj.c_nm = v.c_nm;
					obj.c_roomid = v.c_roomid;
					obj.c_cinema_id = v.c_cinema_id;
					obj.c_showid = v.c_showid;
					obj.price = v.price;
					obj.stop_time = v.stop_time;
				}
				
				return obj;
			};
		}])
		.filter('encodeURIComponent', function() {
			return encodeURIComponent;
		})
		.filter('formatPrice', function(){
			return function(price) {
				price = Math.abs(price/100);
				return price.toFixed(2);
			};
		})
		.filter('getMinPrice', function() {
			return function(item) {
				var price = item.price;
				var channel = item.channel;
				for(var k in channel) {
					if(channel.hasOwnProperty(k)) {
						var c = channel[k];
						if(c.discount) {
							price = Math.min(c.discount.d_price, price);
						}
					}
				}
				return price;
			}
		})
		//定义控制器，依赖于$scope(双向绑定), $http(相当于$.ajax), $getUrlParam(刚刚使用seajs引入的), $q(promise) 几个服务
		.controller('schedule', ['$scope', '$http', '$getUrlParam', '$q', function($scope, $http, $getUrlParam, $q) {
			$scope.schedule = {};
			$scope.currentDayList = [];
			$scope.currentDay = null;
			$scope.selectedIndex = -1;
	
			$scope.$switchDay = function(day) {//切换日期的点击事件
				$scope.currentDayList = $scope.schedule[day];
				$scope.currentDay = day;
				document.querySelector('#list').scrollTop = 0;
			};
	
			$scope.$href = function(event, item) {
				if (!item.close_buy) {
					event.preventDefault();
					location.href =angular.element(event.currentTarget).find('a')[0].href;
				}
			};
	
			$scope.$toggleFold = function(event, index){
				if($scope.selectedIndex === index) {
					$scope.selectedIndex = -1;
				} else {
					$scope.selectedIndex = index;
				}
				
			};
	
			var fid = $getUrlParam('film_id');
			var tid = $getUrlParam('theater_id');
			var cacheData = lruStorage.get('theater_schedule?fid=' + fid + '&tid=' + tid);
			if (cacheData) {
				_success(cacheData, false);
				_finally();
			}
	
			$http
				.jsonp('https://ticketapi.video.qq.com/wireless_theater_schedule?callback=JSON_CALLBACK', {
					params: {
						otype: 'json',
						film_id: fid,
						theater_id: tid
					}
				})
				.success(function(data) {
					lruStorage.set('theater_schedule?fid=' + fid + '&tid=' + tid, data);
				})
				.success(_success)
				.error(_error)
				.finally(_finally);
	
			function _success(data) {
				if (data.retcode == '0' && data.schedule) {
					$scope.schedule = data.schedule;
	
					for (var i in data.schedule) {
						var target =  data.schedule[i];
	
						for(var j = 0, len = target.length; j < len; j++) {
							if( target[j].channel ) {
								target[j].channel = _simpleMapToArray(target[j].channel);
							}
						}
	
						$scope.currentDayList = target;
						
						$scope.currentDay = i;
						break;
					}
				} else {
					$scope.currentDayList = null;
					return $q.reject();
				}
			}
			function _error() {
				if (!cacheData) {
					errorPop('获取排期失败了', '刷新重试', null, $q.defer()).then(function() {
						location.reload();
					});
				}
			}
			function _finally() {
				loadingPop.loaded();
			}
	
			function _simpleMapToArray(obj) {
				var arr = null;
				for(var k in obj) {
					if(obj.hasOwnProperty(k)) {
						if(!arr) arr = [];
						arr.push(obj[k]);
					}
				}
				return arr;
			}
		}]);
	
	//由于用了seajs的关系，所以要等dom ready再启动angular
	angular.element(document).ready(function() {
		//在document节点启动mobileTicket模块
		angular.bootstrap(document, ['mobileTicket']);
	
		//去你大爷的300ms延迟
		__webpack_require__(19).attach(document.body);
	});
	QQVideoBridge.setMoreInfo({"hasRefresh":true, "hasShare":false, "hasFollow":false});


/***/ }),

/***/ 2:
/***/ (function(module, exports) {

	// http://tapd.oa.com/tvideo/prong/stories/view/1010031991056992805?url_cache_key=dc4c5bdd3ef3797a13e788c323168a6f&action_entry_type=story_tree_list
	var sessionStorage = window.sessionStorage || {
			getItem: function () {
			}, setItem: function () {
			}, removeItem: function () {
			}
		};
	var base_url = "https://btrace.qq.com/kvcollect?BossId=3243&Pwd=1546101498&plat=1&ua=" + navigator.userAgent + "&_dc=" + Math.random();
	var ref;
	
	
	//播放页来源
	if (location.href.indexOf('app.package.play') != -1) {
		sessionStorage.setItem('piao-ref', ref = 11);
	} else if (location.href.indexOf('app.package.user') != -1 || location.href.indexOf('app.package.channel') != -1) {
		sessionStorage.setItem('piao-ref', ref = 12);
	} else {
		ref = sessionStorage.getItem('piao-ref') || 12;
	}
	base_url += '&ref=' + ref;
	
	var exp = function (event, cid) {
		var g_btrace_BOSS = new Image(1, 1);
		g_btrace_BOSS.src = base_url + '&event=' + event + (cid ? ('&cid=' + cid) : '');
	};
	exp.delegate = function (event) {
		var $ = window.jQuery || window.Zepto;
		exp(event);//pv
		$(document.body).on('click', '[_boss]', function (e) {
			exp($(e.currentTarget).attr('_boss'));
		});
	};
	module.exports = exp;

/***/ }),

/***/ 13:
/***/ (function(module, exports) {

	/**
	 * exports: function(key, options)
	 * @param prefix       define a prefix of the keys in localStorage
	 * @param options
	 *      maxAge
	 *      limit           item limited in localStorage, defaults to 0(so all item will be saved in sessionStorage)
	 *      useSession      when an item is staled, detemine whether drop it or move it to sessionStorage, defaults to true
	 *      -
	 */
	
	(function(LruStorageFactory, CacheItemFactory, LRUArrayFactory) {
	  // if (window.define && define.cmd) {
	  //   define(function(r, e, module) {
	  //     module.exports =
	  //   });
	  // } else {
	  //   window.LruWebStorage = LruStorageFactory(CacheItemFactory(),
	  //     LRUArrayFactory());
	  // }
	  module.exports = LruStorageFactory(CacheItemFactory(), LRUArrayFactory());
	})(function(CacheItem, LRUArray) {
	  var STORAGE = {
	    local: window.localStorage,
	    session: window.sessionStorage
	  };
	
	  function LruStorage(prefix, options) {
	    this.prefix = prefix;
	    LruStorage.ATTRIBUTES.forEach(function(key) {
	      this[key] = options[key];
	    }, this);
	    this.onStale = options.onStale;
	
	    //keys
	    this.items = LRUArray('storageKey');
	    if (options._items) {
	      options._items.forEach(function(v) {
	        this.items.unshift(new CacheItem(v));
	      }, this);
	    }
	  }
	  LruStorage.ATTRIBUTES = ['maxAge', 'limit', 'useSession'];
	
	  LruStorage.prototype.set = function set(key, val, opt) {
	    var item;
	    //if there is no cacheItem storaged, create one
	    if (!(item = this.items.find(key))) {
	      item = new CacheItem({
	        key: key,
	        maxAge: Date.now() + this.maxAge
	      });
	      this.add(item);
	    }
	    //save value
	    STORAGE[item.level].setItem(this.prefix + '-' + item.storageKey, JSON.stringify(
	      val));
	    this.saveConfig();
	    return this;
	  };
	
	  LruStorage.prototype.get = function get(key, opt) {
	    var item;
	    //check if there is a cacheItem storaged yet
	    if (!(item = this.items.find(key))) return ({}).undefined;
	    if (item.isStale()) {
	      this.remove(this.items.indexOf(key));
	      return null;
	    }
	
	    return JSON.parse(STORAGE[item.level].getItem(this.prefix + '-' + item.storageKey));
	  };
	
	  LruStorage.prototype.remove = function(index) {
	    var item = this.items.arr[index];
	
	    if (typeof this.onStale == 'function') {
	      if (this.onStale(JSON.parse(STORAGE[item.level].getItem(this.prefix +
	          '-' + item.storageKey)), this.useSession)) return;
	    }
	    // console.log(this.useSession, index);
	    if (this.useSession) {
	      if (item.level == 'local') {
	        item.level = 'session';
	        STORAGE.local.removeItem(this.prefix + '-' + item.storageKey);
	        STORAGE.session.setItem(this.prefix + '-' + item.storageKey,
	          STORAGE.local.getItem(this.prefix + '-' + item.storageKey));
	      }
	
	    } else {
	      STORAGE[item.level].removeItem(this.prefix + '-' + item.storageKey);
	      if (index == this.items.length - 1) {
	        this.items.pop();
	      } else {
	        this.items.splice(index, 1);
	      }
	    }
	    return this;
	  };
	
	  LruStorage.prototype.add = function(item) {
	    //remove the last one when items out of limit
	    if (this.items.length >= this.limit && this.items.length > 0) {
	      // console.log(this.items.length, this.limit);
	      for (var i = Math.max(0, this.limit - 1); i < this.items.length; i++) {
	        this.remove(i);
	      }
	    }
	    this.items.unshift(item);
	    return this;
	  };
	
	  LruStorage.prototype.saveConfig = function saveConfig() {
	    var json = {
	      _items: []
	    };
	    //stringify all items and config
	    this.items.forEach(function(v) {
	      var citem = {};
	      CacheItem.ATTRIBUTES.forEach(function(key) {
	        citem[key] = v[key];
	      });
	      json._items.push(citem);
	    }, this);
	    LruStorage.ATTRIBUTES.forEach(function(attr) {
	      json[attr] = this[attr];
	    }, this);
	    STORAGE.local.setItem(this.prefix + '-lruconfig', JSON.stringify(json));
	  };
	
	  return function(prefix, options) {
	    var oldConfig = STORAGE.local.getItem(prefix + '-lruconfig') ? JSON.parse(
	      STORAGE.local.getItem(prefix + '-lruconfig')) : {};
	    options = options || {};
	
	    oldConfig.maxAge = options.maxAge || oldConfig.maxAge || Infinity;
	    oldConfig.limit = options.limit || oldConfig.limit || 0;
	    oldConfig.useSession = ('useSession' in options) ? options.useSession :
	      (('useSession' in oldConfig) ? oldConfig.useSession : true);
	    oldConfig.onStale = options.onStale || null;
	
	    return new LruStorage(prefix, oldConfig);
	  };
	
	
	}, function() {
	
	  function CacheItem(obj) {
	    this.storageKey = obj.storageKey || obj.key || '';
	    this.maxAge = obj.maxAge || 0;
	    this.level = obj.level || 'local';
	
	    if (this.level != 'session' && this.level != 'local') {
	      throw 'there is no webstorage interface named ' + this.level +
	        'Storage';
	    }
	  }
	  CacheItem.ATTRIBUTES = ['storageKey', 'maxAge', 'level'];
	  //create by a json string
	  CacheItem.fromJSON = function parse(str) {
	    var ret = {};
	    try {
	      str = JSON.parse(str);
	
	      CacheItem.ATTRIBUTES.forEach(function(v) {
	        this[v] = str[v];
	      }, ret);
	    } catch (e) {}
	    return ret;
	  };
	
	  //check if out of date
	  CacheItem.prototype.isStale = function isStale() {
	    return Date.now() > this.maxAge;
	  };
	
	  return CacheItem;
	
	}, function() {
	  function LRUArray(idkey) {
	    this.arr = [];
	    this.idkey = typeof idkey == 'function' ? idkey : function(item) {
	      return item[idkey];
	    };
	
	    var self = this;
	    Object.defineProperty(this, 'length', {
	      get: function() {
	        return self.arr.length;
	      },
	      set: function() {
	
	      }
	    });
	  }
	  ['forEach', 'push', 'shift', 'unshift', 'pop', 'every', 'concat', 'splice']
	  .forEach(function(key) {
	    LRUArray.prototype[key] = function() {
	      return this.arr[key].apply(this.arr, arguments);
	    };
	  });
	  LRUArray.prototype.update = function(id) {
	    var index = this.indexOf(id);
	    if (index === -1) return;
	    this.updateByIndex(index);
	  };
	  LRUArray.prototype.updateByIndex = function(index) {
	    if (this.arr.length <= index || index == -1) return;
	    var item = this.arr[index];
	    this.arr.splice(index, 1);
	    this.arr.unshift(item);
	  };
	  LRUArray.prototype.indexOf = function(id) {
	    var ret = -1;
	    //TODO improve the finding algorithm?
	    this.every(function(item, index) {
	      if (this.idkey(item) == id) {
	        ret = index;
	        return false;
	      }
	      return true;
	    }, this);
	    return ret;
	  };
	  LRUArray.prototype.find = function(key, silent) {
	    var index = this.indexOf(key);
	    var item = this.arr[index];
	    if (!silent) {
	      this.updateByIndex(index);
	    }
	    return item;
	  };
	
	  return function(key) {
	    return new LRUArray(key);
	  };
	});


/***/ }),

/***/ 19:
/***/ (function(module, exports) {

	;
	(function() {
		'use strict';
	
		/**
		 * @preserve FastClick: polyfill to remove click delays on browsers with touch UIs.
		 *
		 * @codingstandard ftlabs-jsv2
		 * @copyright The Financial Times Limited [All Rights Reserved]
		 * @license MIT License (see LICENSE.txt)
		 */
	
		/*jslint browser:true, node:true*/
		/*global define, Event, Node*/
	
	
		/**
		 * Instantiate fast-clicking listeners on the specified layer.
		 *
		 * @constructor
		 * @param {Element} layer The layer to listen on
		 * @param {Object} [options={}] The options to override the defaults
		 */
		function FastClick(layer, options) {
			var oldOnClick;
	
			options = options || {};
	
			/**
			 * Whether a click is currently being tracked.
			 *
			 * @type boolean
			 */
			this.trackingClick = false;
	
	
			/**
			 * Timestamp for when click tracking started.
			 *
			 * @type number
			 */
			this.trackingClickStart = 0;
	
	
			/**
			 * The element being tracked for a click.
			 *
			 * @type EventTarget
			 */
			this.targetElement = null;
	
	
			/**
			 * X-coordinate of touch start event.
			 *
			 * @type number
			 */
			this.touchStartX = 0;
	
	
			/**
			 * Y-coordinate of touch start event.
			 *
			 * @type number
			 */
			this.touchStartY = 0;
	
	
			/**
			 * ID of the last touch, retrieved from Touch.identifier.
			 *
			 * @type number
			 */
			this.lastTouchIdentifier = 0;
	
	
			/**
			 * Touchmove boundary, beyond which a click will be cancelled.
			 *
			 * @type number
			 */
			this.touchBoundary = options.touchBoundary || 10;
	
	
			/**
			 * The FastClick layer.
			 *
			 * @type Element
			 */
			this.layer = layer;
	
			/**
			 * The minimum time between tap(touchstart and touchend) events
			 *
			 * @type number
			 */
			this.tapDelay = options.tapDelay || 200;
	
			/**
			 * The maximum time for a tap
			 *
			 * @type number
			 */
			this.tapTimeout = options.tapTimeout || 700;
	
			if (FastClick.notNeeded(layer)) {
				return;
			}
	
			// Some old versions of Android don't have Function.prototype.bind
			function bind(method, context) {
				return function() {
					return method.apply(context, arguments);
				};
			}
	
	
			var methods = ['onMouse', 'onClick', 'onTouchStart', 'onTouchMove',
				'onTouchEnd', 'onTouchCancel'
			];
			var context = this;
			for (var i = 0, l = methods.length; i < l; i++) {
				context[methods[i]] = bind(context[methods[i]], context);
			}
	
			// Set up event handlers as required
			if (deviceIsAndroid) {
				layer.addEventListener('mouseover', this.onMouse, true);
				layer.addEventListener('mousedown', this.onMouse, true);
				layer.addEventListener('mouseup', this.onMouse, true);
			}
	
			layer.addEventListener('click', this.onClick, true);
			layer.addEventListener('touchstart', this.onTouchStart, false);
			layer.addEventListener('touchmove', this.onTouchMove, false);
			layer.addEventListener('touchend', this.onTouchEnd, false);
			layer.addEventListener('touchcancel', this.onTouchCancel, false);
	
			// Hack is required for browsers that don't support Event#stopImmediatePropagation (e.g. Android 2)
			// which is how FastClick normally stops click events bubbling to callbacks registered on the FastClick
			// layer when they are cancelled.
			if (!Event.prototype.stopImmediatePropagation) {
				layer.removeEventListener = function(type, callback, capture) {
					var rmv = Node.prototype.removeEventListener;
					if (type === 'click') {
						rmv.call(layer, type, callback.hijacked || callback, capture);
					} else {
						rmv.call(layer, type, callback, capture);
					}
				};
	
				layer.addEventListener = function(type, callback, capture) {
					var adv = Node.prototype.addEventListener;
					if (type === 'click') {
						adv.call(layer, type, callback.hijacked || (callback.hijacked = function(
							event) {
							if (!event.propagationStopped) {
								callback(event);
							}
						}), capture);
					} else {
						adv.call(layer, type, callback, capture);
					}
				};
			}
	
			// If a handler is already declared in the element's onclick attribute, it will be fired before
			// FastClick's onClick handler. Fix this by pulling out the user-defined handler function and
			// adding it as listener.
			if (typeof layer.onclick === 'function') {
	
				// Android browser on at least 3.2 requires a new reference to the function in layer.onclick
				// - the old one won't work if passed to addEventListener directly.
				oldOnClick = layer.onclick;
				layer.addEventListener('click', function(event) {
					oldOnClick(event);
				}, false);
				layer.onclick = null;
			}
		}
	
		/**
		 * Windows Phone 8.1 fakes user agent string to look like Android and iPhone.
		 *
		 * @type boolean
		 */
		var deviceIsWindowsPhone = navigator.userAgent.indexOf("Windows Phone") >= 0;
	
		/**
		 * Android requires exceptions.
		 *
		 * @type boolean
		 */
		var deviceIsAndroid = navigator.userAgent.indexOf('Android') > 0 && !
			deviceIsWindowsPhone;
	
	
		/**
		 * iOS requires exceptions.
		 *
		 * @type boolean
		 */
		var deviceIsIOS = /iP(ad|hone|od)/.test(navigator.userAgent) && !
			deviceIsWindowsPhone;
	
	
		/**
		 * iOS 4 requires an exception for select elements.
		 *
		 * @type boolean
		 */
		var deviceIsIOS4 = deviceIsIOS && (/OS 4_\d(_\d)?/).test(navigator.userAgent);
	
	
		/**
		 * iOS 6.0-7.* requires the target element to be manually derived
		 *
		 * @type boolean
		 */
		var deviceIsIOSWithBadTarget = deviceIsIOS && (/OS [6-7]_\d/).test(navigator.userAgent);
	
		/**
		 * BlackBerry requires exceptions.
		 *
		 * @type boolean
		 */
		var deviceIsBlackBerry10 = navigator.userAgent.indexOf('BB10') > 0;
	
		/**
		 * Determine whether a given element requires a native click.
		 *
		 * @param {EventTarget|Element} target Target DOM element
		 * @returns {boolean} Returns true if the element needs a native click
		 */
		FastClick.prototype.needsClick = function(target) {
			switch (target.nodeName.toLowerCase()) {
	
				// Don't send a synthetic click to disabled inputs (issue #62)
				case 'button':
				case 'select':
				case 'textarea':
					if (target.disabled) {
						return true;
					}
	
					break;
				case 'input':
	
					// File inputs need real clicks on iOS 6 due to a browser bug (issue #68)
					if ((deviceIsIOS && target.type === 'file') || target.disabled) {
						return true;
					}
	
					break;
				case 'label':
				case 'iframe': // iOS8 homescreen apps can prevent events bubbling into frames
				case 'video':
					return true;
			}
	
			return (/\bneedsclick\b/).test(target.className);
		};
	
	
		/**
		 * Determine whether a given element requires a call to focus to simulate click into element.
		 *
		 * @param {EventTarget|Element} target Target DOM element
		 * @returns {boolean} Returns true if the element requires a call to focus to simulate native click.
		 */
		FastClick.prototype.needsFocus = function(target) {
			switch (target.nodeName.toLowerCase()) {
				case 'textarea':
					return true;
				case 'select':
					return !deviceIsAndroid;
				case 'input':
					switch (target.type) {
						case 'button':
						case 'checkbox':
						case 'file':
						case 'image':
						case 'radio':
						case 'submit':
							return false;
					}
	
					// No point in attempting to focus disabled inputs
					return !target.disabled && !target.readOnly;
				default:
					return (/\bneedsfocus\b/).test(target.className);
			}
		};
	
	
		/**
		 * Send a click event to the specified element.
		 *
		 * @param {EventTarget|Element} targetElement
		 * @param {Event} event
		 */
		FastClick.prototype.sendClick = function(targetElement, event) {
			var clickEvent, touch;
	
			// On some Android devices activeElement needs to be blurred otherwise the synthetic click will have no effect (#24)
			if (document.activeElement && document.activeElement !== targetElement) {
				document.activeElement.blur();
			}
	
			touch = event.changedTouches[0];
	
			// Synthesise a click event, with an extra attribute so it can be tracked
			clickEvent = document.createEvent('MouseEvents');
			clickEvent.initMouseEvent(this.determineEventType(targetElement), true,
				true, window, 1, touch.screenX, touch.screenY, touch.clientX, touch.clientY,
				false, false, false, false, 0, null);
			clickEvent.forwardedTouchEvent = true;
			targetElement.dispatchEvent(clickEvent);
		};
	
		FastClick.prototype.determineEventType = function(targetElement) {
	
			//Issue #159: Android Chrome Select Box does not open with a synthetic click event
			if (deviceIsAndroid && targetElement.tagName.toLowerCase() === 'select') {
				return 'mousedown';
			}
	
			return 'click';
		};
	
	
		/**
		 * @param {EventTarget|Element} targetElement
		 */
		FastClick.prototype.focus = function(targetElement) {
			var length;
	
			// Issue #160: on iOS 7, some input elements (e.g. date datetime month) throw a vague TypeError on setSelectionRange. These elements don't have an integer value for the selectionStart and selectionEnd properties, but unfortunately that can't be used for detection because accessing the properties also throws a TypeError. Just check the type instead. Filed as Apple bug #15122724.
			if (deviceIsIOS && targetElement.setSelectionRange && targetElement.type.indexOf(
					'date') !== 0 && targetElement.type !== 'time' && targetElement.type !==
				'month') {
				length = targetElement.value.length;
				targetElement.setSelectionRange(length, length);
			} else {
				targetElement.focus();
			}
		};
	
	
		/**
		 * Check whether the given target element is a child of a scrollable layer and if so, set a flag on it.
		 *
		 * @param {EventTarget|Element} targetElement
		 */
		FastClick.prototype.updateScrollParent = function(targetElement) {
			var scrollParent, parentElement;
	
			scrollParent = targetElement.fastClickScrollParent;
	
			// Attempt to discover whether the target element is contained within a scrollable layer. Re-check if the
			// target element was moved to another parent.
			if (!scrollParent || !scrollParent.contains(targetElement)) {
				parentElement = targetElement;
				do {
					if (parentElement.scrollHeight > parentElement.offsetHeight) {
						scrollParent = parentElement;
						targetElement.fastClickScrollParent = parentElement;
						break;
					}
	
					parentElement = parentElement.parentElement;
				} while (parentElement);
			}
	
			// Always update the scroll top tracker if possible.
			if (scrollParent) {
				scrollParent.fastClickLastScrollTop = scrollParent.scrollTop;
			}
		};
	
	
		/**
		 * @param {EventTarget} targetElement
		 * @returns {Element|EventTarget}
		 */
		FastClick.prototype.getTargetElementFromEventTarget = function(eventTarget) {
	
			// On some older browsers (notably Safari on iOS 4.1 - see issue #56) the event target may be a text node.
			if (eventTarget.nodeType === Node.TEXT_NODE) {
				return eventTarget.parentNode;
			}
	
			return eventTarget;
		};
	
	
		/**
		 * On touch start, record the position and scroll offset.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onTouchStart = function(event) {
			var targetElement, touch, selection;
	
			// Ignore multiple touches, otherwise pinch-to-zoom is prevented if both fingers are on the FastClick element (issue #111).
			if (event.targetTouches.length > 1) {
				return true;
			}
	
			targetElement = this.getTargetElementFromEventTarget(event.target);
			touch = event.targetTouches[0];
	
			if (deviceIsIOS) {
	
				// Only trusted events will deselect text on iOS (issue #49)
				selection = window.getSelection();
				if (selection.rangeCount && !selection.isCollapsed) {
					return true;
				}
	
				if (!deviceIsIOS4) {
	
					// Weird things happen on iOS when an alert or confirm dialog is opened from a click event callback (issue #23):
					// when the user next taps anywhere else on the page, new touchstart and touchend events are dispatched
					// with the same identifier as the touch event that previously triggered the click that triggered the alert.
					// Sadly, there is an issue on iOS 4 that causes some normal touch events to have the same identifier as an
					// immediately preceeding touch event (issue #52), so this fix is unavailable on that platform.
					// Issue 120: touch.identifier is 0 when Chrome dev tools 'Emulate touch events' is set with an iOS device UA string,
					// which causes all touch events to be ignored. As this block only applies to iOS, and iOS identifiers are always long,
					// random integers, it's safe to to continue if the identifier is 0 here.
					if (touch.identifier && touch.identifier === this.lastTouchIdentifier) {
						event.preventDefault();
						return false;
					}
	
					this.lastTouchIdentifier = touch.identifier;
	
					// If the target element is a child of a scrollable layer (using -webkit-overflow-scrolling: touch) and:
					// 1) the user does a fling scroll on the scrollable layer
					// 2) the user stops the fling scroll with another tap
					// then the event.target of the last 'touchend' event will be the element that was under the user's finger
					// when the fling scroll was started, causing FastClick to send a click event to that layer - unless a check
					// is made to ensure that a parent layer was not scrolled before sending a synthetic click (issue #42).
					this.updateScrollParent(targetElement);
				}
			}
	
			this.trackingClick = true;
			this.trackingClickStart = event.timeStamp;
			this.targetElement = targetElement;
	
			this.touchStartX = touch.pageX;
			this.touchStartY = touch.pageY;
	
			// Prevent phantom clicks on fast double-tap (issue #36)
			if ((event.timeStamp - this.lastClickTime) < this.tapDelay) {
				event.preventDefault();
			}
	
			return true;
		};
	
	
		/**
		 * Based on a touchmove event object, check whether the touch has moved past a boundary since it started.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.touchHasMoved = function(event) {
			var touch = event.changedTouches[0],
				boundary = this.touchBoundary;
	
			if (Math.abs(touch.pageX - this.touchStartX) > boundary || Math.abs(touch.pageY -
					this.touchStartY) > boundary) {
				return true;
			}
	
			return false;
		};
	
	
		/**
		 * Update the last position.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onTouchMove = function(event) {
			if (!this.trackingClick) {
				return true;
			}
	
			// If the touch has moved, cancel the click tracking
			if (this.targetElement !== this.getTargetElementFromEventTarget(event.target) ||
				this.touchHasMoved(event)) {
				this.trackingClick = false;
				this.targetElement = null;
			}
	
			return true;
		};
	
	
		/**
		 * Attempt to find the labelled control for the given label element.
		 *
		 * @param {EventTarget|HTMLLabelElement} labelElement
		 * @returns {Element|null}
		 */
		FastClick.prototype.findControl = function(labelElement) {
	
			// Fast path for newer browsers supporting the HTML5 control attribute
			if (labelElement.control !== undefined) {
				return labelElement.control;
			}
	
			// All browsers under test that support touch events also support the HTML5 htmlFor attribute
			if (labelElement.htmlFor) {
				return document.getElementById(labelElement.htmlFor);
			}
	
			// If no for attribute exists, attempt to retrieve the first labellable descendant element
			// the list of which is defined here: http://www.w3.org/TR/html5/forms.html#category-label
			return labelElement.querySelector(
				'button, input:not([type=hidden]), keygen, meter, output, progress, select, textarea'
			);
		};
	
	
		/**
		 * On touch end, determine whether to send a click event at once.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onTouchEnd = function(event) {
			var forElement, trackingClickStart, targetTagName, scrollParent, touch,
				targetElement = this.targetElement;
	
			if (!this.trackingClick) {
				return true;
			}
	
			// Prevent phantom clicks on fast double-tap (issue #36)
			if ((event.timeStamp - this.lastClickTime) < this.tapDelay) {
				this.cancelNextClick = true;
				return true;
			}
	
			if ((event.timeStamp - this.trackingClickStart) > this.tapTimeout) {
				return true;
			}
	
			// Reset to prevent wrong click cancel on input (issue #156).
			this.cancelNextClick = false;
	
			this.lastClickTime = event.timeStamp;
	
			trackingClickStart = this.trackingClickStart;
			this.trackingClick = false;
			this.trackingClickStart = 0;
	
			// On some iOS devices, the targetElement supplied with the event is invalid if the layer
			// is performing a transition or scroll, and has to be re-detected manually. Note that
			// for this to function correctly, it must be called *after* the event target is checked!
			// See issue #57; also filed as rdar://13048589 .
			if (deviceIsIOSWithBadTarget) {
				touch = event.changedTouches[0];
	
				// In certain cases arguments of elementFromPoint can be negative, so prevent setting targetElement to null
				targetElement = document.elementFromPoint(touch.pageX - window.pageXOffset,
					touch.pageY - window.pageYOffset) || targetElement;
				targetElement.fastClickScrollParent = this.targetElement.fastClickScrollParent;
			}
	
			targetTagName = targetElement.tagName.toLowerCase();
			if (targetTagName === 'label') {
				forElement = this.findControl(targetElement);
				if (forElement) {
					this.focus(targetElement);
					if (deviceIsAndroid) {
						return false;
					}
	
					targetElement = forElement;
				}
			} else if (this.needsFocus(targetElement)) {
	
				// Case 1: If the touch started a while ago (best guess is 100ms based on tests for issue #36) then focus will be triggered anyway. Return early and unset the target element reference so that the subsequent click will be allowed through.
				// Case 2: Without this exception for input elements tapped when the document is contained in an iframe, then any inputted text won't be visible even though the value attribute is updated as the user types (issue #37).
				if ((event.timeStamp - trackingClickStart) > 100 || (deviceIsIOS && window
						.top !== window && targetTagName === 'input')) {
					this.targetElement = null;
					return false;
				}
	
				this.focus(targetElement);
				this.sendClick(targetElement, event);
	
				// Select elements need the event to go through on iOS 4, otherwise the selector menu won't open.
				// Also this breaks opening selects when VoiceOver is active on iOS6, iOS7 (and possibly others)
				if (!deviceIsIOS || targetTagName !== 'select') {
					this.targetElement = null;
					event.preventDefault();
				}
	
				return false;
			}
	
			if (deviceIsIOS && !deviceIsIOS4) {
	
				// Don't send a synthetic click event if the target element is contained within a parent layer that was scrolled
				// and this tap is being used to stop the scrolling (usually initiated by a fling - issue #42).
				scrollParent = targetElement.fastClickScrollParent;
				if (scrollParent && scrollParent.fastClickLastScrollTop !== scrollParent.scrollTop) {
					return true;
				}
			}
	
			// Prevent the actual click from going though - unless the target node is marked as requiring
			// real clicks or if it is in the whitelist in which case only non-programmatic clicks are permitted.
			if (!this.needsClick(targetElement)) {
				event.preventDefault();
				this.sendClick(targetElement, event);
			}
	
			return false;
		};
	
	
		/**
		 * On touch cancel, stop tracking the click.
		 *
		 * @returns {void}
		 */
		FastClick.prototype.onTouchCancel = function() {
			this.trackingClick = false;
			this.targetElement = null;
		};
	
	
		/**
		 * Determine mouse events which should be permitted.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onMouse = function(event) {
	
			// If a target element was never set (because a touch event was never fired) allow the event
			if (!this.targetElement) {
				return true;
			}
	
			if (event.forwardedTouchEvent) {
				return true;
			}
	
			// Programmatically generated events targeting a specific element should be permitted
			if (!event.cancelable) {
				return true;
			}
	
			// Derive and check the target element to see whether the mouse event needs to be permitted;
			// unless explicitly enabled, prevent non-touch click events from triggering actions,
			// to prevent ghost/doubleclicks.
			if (!this.needsClick(this.targetElement) || this.cancelNextClick) {
	
				// Prevent any user-added listeners declared on FastClick element from being fired.
				if (event.stopImmediatePropagation) {
					event.stopImmediatePropagation();
				} else {
	
					// Part of the hack for browsers that don't support Event#stopImmediatePropagation (e.g. Android 2)
					event.propagationStopped = true;
				}
	
				// Cancel the event
				event.stopPropagation();
				event.preventDefault();
	
				return false;
			}
	
			// If the mouse event is permitted, return true for the action to go through.
			return true;
		};
	
	
		/**
		 * On actual clicks, determine whether this is a touch-generated click, a click action occurring
		 * naturally after a delay after a touch (which needs to be cancelled to avoid duplication), or
		 * an actual click which should be permitted.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onClick = function(event) {
			var permitted;
	
			// It's possible for another FastClick-like library delivered with third-party code to fire a click event before FastClick does (issue #44). In that case, set the click-tracking flag back to false and return early. This will cause onTouchEnd to return early.
			if (this.trackingClick) {
				this.targetElement = null;
				this.trackingClick = false;
				return true;
			}
	
			// Very odd behaviour on iOS (issue #18): if a submit element is present inside a form and the user hits enter in the iOS simulator or clicks the Go button on the pop-up OS keyboard the a kind of 'fake' click event will be triggered with the submit-type input element as the target.
			if (event.target.type === 'submit' && event.detail === 0) {
				return true;
			}
	
			permitted = this.onMouse(event);
	
			// Only unset targetElement if the click is not permitted. This will ensure that the check for !targetElement in onMouse fails and the browser's click doesn't go through.
			if (!permitted) {
				this.targetElement = null;
			}
	
			// If clicks are permitted, return true for the action to go through.
			return permitted;
		};
	
	
		/**
		 * Remove all FastClick's event listeners.
		 *
		 * @returns {void}
		 */
		FastClick.prototype.destroy = function() {
			var layer = this.layer;
	
			if (deviceIsAndroid) {
				layer.removeEventListener('mouseover', this.onMouse, true);
				layer.removeEventListener('mousedown', this.onMouse, true);
				layer.removeEventListener('mouseup', this.onMouse, true);
			}
	
			layer.removeEventListener('click', this.onClick, true);
			layer.removeEventListener('touchstart', this.onTouchStart, false);
			layer.removeEventListener('touchmove', this.onTouchMove, false);
			layer.removeEventListener('touchend', this.onTouchEnd, false);
			layer.removeEventListener('touchcancel', this.onTouchCancel, false);
		};
	
	
		/**
		 * Check whether FastClick is needed.
		 *
		 * @param {Element} layer The layer to listen on
		 */
		FastClick.notNeeded = function(layer) {
			var metaViewport;
			var chromeVersion;
			var blackberryVersion;
			var firefoxVersion;
	
			// Devices that don't support touch don't need FastClick
			if (typeof window.ontouchstart === 'undefined') {
				return true;
			}
	
			// Chrome version - zero for other browsers
			chromeVersion = +(/Chrome\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[1];
	
			if (chromeVersion) {
	
				if (deviceIsAndroid) {
					metaViewport = document.querySelector('meta[name=viewport]');
	
					if (metaViewport) {
						// Chrome on Android with user-scalable="no" doesn't need FastClick (issue #89)
						if (metaViewport.content.indexOf('user-scalable=no') !== -1) {
							return true;
						}
						// Chrome 32 and above with width=device-width or less don't need FastClick
						if (chromeVersion > 31 && document.documentElement.scrollWidth <= window
							.outerWidth) {
							return true;
						}
					}
	
					// Chrome desktop doesn't need FastClick (issue #15)
				} else {
					return true;
				}
			}
	
			if (deviceIsBlackBerry10) {
				blackberryVersion = navigator.userAgent.match(
					/Version\/([0-9]*)\.([0-9]*)/);
	
				// BlackBerry 10.3+ does not require Fastclick library.
				// https://github.com/ftlabs/fastclick/issues/251
				if (blackberryVersion[1] >= 10 && blackberryVersion[2] >= 3) {
					metaViewport = document.querySelector('meta[name=viewport]');
	
					if (metaViewport) {
						// user-scalable=no eliminates click delay.
						if (metaViewport.content.indexOf('user-scalable=no') !== -1) {
							return true;
						}
						// width=device-width (or less than device-width) eliminates click delay.
						if (document.documentElement.scrollWidth <= window.outerWidth) {
							return true;
						}
					}
				}
			}
	
			// IE10 with -ms-touch-action: none or manipulation, which disables double-tap-to-zoom (issue #97)
			if (layer.style.msTouchAction === 'none' || layer.style.touchAction ===
				'manipulation') {
				return true;
			}
	
			// Firefox version - zero for other browsers
			firefoxVersion = +(/Firefox\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[
				1];
	
			if (firefoxVersion >= 27) {
				// Firefox 27+ does not have tap delay if the content is not zoomable - https://bugzilla.mozilla.org/show_bug.cgi?id=922896
	
				metaViewport = document.querySelector('meta[name=viewport]');
				if (metaViewport && (metaViewport.content.indexOf('user-scalable=no') !==
						-1 || document.documentElement.scrollWidth <= window.outerWidth)) {
					return true;
				}
			}
	
			// IE11: prefixed -ms-touch-action is no longer supported and it's recomended to use non-prefixed version
			// http://msdn.microsoft.com/en-us/library/windows/apps/Hh767313.aspx
			if (layer.style.touchAction === 'none' || layer.style.touchAction ===
				'manipulation') {
				return true;
			}
	
			return false;
		};
	
	
		/**
		 * Factory method for creating a FastClick object
		 *
		 * @param {Element} layer The layer to listen on
		 * @param {Object} [options={}] The options to override the defaults
		 */
		FastClick.attach = function(layer, options) {
			return new FastClick(layer, options);
		};
	
	
		// if (typeof define === 'function' && define.cmd) {
		// 	define(function(require, exports, module) {
		// 		module.exports = FastClick;
		// 	});
		// } else {
		// 	window.FastClick = FastClick;
		// }
		module.exports = FastClick;
	}());


/***/ }),

/***/ 24:
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, e, module) {
	    var qs = function() {return document.querySelector.apply(document, arguments)};
	
	    var $error = qs('#error'),
	        $errorMsg = qs('#error_msg'),
	        $subTit = qs('#error_subtit'),
	        $retry = qs('#retry');
	
	    var defer;
	
	    var listener = function() {
	        defer.resolve();
	        $retry.removeEventListener('click', listener);
	        $error.style.display = 'none';
	    };
	
	    module.exports = function(msg, btnTxt, subTit, def) {
	        defer = def || $.Deferred();
	        $errorMsg.textContent = msg;
	        $retry.textContent = btnTxt;
	        subTit && ($subTit.textContent = subTit);
	        $error.style.display = 'block';
	        $retry.addEventListener('click', listener);
	        return typeof defer.promise == 'function' ? defer.promise() : defer.promise;
	    };
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),

/***/ 38:
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, e, module) {
	    var $loading = document.querySelector('#loading');
	
	    module.exports = {
	        loaded: function loaded() {
	            $loading.style.display = 'none';
	        },
	        loading: function loading() {
	            $loading.style.display = 'block';
	        }
	    };
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),

/***/ 39:
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;/**
	 * 由于QZHTTP的json callback命名不能含有"."
	 * 所以angular的jsonp服务就这样被鄙视了。
	 * 所以就要手动修复
	 * #远古代码虐我千百遍
	 */
	(function(factory) {
		!(__WEBPACK_AMD_DEFINE_RESULT__ = function(require, exports, module) {
			module.exports = function(ngModule) {
				factory(ngModule);
			}
		}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	})(function(ngModule) {
		ngModule
			.config(['$httpProvider', function($hp) {
				$hp.interceptors.push('jsonpInterceptor');
			}])
			.factory('jsonpInterceptor', ['$timeout', '$window', '$q', function($timeout, $window, $q) {
				return {
					'request': function(config) {
						if (config.method === 'JSONP') {
							var callbackId = angular.callbacks.counter.toString(36);
							config.callbackName = 'angular_callbacks_' + callbackId;
							config.url = config.url.replace('JSON_CALLBACK', config.callbackName);
	
							$timeout(function() {
								$window[config.callbackName] = angular.callbacks['_' + callbackId];
							}, 0, false);
						}
	
						return config;
					},
	
					'response': function(response) {
						var config = response.config;
						if (config.method === 'JSONP') {
							delete $window[config.callbackName]; // cleanup
						}
	
						return response;
					},
	
					'responseError': function(rejection) {
						var config = rejection.config;
						if (config.method === 'JSONP') {
							delete $window[config.callbackName]; // cleanup
						}
	
						return $q.reject(rejection);
					}
				};
			}]);
	});


/***/ }),

/***/ 40:
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;(function (factory) {
		!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, exports, module) {
			module.exports = function (ngModule) {
				__webpack_require__(41)(ngModule);
				factory(ngModule);
			}
		}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	})(function (ngModule) {
		ngModule
			.factory('$getUrlParam', ['$filterXSS', function ($filterXSS) {
	
				return function (name, url) {
					var r = new RegExp("(\\?|#|&)" + name + "=([^&#]*)(&|#|$)");
					url = url || location.href;
					var m = url.match(r);
					return (!m ? "" : $filterXSS(m[2]));
				};
			}]);
	});

/***/ }),

/***/ 41:
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;(function (factory) {
		!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, exports, module) {
			module.exports = function (ngModule) {
				factory(ngModule);
			}
		}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	})(function (ngModule) {
		ngModule
			.factory('$filterXSS', function () {
	
				return function (str) {
					if (typeof str != "string")return str;
					return str.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;").replace(/\'/g, "&apos;");
				};
			});
	});

/***/ }),

/***/ 42:
/***/ (function(module, exports, __webpack_require__) {

	/**
	 */
	var boss = __webpack_require__(2);
	module.exports = function(ngModule, event) {
		boss(event);//pv
		ngModule
				.directive('boss', function() {
					return {
						link: function($scope, element) {
							element.on('click', function() {
								boss(element.attr('_boss'));
							});
						}
					};
				});
	};

/***/ })

/******/ });