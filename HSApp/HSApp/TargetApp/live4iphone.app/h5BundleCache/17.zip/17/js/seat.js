/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	window.requestAnimationFrame = window.requestAnimationFrame || function () {
		setTimeout(arguments[0], 16);
	};
	var boss = __webpack_require__(2);
	boss.delegate('app_v_seat');
	
	var $_seat_list = __webpack_require__(43),
		$_txvuser_cookie = __webpack_require__(44),
		$_schedule_info = __webpack_require__(45),
		$_check_order_unpay = __webpack_require__(46),
		$_order_cancel = __webpack_require__(47),
		$_get_discount = __webpack_require__(48),
		SeatVM = __webpack_require__(49),
		VerifyVM = __webpack_require__(50),
	
		errorPop = __webpack_require__(24),
		loadingPop = __webpack_require__(38),
		confirmPop = __webpack_require__(5),
		Toast = __webpack_require__(34);
	
	var $form = $('#form');
	var urlData = decodeURIComponent($.util.getUrlParam('data'));
	var POSTING = false;
	var NEEDVERIFY = true;
	var TABLE_WIDTH = 0;
	
	if (!urlData) {
		throw new Error('参数错误，无法继续');
	} else {
		urlData = JSON.parse(urlData);
		$('#c_id').text('该场次由' + urlData.c_nm + '支持');
		$('#summ').text(urlData.lagu + urlData.type + ' / ' + urlData.date + ' ' + urlData.time);
		Object.keys(urlData).forEach(function(key) {
			$form.find('[name="' + key + '"]').val(urlData[key]);
		});
	}
	var VMMap = {};
	
	var $td,
		$table = $('#table'),
		$colist = $('#colist'),
		// $confirm = $('#confirm'),
		$confirm2 = $('#confirm2'),
		$wrap = $('#seat_wrap'),
		$scaler = $('#scaler'),
		singleLover = false,
		price = urlData.price,
	
		//优惠信息
		discount_id = urlData.discount_id,
		c_id = urlData.c_id,
		c_showid = urlData.c_showid,
		discountTable = {
			count: 0
		},
		discountPrice = urlData.discount_price || price;
	
	$_txvuser_cookie()
		.fail(function() {
			errorPop('获取登录信息失败', '刷新重试', null, $.Deferred()).then(function() {
				location.reload();
			});
		})
		.done(function(ret) {
			if (!ret.vusession || !ret.vuserid) {
				QQVideoBridge.loginTv({}, function(r) {
					if (r.data.errCode == "2") {//用户取消
						history.back();
					} else {
						window.location.reload();
					}
				});
				return;
			}
			$_check_order_unpay(ret).done(function(orderid) {
				if (orderid != '0') {
					confirmPop('是否取消上一个订单？取消后座位不再保留', '继续支付', '取消')
						.done(function() {
							location.href = './pay.html?order_id=' + orderid;
						})
						.fail(function() {
							$_order_cancel($.extend({order_id: orderid}, ret)).done(function() {
								location.reload();
							});
						});
				}
			});
	
			//如果有折扣价id，则需要请求折扣价信息
			if(discount_id) {
				$_get_discount({
					c_id: c_id,
					c_showid: c_showid,
					discount_id: discount_id,
					from: 1,
					vuserid: ret.vuserid,
					vusession: ret.vusession
				}).fail(function(){
					Toast('你已经享受过优惠了，此次订单以原价计算');
				})
				.done(function(ret) {
					if(ret.retcode === 0) {
						var list = ret.discount_list;
						for(var i = 0, len = list.length; i < len; i++) {
							var totalCount = list[i].total_count;
							discountTable[totalCount] = list[i].discount_price;
							discountTable.count++;
						}
					}
				});
			}
			
			Object.keys(ret).forEach(function(key) {
				$form.find('[name="' + key + '"]').val(ret[key]);
			});
			$_schedule_info($.extend({
				theater_id: urlData.tid,
				film_id: urlData.fid,
				c_id: urlData.c_id,
				c_showid: urlData.c_showid,
				c_roomid: urlData.c_roomid,
				c_cinema_id: urlData.c_cinema_id,
				date: urlData.date,
				time: urlData.time
			}, ret)).done(function(ret) {
				$('#title').text(ret.film.name).parent().show();
				$('#screen').text(ret.schedule.room_nm + '银幕');
	
				Object.keys(ret.theater).forEach(function(key) {
					$form.find('[name="theater_' + key + '"]').val(ret.theater[key]);
				});
	
				var filmAndSchedule = $.extend(ret.film, ret.schedule);
				Object.keys(filmAndSchedule).forEach(function(key) {
					$form.find('[name="film_' + key + '"]').val(filmAndSchedule[key]);
				});
	
				if (ret.phone) {
					NEEDVERIFY = false;
				}
				$form.find('[name="phone"]').val(ret.recv_phone || ret.phone);
	
	
			}).fail(function() {
				errorPop('获取影片信息失败了', '刷新重试', null, $.Deferred()).then(function() {
					location.reload();
				});
			});
	
			$_seat_list({
				c_id: urlData.c_id,
				c_cinema_id: urlData.c_cinema_id,
				c_roomid: urlData.c_roomid,
				c_showid: urlData.c_showid
			}).done(function(ret) {
				var minCol = 10240;
				//绘制座位表格
				var $row = '<li class="row">';
				for (var i = 0; i < ret.seats_col; i++) {
					$row += '<span class="seat_empty"><i class="icon_seat" style="display:none"></i></span>';
				}
				$row = $row + '</li>';
	
				for (i = 0; i < ret.seats_row; i++) {
					$table.append($($row));
					$colist.append('<li class="col">&nbsp;</li>');
				}
	
				//渲染座位
				ret.seats.forEach(function(v) {
					if (v.status != 2) {
						minCol = Math.min(v.col, minCol);
					} else {
						return;
					}
	
					$td = $table.find('li').eq(v.row - 1).find('span').eq(v.col - 1);
	
					var _seat = new SeatVM($td);
					_seat
						.setParam({
							row: v.row,
							col: v.col,
							id: v.id,
							name: v.name
						})
						.setFlag(v.flag, singleLover && singleLover.flag != v.flag ? singleLover : null)
						.setStatus(v.status);
					VMMap[$td.data('_vm')] = _seat;
	
					if (v.flag != '0') { //遍历到情侣座时，先缓存，并与下一个情侣座匹配。
						singleLover = singleLover && singleLover.flag != v.flag ? null : _seat;
					}
	
					//渲染行号
					$colist.find('li').eq(v.row - 1).text(v.name.split(':')[0].split('排')[0]);
	
				});
	
				TABLE_WIDTH = (ret.seats_col + 2) * 22;
				scaleTheTable(document.body.clientWidth / TABLE_WIDTH);
				curTrans = lastTrans = document.body.clientWidth / TABLE_WIDTH;
	
				loadingPop.loaded();
			}).fail(function() {
				errorPop('加载座位表失败了', '刷新重试', null, $.Deferred()).then(function() {
					location.reload();
				});
			});
	
			var checked = [],
				$tickets = $('#tickets');
			checked._remove = function(id) {
				for (var i = 0; i < this.length; i++) {
					if (this[i].id == id) {
						this.splice(i, 1);
						break;
					}
				}
			};
			checked._render = function() {
				var arr = this;
				//渲染票格
				$tickets.find('li').each(function(i) {
					if (arr[i]) {
						$(this).html(arr[i].get$ticket()).show().data('_vm', [arr[i].row, arr[i].col].join('|'));
					} else {
						$(this).html('').hide();
					}
				});
	
				//有选择时点亮按钮并修改文案
				if (arr.length === 0) {
					// $confirm.addClass('btn_disable').text('请选择座位');
					$confirm2.addClass('btn_forbid').val('选座后提交');
					$tickets.hide();
				} else {
					$tickets.show();
					// $confirm.removeClass('btn_disable').text('确定 ￥' + ((arr.length * price) / 100).toFixed(2));
	
					var priceTemp = 0;
					//表示有折扣信息
					if(discountTable.count > 0) {
						priceTemp = discountTable[arr.length];
					}
					if(priceTemp === 0) {
						//表示没有折扣信息
						priceTemp = price * arr.length;
						$form.find('[name="discount_id"]').val('');
						$form.find('[name="discount_price"]').val('');
					}
	
					$confirm2.removeClass('btn_forbid').val('￥' + ((priceTemp % 100 !== 0) ? (priceTemp / 100).toFixed(2) : (priceTemp / 100)));
				}
			};
	
			$tickets.on('click', 'li', function(e) {
				var $e = $(e.currentTarget),
					vm = VMMap[$e.data('_vm')];
				if (vm) {
					checked._remove(vm.id);
					vm.check(false);
					checked._render();
				}
			});
			$table.on('click', 'span', function(e) {
				var $seat = $(e.currentTarget);
				var vm = VMMap[$seat.data('_vm')];
	
				if (!vm) {
					return;
				}
				if (!vm.check()) {
					checked._remove(vm.id);
					vm.partner && checked._remove(vm.partner.id);
					checked._render();
				} else if (checked.length < 4 && !(vm.partner && checked.length >= 3)) {
					checked.push(vm);
					vm.partner && checked.push(vm.partner);
					checked._render();
				} else {
					//超过4个票，取消check态
					vm.check();
					Toast('最多只可选择4个座位');
				}
	
			});
	
			//提交第一次后锁死按钮，防止重复提交
			$form.on('submit', function() {
				// $confirm.text('提交中').addClass('btn_disable');
				$confirm2.val('提交中').addClass('btn_forbid');
				POSTING = true;
			});
			$form.find('[name="phone"]').focus(function () {
				// document.body.scrollTop = 1000;
			});
	
	
			//提交
			// $confirm.on('click', confirms);
			$confirm2.on('click', confirms);
			function confirms() {
				if (checked.length && !POSTING) {
					if (killFFtuan()) {
						Toast('请尽量选择连续的座位');
						return false;
					}
	
					var ids = [],
						names = [];
						console.log(checked);
					checked.forEach(function(v) {
						ids.push(v.id);
						names.push(v.name);
					});
					$form.find('[name="seats"]').val(ids.join(','));
					$form.find('[name="seats_name"]').val(names.join(','));
					$form.find('[name="price"]').val(checked.length * price);
					
					//计算折扣价
					var priceTemp = 0;
					if(discountTable.count > 0) {
						priceTemp = discountTable[checked.length];
					}
	
					if(priceTemp === 0) {
						priceTemp = price * checked.length;
						//没有折扣信息
						$form.find('[name="discount_id"]').val('');
						$form.find('[name="discount_price"]').val('');
					} else {
						$form.find('[name="discount_price"]').val(priceTemp);
					}
	
					
					
					var tempphone = $form.find('[name="phone"]').val();
	
					if (!tempphone.match(/^\d{11}$/)) {
						Toast('请输入正确的手机号');
						return false;
					} else if (NEEDVERIFY) {
						//没有手机时展现验证浮层
						VerifyVM(tempphone).done(function(phone) {
							$form.find('[name="phone"]').val(phone);
							$form.submit();
						});
						return false;
					} else {
						$form.submit();
					}
	
				} else {
					return false;
				}
			}
	
			var originDis = 0, fingerNum = 0;
			function fixColList() {
				var scrollLeft = Math.min(Math.max($wrap[0].scrollLeft, 0), $wrap[0].scrollWidth - $wrap[0].clientWidth) + 10;
				$colist.css({
					left: scrollLeft / curTrans + 'px'
				});
				$scaler.css({
					opacity: 0.99 + Math.random() / 100
				});
				requestAnimationFrame(fixColList);
			}
			requestAnimationFrame(fixColList);
			//还是要自己造轮子啊 hammerjs只有用canvas的时候给力
	
			$wrap
				.on('touchstart', function(e) {
					fingerNum = e.touches.length;
					if (fingerNum == 2) {
						originDis = countDis(e.touches[0], e.touches[1]);
					}
				})
				.on('touchmove', function (e) {
					if (fingerNum == 2) {
						e.preventDefault();
						curTrans = countDis(e.touches[0], e.touches[1]) / originDis * lastTrans;
						scaleTheTable(curTrans);
					}
				})
				.on('touchend', function(e) {
					fingerNum = e.touches.length;
					if (fingerNum == 2) {
						originDis = countDis(e.touches[0], e.touches[1]);
					} else {
	
						lastTrans = scaleTheTable(curTrans);
					}
				});
	
			function countDis(touchA, touchB) {
				var dx = touchA.pageX - touchB.pageX,
					dy = touchA.pageY - touchB.pageY;
				return Math.sqrt(dx * dx + dy * dy);
			}
	
			//隔选党杀手,依赖外部变量checked VMMap
			var killFFtuan = (function() {
				function findgap() {
					var ret = [];
					$.each(checked, function(i) {
						for (var j = i + 1; j < checked.length; j++) {//O(n!)的算法
							if (checked[i].row == checked[j].row && Math.abs(checked[j].col - checked[i].col) == 2) {
								if (checked[j].col > checked[i].col) { //隔座在右边
									ret.push([checked[i], 'next']);
								} else {//隔座在左边。
									ret.push([checked[i], 'prev']);
								}
							}
						}
					});
					return ret;
				}
				return function() {
					var isFFtuan = false;
					$.each(findgap(), function(i, v) {
						var vm = VMMap[v[0].$el[v[1]]().data('_vm')];
						if (vm && vm.status == '0' && !vm.checked) {
							isFFtuan = true;
						}
					});
					return isFFtuan;
				};
			})();
		});
	
	var lastTrans = 1, curTrans = 1;
	var oWidth, oHeight;
	function scaleTheTable(scale) {
		if (scale < 0.5) {
			scale = 0.5;
		} else if (scale > 2) {
			scale = 2;
		}
	
		oWidth = oWidth || TABLE_WIDTH || $scaler.width();
		oHeight = oHeight || $scaler.height();
		$scaler
			.css({
				'width': oWidth * scale + 'px',
				'height': oHeight * scale + 'px',
				'-webkit-transform': 'scale(' + scale + ')',
				'transform': 'scale(' + scale + ')'
			});
	
		return scale;
		// $colist.css({
		// 	left: ($scaler.parent()[0].scrollLeft + 10) / scale + 'px'
		// });
	}
	
	QQVideoBridge.setMoreInfo({"hasRefresh":true, "hasShare":false, "hasFollow":false});
	//去你大爷的300ms延迟
	$(document).ready(function () {
		__webpack_require__(19).attach(document.body);
		location.hash = "";
	});

/***/ }),
/* 1 */,
/* 2 */
/***/ (function(module, exports) {

	// http://tapd.oa.com/tvideo/prong/stories/view/1010031991056992805?url_cache_key=dc4c5bdd3ef3797a13e788c323168a6f&action_entry_type=story_tree_list
	var sessionStorage = window.sessionStorage || {
			getItem: function () {
			}, setItem: function () {
			}, removeItem: function () {
			}
		};
	var base_url = "https://btrace.qq.com/kvcollect?BossId=3243&Pwd=1546101498&plat=1&ua=" + navigator.userAgent + "&_dc=" + Math.random();
	var ref;
	
	
	//播放页来源
	if (location.href.indexOf('app.package.play') != -1) {
		sessionStorage.setItem('piao-ref', ref = 11);
	} else if (location.href.indexOf('app.package.user') != -1 || location.href.indexOf('app.package.channel') != -1) {
		sessionStorage.setItem('piao-ref', ref = 12);
	} else {
		ref = sessionStorage.getItem('piao-ref') || 12;
	}
	base_url += '&ref=' + ref;
	
	var exp = function (event, cid) {
		var g_btrace_BOSS = new Image(1, 1);
		g_btrace_BOSS.src = base_url + '&event=' + event + (cid ? ('&cid=' + cid) : '');
	};
	exp.delegate = function (event) {
		var $ = window.jQuery || window.Zepto;
		exp(event);//pv
		$(document.body).on('click', '[_boss]', function (e) {
			exp($(e.currentTarget).attr('_boss'));
		});
	};
	module.exports = exp;

/***/ }),
/* 3 */,
/* 4 */,
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, exports, module) {
	    var $pop = document.querySelector('#alert'),
	        $confirm = document.querySelector('#alert_confirm'),
	        $cancel = document.querySelector('#alert_cancel'),
	        $msg = document.querySelector('#alert_msg');
	
	    var def;
	
	    $confirm.addEventListener('click', function() {
	        def && def.resolve();
	        $pop.style.display = "none";
	    });
	    $cancel.addEventListener('click', function() {
	        def && def.reject();
	        $pop.style.display = "none";
	    });
	
	    module.exports = function(msg, confirmTxt, cancelTxt, defer) {
	        def = defer || $.Deferred();
	        $pop.style.display = "block";
	        $msg.innerHTML = msg;
	        $confirm.innerHTML = confirmTxt;
	        $cancel.innerHTML = cancelTxt;
	        return typeof def.promise == 'function' ? def.promise() : def.promise;
	    };
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */,
/* 14 */,
/* 15 */,
/* 16 */,
/* 17 */,
/* 18 */,
/* 19 */
/***/ (function(module, exports) {

	;
	(function() {
		'use strict';
	
		/**
		 * @preserve FastClick: polyfill to remove click delays on browsers with touch UIs.
		 *
		 * @codingstandard ftlabs-jsv2
		 * @copyright The Financial Times Limited [All Rights Reserved]
		 * @license MIT License (see LICENSE.txt)
		 */
	
		/*jslint browser:true, node:true*/
		/*global define, Event, Node*/
	
	
		/**
		 * Instantiate fast-clicking listeners on the specified layer.
		 *
		 * @constructor
		 * @param {Element} layer The layer to listen on
		 * @param {Object} [options={}] The options to override the defaults
		 */
		function FastClick(layer, options) {
			var oldOnClick;
	
			options = options || {};
	
			/**
			 * Whether a click is currently being tracked.
			 *
			 * @type boolean
			 */
			this.trackingClick = false;
	
	
			/**
			 * Timestamp for when click tracking started.
			 *
			 * @type number
			 */
			this.trackingClickStart = 0;
	
	
			/**
			 * The element being tracked for a click.
			 *
			 * @type EventTarget
			 */
			this.targetElement = null;
	
	
			/**
			 * X-coordinate of touch start event.
			 *
			 * @type number
			 */
			this.touchStartX = 0;
	
	
			/**
			 * Y-coordinate of touch start event.
			 *
			 * @type number
			 */
			this.touchStartY = 0;
	
	
			/**
			 * ID of the last touch, retrieved from Touch.identifier.
			 *
			 * @type number
			 */
			this.lastTouchIdentifier = 0;
	
	
			/**
			 * Touchmove boundary, beyond which a click will be cancelled.
			 *
			 * @type number
			 */
			this.touchBoundary = options.touchBoundary || 10;
	
	
			/**
			 * The FastClick layer.
			 *
			 * @type Element
			 */
			this.layer = layer;
	
			/**
			 * The minimum time between tap(touchstart and touchend) events
			 *
			 * @type number
			 */
			this.tapDelay = options.tapDelay || 200;
	
			/**
			 * The maximum time for a tap
			 *
			 * @type number
			 */
			this.tapTimeout = options.tapTimeout || 700;
	
			if (FastClick.notNeeded(layer)) {
				return;
			}
	
			// Some old versions of Android don't have Function.prototype.bind
			function bind(method, context) {
				return function() {
					return method.apply(context, arguments);
				};
			}
	
	
			var methods = ['onMouse', 'onClick', 'onTouchStart', 'onTouchMove',
				'onTouchEnd', 'onTouchCancel'
			];
			var context = this;
			for (var i = 0, l = methods.length; i < l; i++) {
				context[methods[i]] = bind(context[methods[i]], context);
			}
	
			// Set up event handlers as required
			if (deviceIsAndroid) {
				layer.addEventListener('mouseover', this.onMouse, true);
				layer.addEventListener('mousedown', this.onMouse, true);
				layer.addEventListener('mouseup', this.onMouse, true);
			}
	
			layer.addEventListener('click', this.onClick, true);
			layer.addEventListener('touchstart', this.onTouchStart, false);
			layer.addEventListener('touchmove', this.onTouchMove, false);
			layer.addEventListener('touchend', this.onTouchEnd, false);
			layer.addEventListener('touchcancel', this.onTouchCancel, false);
	
			// Hack is required for browsers that don't support Event#stopImmediatePropagation (e.g. Android 2)
			// which is how FastClick normally stops click events bubbling to callbacks registered on the FastClick
			// layer when they are cancelled.
			if (!Event.prototype.stopImmediatePropagation) {
				layer.removeEventListener = function(type, callback, capture) {
					var rmv = Node.prototype.removeEventListener;
					if (type === 'click') {
						rmv.call(layer, type, callback.hijacked || callback, capture);
					} else {
						rmv.call(layer, type, callback, capture);
					}
				};
	
				layer.addEventListener = function(type, callback, capture) {
					var adv = Node.prototype.addEventListener;
					if (type === 'click') {
						adv.call(layer, type, callback.hijacked || (callback.hijacked = function(
							event) {
							if (!event.propagationStopped) {
								callback(event);
							}
						}), capture);
					} else {
						adv.call(layer, type, callback, capture);
					}
				};
			}
	
			// If a handler is already declared in the element's onclick attribute, it will be fired before
			// FastClick's onClick handler. Fix this by pulling out the user-defined handler function and
			// adding it as listener.
			if (typeof layer.onclick === 'function') {
	
				// Android browser on at least 3.2 requires a new reference to the function in layer.onclick
				// - the old one won't work if passed to addEventListener directly.
				oldOnClick = layer.onclick;
				layer.addEventListener('click', function(event) {
					oldOnClick(event);
				}, false);
				layer.onclick = null;
			}
		}
	
		/**
		 * Windows Phone 8.1 fakes user agent string to look like Android and iPhone.
		 *
		 * @type boolean
		 */
		var deviceIsWindowsPhone = navigator.userAgent.indexOf("Windows Phone") >= 0;
	
		/**
		 * Android requires exceptions.
		 *
		 * @type boolean
		 */
		var deviceIsAndroid = navigator.userAgent.indexOf('Android') > 0 && !
			deviceIsWindowsPhone;
	
	
		/**
		 * iOS requires exceptions.
		 *
		 * @type boolean
		 */
		var deviceIsIOS = /iP(ad|hone|od)/.test(navigator.userAgent) && !
			deviceIsWindowsPhone;
	
	
		/**
		 * iOS 4 requires an exception for select elements.
		 *
		 * @type boolean
		 */
		var deviceIsIOS4 = deviceIsIOS && (/OS 4_\d(_\d)?/).test(navigator.userAgent);
	
	
		/**
		 * iOS 6.0-7.* requires the target element to be manually derived
		 *
		 * @type boolean
		 */
		var deviceIsIOSWithBadTarget = deviceIsIOS && (/OS [6-7]_\d/).test(navigator.userAgent);
	
		/**
		 * BlackBerry requires exceptions.
		 *
		 * @type boolean
		 */
		var deviceIsBlackBerry10 = navigator.userAgent.indexOf('BB10') > 0;
	
		/**
		 * Determine whether a given element requires a native click.
		 *
		 * @param {EventTarget|Element} target Target DOM element
		 * @returns {boolean} Returns true if the element needs a native click
		 */
		FastClick.prototype.needsClick = function(target) {
			switch (target.nodeName.toLowerCase()) {
	
				// Don't send a synthetic click to disabled inputs (issue #62)
				case 'button':
				case 'select':
				case 'textarea':
					if (target.disabled) {
						return true;
					}
	
					break;
				case 'input':
	
					// File inputs need real clicks on iOS 6 due to a browser bug (issue #68)
					if ((deviceIsIOS && target.type === 'file') || target.disabled) {
						return true;
					}
	
					break;
				case 'label':
				case 'iframe': // iOS8 homescreen apps can prevent events bubbling into frames
				case 'video':
					return true;
			}
	
			return (/\bneedsclick\b/).test(target.className);
		};
	
	
		/**
		 * Determine whether a given element requires a call to focus to simulate click into element.
		 *
		 * @param {EventTarget|Element} target Target DOM element
		 * @returns {boolean} Returns true if the element requires a call to focus to simulate native click.
		 */
		FastClick.prototype.needsFocus = function(target) {
			switch (target.nodeName.toLowerCase()) {
				case 'textarea':
					return true;
				case 'select':
					return !deviceIsAndroid;
				case 'input':
					switch (target.type) {
						case 'button':
						case 'checkbox':
						case 'file':
						case 'image':
						case 'radio':
						case 'submit':
							return false;
					}
	
					// No point in attempting to focus disabled inputs
					return !target.disabled && !target.readOnly;
				default:
					return (/\bneedsfocus\b/).test(target.className);
			}
		};
	
	
		/**
		 * Send a click event to the specified element.
		 *
		 * @param {EventTarget|Element} targetElement
		 * @param {Event} event
		 */
		FastClick.prototype.sendClick = function(targetElement, event) {
			var clickEvent, touch;
	
			// On some Android devices activeElement needs to be blurred otherwise the synthetic click will have no effect (#24)
			if (document.activeElement && document.activeElement !== targetElement) {
				document.activeElement.blur();
			}
	
			touch = event.changedTouches[0];
	
			// Synthesise a click event, with an extra attribute so it can be tracked
			clickEvent = document.createEvent('MouseEvents');
			clickEvent.initMouseEvent(this.determineEventType(targetElement), true,
				true, window, 1, touch.screenX, touch.screenY, touch.clientX, touch.clientY,
				false, false, false, false, 0, null);
			clickEvent.forwardedTouchEvent = true;
			targetElement.dispatchEvent(clickEvent);
		};
	
		FastClick.prototype.determineEventType = function(targetElement) {
	
			//Issue #159: Android Chrome Select Box does not open with a synthetic click event
			if (deviceIsAndroid && targetElement.tagName.toLowerCase() === 'select') {
				return 'mousedown';
			}
	
			return 'click';
		};
	
	
		/**
		 * @param {EventTarget|Element} targetElement
		 */
		FastClick.prototype.focus = function(targetElement) {
			var length;
	
			// Issue #160: on iOS 7, some input elements (e.g. date datetime month) throw a vague TypeError on setSelectionRange. These elements don't have an integer value for the selectionStart and selectionEnd properties, but unfortunately that can't be used for detection because accessing the properties also throws a TypeError. Just check the type instead. Filed as Apple bug #15122724.
			if (deviceIsIOS && targetElement.setSelectionRange && targetElement.type.indexOf(
					'date') !== 0 && targetElement.type !== 'time' && targetElement.type !==
				'month') {
				length = targetElement.value.length;
				targetElement.setSelectionRange(length, length);
			} else {
				targetElement.focus();
			}
		};
	
	
		/**
		 * Check whether the given target element is a child of a scrollable layer and if so, set a flag on it.
		 *
		 * @param {EventTarget|Element} targetElement
		 */
		FastClick.prototype.updateScrollParent = function(targetElement) {
			var scrollParent, parentElement;
	
			scrollParent = targetElement.fastClickScrollParent;
	
			// Attempt to discover whether the target element is contained within a scrollable layer. Re-check if the
			// target element was moved to another parent.
			if (!scrollParent || !scrollParent.contains(targetElement)) {
				parentElement = targetElement;
				do {
					if (parentElement.scrollHeight > parentElement.offsetHeight) {
						scrollParent = parentElement;
						targetElement.fastClickScrollParent = parentElement;
						break;
					}
	
					parentElement = parentElement.parentElement;
				} while (parentElement);
			}
	
			// Always update the scroll top tracker if possible.
			if (scrollParent) {
				scrollParent.fastClickLastScrollTop = scrollParent.scrollTop;
			}
		};
	
	
		/**
		 * @param {EventTarget} targetElement
		 * @returns {Element|EventTarget}
		 */
		FastClick.prototype.getTargetElementFromEventTarget = function(eventTarget) {
	
			// On some older browsers (notably Safari on iOS 4.1 - see issue #56) the event target may be a text node.
			if (eventTarget.nodeType === Node.TEXT_NODE) {
				return eventTarget.parentNode;
			}
	
			return eventTarget;
		};
	
	
		/**
		 * On touch start, record the position and scroll offset.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onTouchStart = function(event) {
			var targetElement, touch, selection;
	
			// Ignore multiple touches, otherwise pinch-to-zoom is prevented if both fingers are on the FastClick element (issue #111).
			if (event.targetTouches.length > 1) {
				return true;
			}
	
			targetElement = this.getTargetElementFromEventTarget(event.target);
			touch = event.targetTouches[0];
	
			if (deviceIsIOS) {
	
				// Only trusted events will deselect text on iOS (issue #49)
				selection = window.getSelection();
				if (selection.rangeCount && !selection.isCollapsed) {
					return true;
				}
	
				if (!deviceIsIOS4) {
	
					// Weird things happen on iOS when an alert or confirm dialog is opened from a click event callback (issue #23):
					// when the user next taps anywhere else on the page, new touchstart and touchend events are dispatched
					// with the same identifier as the touch event that previously triggered the click that triggered the alert.
					// Sadly, there is an issue on iOS 4 that causes some normal touch events to have the same identifier as an
					// immediately preceeding touch event (issue #52), so this fix is unavailable on that platform.
					// Issue 120: touch.identifier is 0 when Chrome dev tools 'Emulate touch events' is set with an iOS device UA string,
					// which causes all touch events to be ignored. As this block only applies to iOS, and iOS identifiers are always long,
					// random integers, it's safe to to continue if the identifier is 0 here.
					if (touch.identifier && touch.identifier === this.lastTouchIdentifier) {
						event.preventDefault();
						return false;
					}
	
					this.lastTouchIdentifier = touch.identifier;
	
					// If the target element is a child of a scrollable layer (using -webkit-overflow-scrolling: touch) and:
					// 1) the user does a fling scroll on the scrollable layer
					// 2) the user stops the fling scroll with another tap
					// then the event.target of the last 'touchend' event will be the element that was under the user's finger
					// when the fling scroll was started, causing FastClick to send a click event to that layer - unless a check
					// is made to ensure that a parent layer was not scrolled before sending a synthetic click (issue #42).
					this.updateScrollParent(targetElement);
				}
			}
	
			this.trackingClick = true;
			this.trackingClickStart = event.timeStamp;
			this.targetElement = targetElement;
	
			this.touchStartX = touch.pageX;
			this.touchStartY = touch.pageY;
	
			// Prevent phantom clicks on fast double-tap (issue #36)
			if ((event.timeStamp - this.lastClickTime) < this.tapDelay) {
				event.preventDefault();
			}
	
			return true;
		};
	
	
		/**
		 * Based on a touchmove event object, check whether the touch has moved past a boundary since it started.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.touchHasMoved = function(event) {
			var touch = event.changedTouches[0],
				boundary = this.touchBoundary;
	
			if (Math.abs(touch.pageX - this.touchStartX) > boundary || Math.abs(touch.pageY -
					this.touchStartY) > boundary) {
				return true;
			}
	
			return false;
		};
	
	
		/**
		 * Update the last position.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onTouchMove = function(event) {
			if (!this.trackingClick) {
				return true;
			}
	
			// If the touch has moved, cancel the click tracking
			if (this.targetElement !== this.getTargetElementFromEventTarget(event.target) ||
				this.touchHasMoved(event)) {
				this.trackingClick = false;
				this.targetElement = null;
			}
	
			return true;
		};
	
	
		/**
		 * Attempt to find the labelled control for the given label element.
		 *
		 * @param {EventTarget|HTMLLabelElement} labelElement
		 * @returns {Element|null}
		 */
		FastClick.prototype.findControl = function(labelElement) {
	
			// Fast path for newer browsers supporting the HTML5 control attribute
			if (labelElement.control !== undefined) {
				return labelElement.control;
			}
	
			// All browsers under test that support touch events also support the HTML5 htmlFor attribute
			if (labelElement.htmlFor) {
				return document.getElementById(labelElement.htmlFor);
			}
	
			// If no for attribute exists, attempt to retrieve the first labellable descendant element
			// the list of which is defined here: http://www.w3.org/TR/html5/forms.html#category-label
			return labelElement.querySelector(
				'button, input:not([type=hidden]), keygen, meter, output, progress, select, textarea'
			);
		};
	
	
		/**
		 * On touch end, determine whether to send a click event at once.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onTouchEnd = function(event) {
			var forElement, trackingClickStart, targetTagName, scrollParent, touch,
				targetElement = this.targetElement;
	
			if (!this.trackingClick) {
				return true;
			}
	
			// Prevent phantom clicks on fast double-tap (issue #36)
			if ((event.timeStamp - this.lastClickTime) < this.tapDelay) {
				this.cancelNextClick = true;
				return true;
			}
	
			if ((event.timeStamp - this.trackingClickStart) > this.tapTimeout) {
				return true;
			}
	
			// Reset to prevent wrong click cancel on input (issue #156).
			this.cancelNextClick = false;
	
			this.lastClickTime = event.timeStamp;
	
			trackingClickStart = this.trackingClickStart;
			this.trackingClick = false;
			this.trackingClickStart = 0;
	
			// On some iOS devices, the targetElement supplied with the event is invalid if the layer
			// is performing a transition or scroll, and has to be re-detected manually. Note that
			// for this to function correctly, it must be called *after* the event target is checked!
			// See issue #57; also filed as rdar://13048589 .
			if (deviceIsIOSWithBadTarget) {
				touch = event.changedTouches[0];
	
				// In certain cases arguments of elementFromPoint can be negative, so prevent setting targetElement to null
				targetElement = document.elementFromPoint(touch.pageX - window.pageXOffset,
					touch.pageY - window.pageYOffset) || targetElement;
				targetElement.fastClickScrollParent = this.targetElement.fastClickScrollParent;
			}
	
			targetTagName = targetElement.tagName.toLowerCase();
			if (targetTagName === 'label') {
				forElement = this.findControl(targetElement);
				if (forElement) {
					this.focus(targetElement);
					if (deviceIsAndroid) {
						return false;
					}
	
					targetElement = forElement;
				}
			} else if (this.needsFocus(targetElement)) {
	
				// Case 1: If the touch started a while ago (best guess is 100ms based on tests for issue #36) then focus will be triggered anyway. Return early and unset the target element reference so that the subsequent click will be allowed through.
				// Case 2: Without this exception for input elements tapped when the document is contained in an iframe, then any inputted text won't be visible even though the value attribute is updated as the user types (issue #37).
				if ((event.timeStamp - trackingClickStart) > 100 || (deviceIsIOS && window
						.top !== window && targetTagName === 'input')) {
					this.targetElement = null;
					return false;
				}
	
				this.focus(targetElement);
				this.sendClick(targetElement, event);
	
				// Select elements need the event to go through on iOS 4, otherwise the selector menu won't open.
				// Also this breaks opening selects when VoiceOver is active on iOS6, iOS7 (and possibly others)
				if (!deviceIsIOS || targetTagName !== 'select') {
					this.targetElement = null;
					event.preventDefault();
				}
	
				return false;
			}
	
			if (deviceIsIOS && !deviceIsIOS4) {
	
				// Don't send a synthetic click event if the target element is contained within a parent layer that was scrolled
				// and this tap is being used to stop the scrolling (usually initiated by a fling - issue #42).
				scrollParent = targetElement.fastClickScrollParent;
				if (scrollParent && scrollParent.fastClickLastScrollTop !== scrollParent.scrollTop) {
					return true;
				}
			}
	
			// Prevent the actual click from going though - unless the target node is marked as requiring
			// real clicks or if it is in the whitelist in which case only non-programmatic clicks are permitted.
			if (!this.needsClick(targetElement)) {
				event.preventDefault();
				this.sendClick(targetElement, event);
			}
	
			return false;
		};
	
	
		/**
		 * On touch cancel, stop tracking the click.
		 *
		 * @returns {void}
		 */
		FastClick.prototype.onTouchCancel = function() {
			this.trackingClick = false;
			this.targetElement = null;
		};
	
	
		/**
		 * Determine mouse events which should be permitted.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onMouse = function(event) {
	
			// If a target element was never set (because a touch event was never fired) allow the event
			if (!this.targetElement) {
				return true;
			}
	
			if (event.forwardedTouchEvent) {
				return true;
			}
	
			// Programmatically generated events targeting a specific element should be permitted
			if (!event.cancelable) {
				return true;
			}
	
			// Derive and check the target element to see whether the mouse event needs to be permitted;
			// unless explicitly enabled, prevent non-touch click events from triggering actions,
			// to prevent ghost/doubleclicks.
			if (!this.needsClick(this.targetElement) || this.cancelNextClick) {
	
				// Prevent any user-added listeners declared on FastClick element from being fired.
				if (event.stopImmediatePropagation) {
					event.stopImmediatePropagation();
				} else {
	
					// Part of the hack for browsers that don't support Event#stopImmediatePropagation (e.g. Android 2)
					event.propagationStopped = true;
				}
	
				// Cancel the event
				event.stopPropagation();
				event.preventDefault();
	
				return false;
			}
	
			// If the mouse event is permitted, return true for the action to go through.
			return true;
		};
	
	
		/**
		 * On actual clicks, determine whether this is a touch-generated click, a click action occurring
		 * naturally after a delay after a touch (which needs to be cancelled to avoid duplication), or
		 * an actual click which should be permitted.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onClick = function(event) {
			var permitted;
	
			// It's possible for another FastClick-like library delivered with third-party code to fire a click event before FastClick does (issue #44). In that case, set the click-tracking flag back to false and return early. This will cause onTouchEnd to return early.
			if (this.trackingClick) {
				this.targetElement = null;
				this.trackingClick = false;
				return true;
			}
	
			// Very odd behaviour on iOS (issue #18): if a submit element is present inside a form and the user hits enter in the iOS simulator or clicks the Go button on the pop-up OS keyboard the a kind of 'fake' click event will be triggered with the submit-type input element as the target.
			if (event.target.type === 'submit' && event.detail === 0) {
				return true;
			}
	
			permitted = this.onMouse(event);
	
			// Only unset targetElement if the click is not permitted. This will ensure that the check for !targetElement in onMouse fails and the browser's click doesn't go through.
			if (!permitted) {
				this.targetElement = null;
			}
	
			// If clicks are permitted, return true for the action to go through.
			return permitted;
		};
	
	
		/**
		 * Remove all FastClick's event listeners.
		 *
		 * @returns {void}
		 */
		FastClick.prototype.destroy = function() {
			var layer = this.layer;
	
			if (deviceIsAndroid) {
				layer.removeEventListener('mouseover', this.onMouse, true);
				layer.removeEventListener('mousedown', this.onMouse, true);
				layer.removeEventListener('mouseup', this.onMouse, true);
			}
	
			layer.removeEventListener('click', this.onClick, true);
			layer.removeEventListener('touchstart', this.onTouchStart, false);
			layer.removeEventListener('touchmove', this.onTouchMove, false);
			layer.removeEventListener('touchend', this.onTouchEnd, false);
			layer.removeEventListener('touchcancel', this.onTouchCancel, false);
		};
	
	
		/**
		 * Check whether FastClick is needed.
		 *
		 * @param {Element} layer The layer to listen on
		 */
		FastClick.notNeeded = function(layer) {
			var metaViewport;
			var chromeVersion;
			var blackberryVersion;
			var firefoxVersion;
	
			// Devices that don't support touch don't need FastClick
			if (typeof window.ontouchstart === 'undefined') {
				return true;
			}
	
			// Chrome version - zero for other browsers
			chromeVersion = +(/Chrome\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[1];
	
			if (chromeVersion) {
	
				if (deviceIsAndroid) {
					metaViewport = document.querySelector('meta[name=viewport]');
	
					if (metaViewport) {
						// Chrome on Android with user-scalable="no" doesn't need FastClick (issue #89)
						if (metaViewport.content.indexOf('user-scalable=no') !== -1) {
							return true;
						}
						// Chrome 32 and above with width=device-width or less don't need FastClick
						if (chromeVersion > 31 && document.documentElement.scrollWidth <= window
							.outerWidth) {
							return true;
						}
					}
	
					// Chrome desktop doesn't need FastClick (issue #15)
				} else {
					return true;
				}
			}
	
			if (deviceIsBlackBerry10) {
				blackberryVersion = navigator.userAgent.match(
					/Version\/([0-9]*)\.([0-9]*)/);
	
				// BlackBerry 10.3+ does not require Fastclick library.
				// https://github.com/ftlabs/fastclick/issues/251
				if (blackberryVersion[1] >= 10 && blackberryVersion[2] >= 3) {
					metaViewport = document.querySelector('meta[name=viewport]');
	
					if (metaViewport) {
						// user-scalable=no eliminates click delay.
						if (metaViewport.content.indexOf('user-scalable=no') !== -1) {
							return true;
						}
						// width=device-width (or less than device-width) eliminates click delay.
						if (document.documentElement.scrollWidth <= window.outerWidth) {
							return true;
						}
					}
				}
			}
	
			// IE10 with -ms-touch-action: none or manipulation, which disables double-tap-to-zoom (issue #97)
			if (layer.style.msTouchAction === 'none' || layer.style.touchAction ===
				'manipulation') {
				return true;
			}
	
			// Firefox version - zero for other browsers
			firefoxVersion = +(/Firefox\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[
				1];
	
			if (firefoxVersion >= 27) {
				// Firefox 27+ does not have tap delay if the content is not zoomable - https://bugzilla.mozilla.org/show_bug.cgi?id=922896
	
				metaViewport = document.querySelector('meta[name=viewport]');
				if (metaViewport && (metaViewport.content.indexOf('user-scalable=no') !==
						-1 || document.documentElement.scrollWidth <= window.outerWidth)) {
					return true;
				}
			}
	
			// IE11: prefixed -ms-touch-action is no longer supported and it's recomended to use non-prefixed version
			// http://msdn.microsoft.com/en-us/library/windows/apps/Hh767313.aspx
			if (layer.style.touchAction === 'none' || layer.style.touchAction ===
				'manipulation') {
				return true;
			}
	
			return false;
		};
	
	
		/**
		 * Factory method for creating a FastClick object
		 *
		 * @param {Element} layer The layer to listen on
		 * @param {Object} [options={}] The options to override the defaults
		 */
		FastClick.attach = function(layer, options) {
			return new FastClick(layer, options);
		};
	
	
		// if (typeof define === 'function' && define.cmd) {
		// 	define(function(require, exports, module) {
		// 		module.exports = FastClick;
		// 	});
		// } else {
		// 	window.FastClick = FastClick;
		// }
		module.exports = FastClick;
	}());


/***/ }),
/* 20 */,
/* 21 */,
/* 22 */,
/* 23 */,
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, e, module) {
	    var qs = function() {return document.querySelector.apply(document, arguments)};
	
	    var $error = qs('#error'),
	        $errorMsg = qs('#error_msg'),
	        $subTit = qs('#error_subtit'),
	        $retry = qs('#retry');
	
	    var defer;
	
	    var listener = function() {
	        defer.resolve();
	        $retry.removeEventListener('click', listener);
	        $error.style.display = 'none';
	    };
	
	    module.exports = function(msg, btnTxt, subTit, def) {
	        defer = def || $.Deferred();
	        $errorMsg.textContent = msg;
	        $retry.textContent = btnTxt;
	        subTit && ($subTit.textContent = subTit);
	        $error.style.display = 'block';
	        $retry.addEventListener('click', listener);
	        return typeof defer.promise == 'function' ? defer.promise() : defer.promise;
	    };
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),
/* 25 */,
/* 26 */,
/* 27 */,
/* 28 */,
/* 29 */,
/* 30 */,
/* 31 */,
/* 32 */,
/* 33 */,
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function(r, e, module) {
		var $toast = $('#toast'),
			$msg = $toast.find('p'),
			timer;
	
		module.exports = function(msg) {
	        $msg.text(msg);
			$toast.show();
			if (timer) {
				clearTimeout(timer);
			}
			timer = setTimeout(function() {
				$toast.hide();
			}, 2000);
		};
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),
/* 35 */,
/* 36 */,
/* 37 */,
/* 38 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, e, module) {
	    var $loading = document.querySelector('#loading');
	
	    module.exports = {
	        loaded: function loaded() {
	            $loading.style.display = 'none';
	        },
	        loading: function loading() {
	            $loading.style.display = 'block';
	        }
	    };
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),
/* 39 */,
/* 40 */,
/* 41 */,
/* 42 */,
/* 43 */
/***/ (function(module, exports) {

	function doAjax(param, suc, fail) {
		$.ajax({
			url: 'https://ticketapi.video.qq.com/wireless_seat_list?otype=json',
			dataType: 'jsonp',
			data: $.extend({
				c_cinema_id: 0,
				c_id: 0,
				c_roomid: 0,
				c_showid: 0
			}, param),
			success: function(ret) {
				if (ret.retcode == '0') {
					suc(ret);
				} else {
					fail(ret);
				}
			},
			error: function (ret) {
				fail(ret);
			}
		});
	}
	
	module.exports = function(param) {
		var def = $.Deferred();
		doAjax(param, function(ret) {
			def.resolve(ret);
		}, function() {
			//retry
			doAjax(param, function(ret) {
				def.resolve(ret);
			}, function(ret) {
				def.reject(ret);
			});
		});
		return def;
	};


/***/ }),
/* 44 */
/***/ (function(module, exports) {

	/**
	 * 我已经想不起来为什么要复制一遍module/tvcookie而不是直接诶require了。。
	 */
	module.exports = function () {
		var def = $.Deferred();
	
		QQVideoBridge.getCookie({type: ["tv"]})
			.then(function (res) {
				if (res.state == 0) {
					var tvcookie = res.data.result.tv,
						reg = /vuserid=(\d+)\;vusession=(\w+)\;/;
					reg.test(tvcookie);
					def.resolve({
						vuserid: RegExp.$1,
						vusession: RegExp.$2
					})
				} else {
					def.reject("js bridge is not available");
				}
			})
			.fail(function () {
				def.reject('get user info failed');
			});
	
		return def;
	};

/***/ }),
/* 45 */
/***/ (function(module, exports) {

	
	function doAjax(param, suc, fail) {
		$.ajax({
			url: 'https://ticketapi.video.qq.com/wireless_schedule_info?otype=json',
			dataType: 'jsonp',
			data: $.extend({
				c_cinema_id: 0,
				c_id: 0,
				c_roomid: 0,
				c_showid: 0,
				theater_id: '',
				film_id: '',
				date: '',
				time: ''
			}, param),
			success: function(ret) {
				if (ret.retcode == '0') {
					suc(ret);
				} else {
					fail(ret);
				}
			},
			error: function (ret) {
				fail(ret);
			}
		});
	}
	
	module.exports = function(param) {
		var def = $.Deferred();
		doAjax(param, function(ret) {
			def.resolve(ret);
		}, function() {
			//retry
			doAjax(param, function(ret) {
				def.resolve(ret);
			}, function(ret) {
				def.reject(ret);
			});
		});
		return def;
	};


/***/ }),
/* 46 */
/***/ (function(module, exports) {

	/**
	*/
	function seatList(param) {
		var def = $.Deferred();
		$.ajax({
			url: "https://ticketapi.video.qq.com/wireless_check_order_unpay?otype=json",
			data: param,
			dataType: "jsonp"
		}).done(function (res) {
			if (res.retcode == '0') {
				def.resolve(res.order_id);
			}
		}).fail(function () {
			def.reject();
		});
		return def.promise();
	}
	
	module.exports = seatList;

/***/ }),
/* 47 */
/***/ (function(module, exports) {

	function cgi(param) {
		var def = $.Deferred();
		$.ajax({
			url: "https://ticketapi.video.qq.com/wireless_order_cancel?otype=json",
			data: param,
			dataType: "jsonp"
		}).done(function (res) {
			if (res.retcode == '0') {
				def.resolve(res);
			} else {
				def.reject();
			}
		}).fail(function () {
			def.reject();
		});
		return def.promise();
	}
	
	module.exports = cgi;

/***/ }),
/* 48 */
/***/ (function(module, exports) {

	function cgi(param) {
		var def = $.Deferred();
		$.ajax({
			url: "https://ticketapi.video.qq.com/get_discount?otype=json",
			data: param,
			dataType: "jsonp"
		}).done(function (res) {
			if (res.retcode == '0') {
				def.resolve(res);
			} else {
				def.reject();
			}
		}).fail(function () {
			def.reject();
		});
		return def.promise();
	}
	
	module.exports = cgi;

/***/ }),
/* 49 */
/***/ (function(module, exports) {

	/**
	* @author zombieyang
	* @create 2015/4/21.
	* 反正把跟单个座位有关的东西丢这里吧呵呵
	* copy自PC电影购票
	* 由于zepto的$.data接口与jquery不一致,此处zepto元素存的是VM的key 'row|col'
	*/
	var cons = function ($el) {
		this.$el = $el;
		this.id = null;
		this.flag = 0;
		this.status = 2;
		this.row = -1;
		this.col = -1;
		this.checked = false;
	
		this.$el.data('_vm', [this.row, this.col].join('|'));
		this.$ticket = null;
	
		this.partner = null;// 情侣座的关联座位
	};
	cons.FLAG = {
		0: ''//普通座位
		, 1: ''//恩爱狗座位
		, 2: ''//恩爱狗的另一只座位
	};
	cons.STATUS = {
		0: ''//可售卖
		, 1: ''//不可售卖
		, 2: ''//没有这个座位
	};
	cons.prototype.setParam = function (param) {
		var self = this;
		$.each(['id', 'row', 'col', 'name'], function (i, v) {
			self[v] = param[v] || self[v];
		});
		if (this.name && this.name.indexOf(':') != -1) {
			this.name = this.name.split(':');
			this.name = this.name[0] + '排' + this.name[1] + '座';
		}
		this.$el.data('_vm', [this.row, this.col].join('|'));
		return this;
	};
	cons.prototype.setFlag = function (flag, partnerVM) {
		this.flag = flag;
		this.renderFlag();
		this.partner = partnerVM || null;
		partnerVM && (partnerVM.partner = this);
	
		return this;
	};
	cons.prototype.renderFlag = function() {
	
	};
	cons.prototype.setStatus = function (status) {
		this.status = status;
		this.renderStatus();
	
		return this;
	};
	cons.prototype.renderStatus = function () {
		if (this.status == 2) {
			this.$el.attr('class', 'seat_empty');
			this.$el.find('i').hide();
		} else if (this.status == 1) {
			this.$el.attr('class', 'seat_saled');
			this.$el.find('i').css('display', 'inline-block');
		} else {
			if (this.flag != 0) {
				this.$el.attr('class', 'seat_lover');
				this.$el.find('i').css('display', 'inline-block');
			} else {
				this.$el.attr('class', 'seat_normal');
				this.$el.find('i').css('display', 'inline-block');
			}
		}
		return this;
	};
	cons.prototype.renderChecked = function () {
		if (this.checked) {
			this.$el.addClass('seat_select seat_selected');
		} else {
			this.$el.removeClass('seat_select seat_selected');
		}
	};
	cons.prototype.check = function (c) {
		if (this.status == '0') {
			this.checked = typeof c == 'undefined' ? !this.checked : c;
			if (this.partner) {
				this.partner.checked = this.checked;
				this.partner.renderChecked();
			}
			this.renderChecked();
		}
		return this.checked;
	};
	cons.prototype.get$ticket = function () {
		this.$ticket = $('<span class="inner">' + this.name + '</span><span class="btn_close">×</span>');
		return this.$ticket;
	};
	
	module.exports = cons;


/***/ }),
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

	var Toast = __webpack_require__(34);
	var txvuserCookie = __webpack_require__(44);
	var def;
	
	var $verifyPop = $('#verify_phone'),
		$getBtn = $('#getbtn'),
		$phone = $('#phone'),
		$code = $('#code'),
		$confirm = $('#verify'),
		sent = false,
		cooldown = 0,
		timer = null;
	
	function verifyPhone() {
		var phone = $phone.val();
		return phone.match(/^\d{11}$/);
	}
	$getBtn.click(function(e) {
		e.preventDefault();
		if ($getBtn.hasClass('btn_forbid')) {
			return false;
		}
		if (verifyPhone()) {
			txvuserCookie().then(function(res) {
				$.ajax({
					url: 'https://ticketapi.video.qq.com/get_code',
					data: $.extend({
						otype: 'json',
						from: 1,
						phone: $phone.val()
					}, res),
					dataType: 'jsonp',
					success: function() {
						sent = true;
					}
				});
			});
	
			$getBtn.addClass('btn_forbid');
			cooldown = 30;
			timer = setInterval(function() {
				if (--cooldown === 0) {
					clearInterval(timer);
					$getBtn.removeClass('btn_forbid').val('重新发送');
				} else {
					$getBtn.val(cooldown + '秒');
				}
			}, 1000);
		} else {
			$phone.addClass('notice_error');
			Toast('请输入正确的手机号');
		}
		return false;
	});
	$phone.on('input', function() {
		$phone.removeClass('notice_error');
	
		if ($code.val().length == 6 && verifyPhone()) {
			$confirm.removeClass('btn_forbid');
		} else {
			$confirm.addClass('btn_forbid');
		}
	});
	$code.on('input', function() {
		$code.removeClass('notice_error');
	
		if ($code.val().length == 6 && verifyPhone()) {
			$confirm.removeClass('btn_forbid');
		} else {
			$confirm.addClass('btn_forbid');
		}
	});
	$confirm.on('click', function(e) {
		if ($confirm.hasClass('btn_forbid')) {
			return false;
		}
		e.preventDefault();
		var code = $code.val();
		txvuserCookie().then(function(res) {
			var phoneNum = $phone.val();
			$.ajax({
				url: 'https://ticketapi.video.qq.com/check_code',
				data: $.extend({
					from: 1,
					phone: phoneNum,
					vcode: code,
					otype: 'json'
				}, res),
				dataType: 'jsonp',
				success: function(e) {
					if (e.retcode == '0') {
						def.resolve(phoneNum);
						location.hash = '';
					} else if (e.retcode == '1') { //验证码错误
						$code.addClass('notice_error');
						Toast('请先获取验证码');
					} else if (e.retcode == '2') { //验证码错误
						$code.addClass('notice_error');
						Toast('验证码错误！');
					}
				}
			});
		});
		return false;
	});
	
	function onHashChange() {
		if (location.hash == '#verify') {
			$verifyPop.show();
			$('#choose_seat').hide();
		} else {
			$verifyPop.hide();
			$('#choose_seat').show();
		}
	}
	window.addEventListener('hashchange', onHashChange);
	
	module.exports = function(phone) {
		def = $.Deferred();
		$phone.val(phone);
		location.hash = '#verify';
		return def;
	};

/***/ })
/******/ ]);