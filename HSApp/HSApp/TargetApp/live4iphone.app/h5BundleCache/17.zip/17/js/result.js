/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	var boss = __webpack_require__(2);
	boss.delegate('app_v_result');
	var userDef = QQVideoBridge.getCookie({type:["tv"]}),
	    getDetail = __webpack_require__(29),
	    order_id = $.util.getUrlParam("order_id"),
	    forceSuccess = $.util.getUrlParam("success")==1;
	
	var template = __webpack_require__(9);
	template.helper("https", function (url) {
	    return url.replace ? url.replace('http', 'https') : url;
	});
	
	window.onerror = function (err) {
	    var s =  Array.apply(null,arguments);
	    $("#log").append("windowerror:"+JSON.stringify(s)+"<br/>")
	}
	
	function getStatus(){
	    userDef.done(function(res){
	        console.log(res)
	
	        if(res.state==0){
	            var tvcookie = res.data.result.tv,
	                reg = /vuserid=(\d+)\;vusession=(\w+)\;/;
	            reg.test(tvcookie);
	            var data = {
	                vuserid: RegExp.$1,
	                vusession :RegExp.$2,
	                order_id : order_id
	            };
	            getData(data);
	        }
	        else{
	            console.log("js bridge is not available")
	        }
	    }).fail(function(){
	        alert("get user info failed")
	    });
	}
	
	var result = {
	    paysuc: function (res) {
	        var tpl = __webpack_require__(35),
	            json = {
	                title:"支付成功",
	                msg : "正在为你出票，出票结果将短信通知你。"
	            };
	        return tpl(json);
	    },
	    payerr: function (res) {
	        var tpl = __webpack_require__(36),
	            json = {
	                title : res.c_name+" 支付失败",
	                msg : res.c_name+"支付失败，请重新返回购票界面进行购票。"
	            };
	        return tpl(json);
	    },
	    cancel: function (res) {
	        var tpl = __webpack_require__(36),
	            json = {
	                title : "订单不存在或已取消",
	                msg : "订单不存在或已取消，请重新返回购票界面进行购票。"
	            };
	        return (tpl(json));
	    },
	    ticketerr: function (res) {
	        var tpl = __webpack_require__(36),
	            json = {
	                title : res.c_name+" 出票失败",
	                msg : "之前购票的款项会在3-7个工作日返还到您的支付账户中。"
	            };
	        return tpl(json);
	    },
	    ticketsuc: function (res) {
	        var tpl = __webpack_require__(37);
	        res.c_exchangecode = res.c_exchangecode.replace(/(\w+)/,"<span class=\"strong code\">$1<\/span>");
	       return tpl(res);
	    },
	    notpay: function (res) {
	        var tpl = __webpack_require__(36),
	            json = {
	                title : res.c_name+" 订单还未支付",
	                msg : "电影票还未支付，请重新返回购票界面进行购票。"
	            };
	        return tpl(json);
	    },
	    timeout: function (res) {
	        var tpl = __webpack_require__(36),
	            json = {
	                title : res.c_name+" 订单已经过期",
	                msg : "已超过支付时间，请重新下单。"
	            };
	        return tpl(json);
	    },
	    cgierr: (function () {
	        var retry = 0, max = 3;
	        return function (res) {
	            ++retry < max ? setTimeout(function () {
	                getStatus(res);
	            }, 1000) : result.showError('网络不通，请稍后再试');
	        }
	    })(),
	    showError : function(){
	        var tpl = __webpack_require__(36),
	            json = {
	                title : " 订单查询失败了",
	                msg : "服务出了点问题，请您一会儿再刷新查询。"
	            };
	        return tpl(json);
	    }
	};
	
	
	function getData(param){
	    getDetail(param).done(function(res){
	
	       try {
	
	           $("#log").append("data from cgi:" + JSON.stringify(res));
	
	           if (res.price) {
	               res.price = (res.price / 100).toFixed(2);
	           }
	           if ($.util.getUrlParam('trade_status') == "TRADE_SUCCESS" || $.util.getUrlParam('trade_state') == "0") {
	               result.paysuc(res);
	               return;
	           }
	           var html = "";
	           switch (res.status) {
	               case 1://未支付
	                   if(forceSuccess){
	                       html = result.paysuc(res);
	                   }
	                   else{
	                       html = result.notpay(res);
	                   }
	                   break;
	               case 2://已支付
	                   html = result.paysuc(res);
	                   break;
	               case 3://出票成功
	                   html = result.ticketsuc(res);
	                   break;
	               case 4://出票失败
	                   html = result.ticketerr(res);
	                   break;
	               case 5://订单取消
	                   html = result.cancel(res);
	                   //by zombie 取消掉的订单后台不会给数据，所以要直接结束渲染流程
	                   $(document.body).append(html);
	                   return;
	               case 100://订单超时
	                   html = result.timeout(res);
	                   break;
	               default:
	                   html = result.cgierr(res);
	                   break;
	           }
	           var theater_info = __webpack_require__(31),
	               plat_info = __webpack_require__(33);
	           html += theater_info(res);
	           html += plat_info(res);
	           $(document.body).append(html);
	       }catch (e){
	           alert(e)
	       }
	    }).fail(function (res) {
	        //if ($j.util.getUrlParam('trade_status') == "TRADE_SUCCESS") {
	        //	//todo 出票成功但是拿后台票据信息失败
	        //	result.paysuc(res);
	        if (res && res.retcode == -11) {//未登录
	            openLogin();
	        } else if (res && res.retcode == 4) {//参数错误
	            result.cancel(res);
	        } else {
	            result.cgierr()
	        }
	    }).fail(function(err){
	        var error = __webpack_require__(24),
	            def = error("获取数据失败了","点击重新获取","");
	        def.done(function(){
	            $("#loading").show();
	            getData(param);
	        });
	    }).always(function(){
	        $("#loading").hide();
	    })
	}
	
	function openLogin(){
	    QQVideoBridge.loginTv().done(function(res){
	        var msgtit = "",
	            btnTxt = "点击登录";
	        if(res && res.data){
	            if(res.data.errCode == 2){
	                msgtit = "需要登录才能进行查询";
	                //用户取消登录
	            }
	            else if(res.data.errCode == 1){
	                msgtit = "登录失败了，需要登录才能进行查询";
	                btnTxt = "点击重新登录"
	                //登录失败
	            }
	            else if(res.data.errCode ==0){
	                location.reload();
	                return;
	            }
	        }
	        var error = __webpack_require__(24),
	            def = error(msgtit,btnTxt,"");
	        def.done(openLogin);
	    })
	}
	
	getStatus();
	QQVideoBridge.setMoreInfo({"hasRefresh":true, "hasShare":false, "hasFollow":false});


/***/ }),
/* 1 */,
/* 2 */
/***/ (function(module, exports) {

	// http://tapd.oa.com/tvideo/prong/stories/view/1010031991056992805?url_cache_key=dc4c5bdd3ef3797a13e788c323168a6f&action_entry_type=story_tree_list
	var sessionStorage = window.sessionStorage || {
			getItem: function () {
			}, setItem: function () {
			}, removeItem: function () {
			}
		};
	var base_url = "https://btrace.qq.com/kvcollect?BossId=3243&Pwd=1546101498&plat=1&ua=" + navigator.userAgent + "&_dc=" + Math.random();
	var ref;
	
	
	//播放页来源
	if (location.href.indexOf('app.package.play') != -1) {
		sessionStorage.setItem('piao-ref', ref = 11);
	} else if (location.href.indexOf('app.package.user') != -1 || location.href.indexOf('app.package.channel') != -1) {
		sessionStorage.setItem('piao-ref', ref = 12);
	} else {
		ref = sessionStorage.getItem('piao-ref') || 12;
	}
	base_url += '&ref=' + ref;
	
	var exp = function (event, cid) {
		var g_btrace_BOSS = new Image(1, 1);
		g_btrace_BOSS.src = base_url + '&event=' + event + (cid ? ('&cid=' + cid) : '');
	};
	exp.delegate = function (event) {
		var $ = window.jQuery || window.Zepto;
		exp(event);//pv
		$(document.body).on('click', '[_boss]', function (e) {
			exp($(e.currentTarget).attr('_boss'));
		});
	};
	module.exports = exp;

/***/ }),
/* 3 */,
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */
/***/ (function(module, exports) {

	/*TMODJS:{}*/
	!function () {
		function a(a, b) {
			return (/string|function/.test(typeof b) ? h : g)(a, b)
		}
	
		function b(a, c) {
			return "string" != typeof a && (c = typeof a, "number" === c ? a += "" : a = "function" === c ? b(a.call(a)) : ""), a
		}
	
		function c(a) {
			return l[a]
		}
	
		function d(a) {
			return b(a).replace(/&(?![\w#]+;)|[<>"']/g, c)
		}
	
		function e(a, b) {
			if (m(a))for (var c = 0, d = a.length; d > c; c++)b.call(a, a[c], c, a); else for (c in a)b.call(a, a[c], c)
		}
	
		function f(a, b) {
			var c = /(\/)[^\/]+\1\.\.\1/, d = ("./" + a).replace(/[^\/]+$/, ""), e = d + b;
			for (e = e.replace(/\/\.\//g, "/"); e.match(c);)e = e.replace(c, "/");
			return e
		}
	
		function g(b, c) {
			var d = a.get(b) || i({filename: b, name: "Render Error", message: "Template not found"});
			return c ? d(c) : d
		}
	
		function h(a, b) {
			if ("string" == typeof b) {
				var c = b;
				b = function () {
					return new k(c)
				}
			}
			var d = j[a] = function (c) {
				try {
					return new b(c, a) + ""
				} catch (d) {
					return i(d)()
				}
			};
			return d.prototype = b.prototype = n, d.toString = function () {
				return b + ""
			}, d
		}
	
		function i(a) {
			var b = "{Template Error}", c = a.stack || "";
			if (c)c = c.split("\n").slice(0, 2).join("\n"); else for (var d in a)c += "<" + d + ">\n" + a[d] + "\n\n";
			return function () {
				return "object" == typeof console && console.error(b + "\n\n" + c), b
			}
		}
	
		var j = a.cache = {}, k = this.String, l = {
			"<": "&#60;",
			">": "&#62;",
			'"': "&#34;",
			"'": "&#39;",
			"&": "&#38;"
		}, m = Array.isArray || function (a) {
				return "[object Array]" === {}.toString.call(a)
			}, n = a.utils = {
			$helpers: {}, $include: function (a, b, c) {
				return a = f(c, a), g(a, b)
			}, $string: b, $escape: d, $each: e
		}, o = a.helpers = n.$helpers;
		a.get = function (a) {
			return j[a.replace(/^\.\//, "")]
		}, a.helper = function (a, b) {
			o[a] = b
		}, module.exports = a
	}();

/***/ }),
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */,
/* 14 */,
/* 15 */,
/* 16 */,
/* 17 */,
/* 18 */,
/* 19 */,
/* 20 */,
/* 21 */,
/* 22 */,
/* 23 */,
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, e, module) {
	    var qs = function() {return document.querySelector.apply(document, arguments)};
	
	    var $error = qs('#error'),
	        $errorMsg = qs('#error_msg'),
	        $subTit = qs('#error_subtit'),
	        $retry = qs('#retry');
	
	    var defer;
	
	    var listener = function() {
	        defer.resolve();
	        $retry.removeEventListener('click', listener);
	        $error.style.display = 'none';
	    };
	
	    module.exports = function(msg, btnTxt, subTit, def) {
	        defer = def || $.Deferred();
	        $errorMsg.textContent = msg;
	        $retry.textContent = btnTxt;
	        subTit && ($subTit.textContent = subTit);
	        $error.style.display = 'block';
	        $retry.addEventListener('click', listener);
	        return typeof defer.promise == 'function' ? defer.promise() : defer.promise;
	    };
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),
/* 25 */,
/* 26 */,
/* 27 */,
/* 28 */,
/* 29 */
/***/ (function(module, exports) {

	
	function getData(data,def,isretry){
	    $.ajax({
	        url: "https://ticketapi.video.qq.com/wireless_order_status?otype=json",
	        data : data,
	        timeout : 120000,
	        dataType: "jsonp"
	    }).done(function(res) {
	        if (res.retcode == 0) {
	            def.resolve(res);
	        }
	        else{
	            if(!isretry){
	                getData(data,def,true)
	            }
	            else{
	                def.reject(res);
	            }
	        }
	    }).fail(function(res) {
	        if(!isretry){
	            getData(data,def,true)
	        }
	        else{
	            def.reject(res);
	        }
	    });
	}
	
	/**
	 *
	 * @param data {vuserid:xx,vusession:x,order_id:xx}
	 * @returns {*|Object}
	 */
	module.exports = function(data){
	    var def = $.Deferred();
	    getData(data,def);
	    return def.promise();
	};

/***/ }),
/* 30 */,
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

	
	var theater_info = __webpack_require__(32);
	module.exports = function(data){
	    if (data.seats) {
	        data.seats = data.seats.split("、");
	    }
	    return theater_info(data);
	};


/***/ }),
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

	var template=__webpack_require__(9);
	module.exports=template('tpl/result/theater_info',function($data,$filename
	/*``*/) {
	'use strict';var $utils=this,$helpers=$utils.$helpers,$escape=$utils.$escape,film_poster=$data.film_poster,film_name=$data.film_name,theater_name=$data.theater_name,film_date=$data.film_date,film_time=$data.film_time,theater_addr=$data.theater_addr,recv_phone=$data.recv_phone,$each=$utils.$each,seats=$data.seats,seat=$data.seat,$index=$data.$index,$out='';$out+='<ul class="ticket_list"> <li class="item"> <div class="figure_ticket"> <a href="javascript:;" class="figure"><img alt="" src="';
	$out+=$escape($helpers. https(film_poster ));
	$out+='"></a> <h5 class="title">';
	$out+=$escape(film_name);
	$out+='</h5> <p class="txt">';
	$out+=$escape(theater_name);
	$out+=' ';
	$out+=$escape(film_date.substr(5));
	$out+=' ';
	$out+=$escape(film_time);
	$out+='</p> <p class="txt">';
	$out+=$escape(theater_addr);
	$out+='</p> <p class="txt">接收兑换码手机号：';
	$out+=$escape(recv_phone);
	$out+='</p> </div> <div class="item_btm">';
	$each(seats,function(seat,$index){
	$out+=' <a href="javascript:;" class="btn_simi">';
	$out+=$escape(seat);
	$out+='</a>';
	});
	$out+=' </div> </li> </ul>';
	return new String($out);
	});

/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

	var template=__webpack_require__(9);
	module.exports=template('tpl/result/plat_info',function($data,$filename
	/*``*/) {
	'use strict';var $utils=this,$helpers=$utils.$helpers,$escape=$utils.$escape,c_name=$data.c_name,c_phone=$data.c_phone,$out='';$out+='<section class="ticket_explain"> <p class="txt">票由';
	$out+=$escape(c_name);
	$out+='提供，支付后不可退换。</p> <p class="txt">客服电话：</p> <a class="strong" href="tel:';
	$out+=$escape(c_phone);
	$out+='">';
	$out+=$escape(c_phone);
	$out+='</a> </section>';
	return new String($out);
	});

/***/ }),
/* 34 */,
/* 35 */
/***/ (function(module, exports, __webpack_require__) {

	var template=__webpack_require__(9);
	module.exports=template('tpl/result/success',function($data,$filename
	/*``*/) {
	'use strict';var $utils=this,$helpers=$utils.$helpers,$escape=$utils.$escape,title=$data.title,msg=$data.msg,$out='';$out+='<div class="section_board"> <section class="payment_status status_success"> <i class="icon_success_lg"></i> <h6 class="title">';
	$out+=$escape(title);
	$out+='</h6> <p class="txt">';
	$out+=$escape(msg);
	$out+='</p> </section> </div>';
	return new String($out);
	});

/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

	var template=__webpack_require__(9);
	module.exports=template('tpl/result/error',function($data,$filename
	/*``*/) {
	'use strict';var $utils=this,$helpers=$utils.$helpers,$escape=$utils.$escape,title=$data.title,msg=$data.msg,$out='';$out+='<div class="section_board"> <section class="payment_status status_fail"> <i class="icon_fail_lg"></i> <h6 class="title">';
	$out+=$escape(title);
	$out+='</h6> <p class="txt">';
	$out+=$escape(msg);
	$out+='</p> </section> </div>';
	return new String($out);
	});

/***/ }),
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

	var template=__webpack_require__(9);
	module.exports=template('tpl/result/ticket_suc',function($data,$filename
	/*``*/) {
	'use strict';var $utils=this,$helpers=$utils.$helpers,$string=$utils.$string,c_exchangecode=$data.c_exchangecode,$out='';$out+='<div class="section_board"> <p class="board_info">';
	$out+=$string(c_exchangecode);
	$out+='</p> </div> ';
	return new String($out);
	});

/***/ })
/******/ ]);