/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	var loadingPop = __webpack_require__(38);
	var errorPop = __webpack_require__(24);
	var confirmPop = __webpack_require__(5);
	var lruStorage = __webpack_require__(13)('h5piao', {limit: 20, maxAge: 10 * 60 * 1000});
	
	var ngModule = angular.module('mobileTicket', []);
	__webpack_require__(39)(ngModule);//修复jsonp
	__webpack_require__(40)(ngModule);//getUrlParam
	__webpack_require__(3).registerNgService(ngModule);//位置服务
	__webpack_require__(51).registerNgService(ngModule);//区域弹窗
	__webpack_require__(42)(ngModule, 'app_v_theater');
	
	var cityStorage = __webpack_require__(6),
		storage = cityStorage.get() || {};
	ngModule
		.filter('lbskm', function() {
			return function(m, lbsfail) {
				if (lbsfail || m == '') {
					m = '';
				} else {
					if (m > 1000) {
						m = (m / 1000).toFixed(1) + '公里';
					} else {
						m += '米';
					}
				}
				return m;
			};
		})
		.controller('theaterlist', ['$scope', '$http', '$getUrlParam', '$txvlbs', '$q', function($scope, $http, $getUrlParam, $txvlbs, $q) {
			$scope.$href = function(event) {
				location.href = angular.element(event.currentTarget).find('a')[0].href;
			};
			//model
			$scope.lbsfail = false;
			$scope.gps_city = '';
			$scope.gps_city_id = 0;
			$scope.city = '加载中..';
			$scope.area = '加载中..';
			$scope.area_id = storage.area_id || 0;
			$scope.city_id = storage.city_id || 0;
			$scope.available = [];
	
			$scope.film_id = 0;
	
			//摆个set方法也许会比较好，防止scope变量覆盖
			$scope.$setAreaId = function (id) {
				$scope.area_id = id;
			};
	
	
			var lastGeo = null;
			//获取影院列表
			$scope.$getTheaterList = function(geo) {
				geo = geo || lastGeo;
				lastGeo = geo;
				var fid = $getUrlParam('film_id');
	
				var param = {
					otype: 'json',
					city_id: $scope.city_id,
					area_id: $scope.area_id,
					lat: geo.lat,
					lng: geo.lng,
					film_id: fid
				};
	
				var cacheData = lruStorage.get('theater_list?cid=' + $scope.city_id + '&aid=' + $scope.area_id + '&fid=' + fid);
				if (cacheData) {
					_success(cacheData, false);
					_finally();
				}
	
				// $http服务发起ajax
				$http
					.jsonp('https://ticketapi.video.qq.com/wireless_theater_list?callback=JSON_CALLBACK', {
						params: param
					})
					.success(_success)
					.success(function(data) {
						lruStorage.set('theater_list?cid=' + param.city_id + '&aid=' + param.area_id + '&fid=' + fid, data);
					})
					.error(_error)
					.finally(_finally);
	
				function _success(data, httpCode) {
					if (data.retcode == '0') {
						$scope.gps_city = data.gps_city_nm || '定位失败';
						$scope.gps_city_id = data.gps_city_id || 0;
						$scope.city = data.city_nm;
						$scope.area = data.area_nm;
						$scope.city_id = data.city_id;
						$scope.area_id = data.area_id;
						$scope.available = data.results[fid].available;
						$scope.film_id = fid;
						if (data.area_infos) {
							$scope.areaInclude = {};
							data.area_infos.forEach(function(v) {
								$scope.areaInclude[v.area_id] = v.theater_num;
							});
						}
	
						if (httpCode) {
	
							//昨日城市
							var yesterdayCity = __webpack_require__(13)('yesterdayCity', {
								limit: 1,
								maxAge: 24 * 60 * 60 * 1000,
								useSession: false,
								onStale: function (item) {
									if (item.nm != data.gps_city_nm) {
										confirmPop('系统定位您在' + data.gps_city_nm + '，是否切换？', '切换', '取消', $q.defer())
											.then(function () {
												$scope.city_id = data.gps_city_id;
												$scope.city = data.gps_city_nm;
												$scope.area_id = 0;
												$scope.$getTheaterList();
	
												cityStorage.remove();
											});
									}
								}
							});
							yesterdayCity.get('city');
							yesterdayCity.set('city', {id: data.city_id, nm: data.city_nm});
						}
	
					} else {
						return $q.reject();
					}
				}
				function _error() {
					if (!cacheData) {
						errorPop('获取影院失败了', '刷新重试', null, $q.defer()).then(function() {
							location.reload();
						});
					}
				}
				function _finally() {
					loadingPop.loaded();
				}
			};
	
			$txvlbs.then(function(geo) {
				console.log(geo);
				$scope.$getTheaterList(geo || {});
				if (geo._lbsfail) {
					$scope.lbsfail = true;
				}
			});
	
	
			$scope.citypop = false;
			$scope.showCity = function(iff, e) {
				$scope.citypop = iff && e.target.innerText;
			};
			$scope.areapop = false;
			$scope.areaInclude = {};
			$scope.areaList = [];
			$scope.showArea = function(iff) {
				$scope.areapop = iff;
			};
		}])
	
		.directive('lbs', ['$q', function($q) {
			return {
	            restrict: 'C',
				link: function ($scope, element, attr) {
					element.on('click', function () {
						if ($scope.gps_city_id != $scope.city_id) {
							confirmPop('系统定位您在' + $scope.gps_city + '，是否切换？', '切换', '取消', $q.defer())
								.then(function () {
									$scope.city_id = $scope.gps_city_id;
									$scope.city = $scope.gps_city;
									$scope.$setAreaId(0);
									$scope.$getTheaterList();
	
									cityStorage.remove();
								});
						}
						$scope.showCity(0);
					});
				}
			};
		}])
		.directive('cityId', function() {//所有带有city-id属性的元素都链接到一个directive
			return {
				link: function($scope, element, attr) {
					var cityId = attr.cityId;
					element.on('click', function() {
						$scope.city_id = cityId;
						$scope.area_id = 0;
						$scope.showCity(0);
						$scope.$getTheaterList();
	
						cityStorage.set(cityId, 0);
					});
				}
			};
		})
		.directive('myngCitypop', function() {//带有myng-citypop属性的元素链接到该directive
			return {
				link: function(scope, element) {
					element.css('display', 'none');
					scope.$watch('citypop', function(n) {
						element.css('display', n ? 'block' : 'none');
						element[0].querySelector('.__lbs span').innerText = scope.city;
						document.querySelector('#list').scrollTop = 0;
					});
					//城市索引
					element[0].querySelector('.filter_anchor').addEventListener('touchmove', onAnchor);
					element[0].querySelector('.filter_anchor').addEventListener('click', onAnchor);
					function onAnchor(e) {
						var x = e.touches ? e.touches[0].pageX : e.pageX;
						var y = e.touches ? e.touches[0].pageY : e.pageY;
						e.preventDefault();
	
						var $enter = document.elementFromPoint(x, y);
				        var alpha = $enter.innerHTML == '热' ? 'hot' : $enter.innerHTML;
						if ($enter.className == 'anchor') {
							element[0].querySelector('.__scroller').scrollTop = document.querySelector('#' + alpha).offsetTop - 49;
							setTimeout(function () {
								element[0].querySelector('.__scroller').style.opacity = 0.99 + Math.random() / 100;
							}, 0);
						}
					}
				}
			};
		})
		.directive('areaId', function() {
			return {
				link: function($scope, element, attr) {
					var areaId = attr.areaId;
					element.on('click', function() {
						$scope.$setAreaId(areaId);
						$scope.showArea(0);
						$scope.$getTheaterList();
	
						cityStorage.set($scope.city_id, areaId);
					});
				}
			};
		})
		.directive('myngAreapop', ['$txvAreaData', function($data) {
			var $scroller = document.querySelector('#mod_areas .selector_wrap');
			return {
				link: function(scope, element) {
					element.css('display', 'none');
					var lastY = 0;
					element.on('touchmove', function(e) {
						//拉到底部的时候再往上拉就preventDefault
						if ($scroller.clientHeight + $scroller.scrollTop == $scroller.scrollHeight && e.pageY < lastY) {
							e.preventDefault();
						}
						lastY = e.pageY;
					});
					scope.$watch('areapop', function(n) {
						element.css('display', n ? 'block' : 'none');
						n && $data(scope.city_id).success(function(ret) {
							scope.areaList = ret.town;
						});
					});
				}
			};
		}])
		.filter('row2', function() {
			//对ngRepeat使用filter的时候，如果不缓存结果。每次filter会产生不同引用，导致触发angular的脏检查，形成死循环。
			//http://stackoverflow.com/questions/21644493/how-to-split-the-ng-repeat-data-with-three-columns-using-bootstrap
			var lastInput, lastResult;
			return function(input) {
				if (input == lastInput) {
					return lastResult;
				}
				var arr = [];
				for(var i = 0; i < input.length; i++) {
					if (!arr.length || arr[arr.length - 1].length == 2) {
						arr.push([]);
					}
					arr[arr.length - 1].push(input[i]);
				}
				if (arr[arr.length - 1] && arr[arr.length - 1].length != 2) {
					arr[arr.length - 1].push({id: -1});
				}
				lastInput = input;
				lastResult = arr;
				return arr;
			};
		});
	
	//由于seajs的关系，所以要等dom ready再启动angular
	//angular.bootstrap就是启动
	angular.element(document).ready(function() {
		angular.bootstrap(document, ['mobileTicket']);
	
		//去你大爷的300ms延迟
		__webpack_require__(19).attach(document.body);
	});
	QQVideoBridge.setMoreInfo({"hasRefresh":true, "hasShare":false, "hasFollow":false});

/***/ }),
/* 1 */,
/* 2 */
/***/ (function(module, exports) {

	// http://tapd.oa.com/tvideo/prong/stories/view/1010031991056992805?url_cache_key=dc4c5bdd3ef3797a13e788c323168a6f&action_entry_type=story_tree_list
	var sessionStorage = window.sessionStorage || {
			getItem: function () {
			}, setItem: function () {
			}, removeItem: function () {
			}
		};
	var base_url = "https://btrace.qq.com/kvcollect?BossId=3243&Pwd=1546101498&plat=1&ua=" + navigator.userAgent + "&_dc=" + Math.random();
	var ref;
	
	
	//播放页来源
	if (location.href.indexOf('app.package.play') != -1) {
		sessionStorage.setItem('piao-ref', ref = 11);
	} else if (location.href.indexOf('app.package.user') != -1 || location.href.indexOf('app.package.channel') != -1) {
		sessionStorage.setItem('piao-ref', ref = 12);
	} else {
		ref = sessionStorage.getItem('piao-ref') || 12;
	}
	base_url += '&ref=' + ref;
	
	var exp = function (event, cid) {
		var g_btrace_BOSS = new Image(1, 1);
		g_btrace_BOSS.src = base_url + '&event=' + event + (cid ? ('&cid=' + cid) : '');
	};
	exp.delegate = function (event) {
		var $ = window.jQuery || window.Zepto;
		exp(event);//pv
		$(document.body).on('click', '[_boss]', function (e) {
			exp($(e.currentTarget).attr('_boss'));
		});
	};
	module.exports = exp;

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

	(function (factory) {
		if (window.angular) {
			//支持以angular服务(service/factory)形式注册使用。
			module.exports.registerNgService = function (ngModule) {
				ngModule.factory('$txvlbs', ['$q', function ($q) {
					return factory(window.QQVideoBridge, $q.defer, __webpack_require__(4)());
				}]);
			}
		} else {
	
			module.exports = factory(window.QQVideoBridge, $.Deferred, __webpack_require__(4)());
		}
	})(function (QQVideoBridge, Deferred, ua) {
	
	
		var def = Deferred(),
			defaultLbs = {
				lng: 900,
				lat: 900,
				_lbsfail: true
			};
		if (!ua.browser.QQvideo) {
			def.resolve(defaultLbs);
			return (typeof def.promise == 'function') ? def.promise() : def.promise;
		}
	
		function getLbsByApp() {
			var timer = setTimeout(function () {
				def.resolve(defaultLbs);
			}, 5000);
			try {
				QQVideoBridge.getLocation(null, function (res) {
					clearTimeout(timer);
					if (res.state == '0') {
						if (res.data) {
							if (res.data.errCode == '0') {
								if (res.data.result) {
	
									// lat,lon,poiName,address
									// error含义
									//其中状态0代表：一次进入用户允许获取
									//状态-1代表：第一次进入用户不允许获取
									//状态-2代表：系统弹出“去设置打开定位服务”
	
									var result = res.data.result,
										pos = {
											lng: result.lon,
											lat: result.lat,
											name: result.poiName
										};
									def.resolve(pos);
									return;
								}
							} else {
								def.resolve(defaultLbs, res.data)
								return;
							}
						}
						def.resolve(defaultLbs);
					} else {
						def.resolve(defaultLbs);
					}
				}).fail(function () {
					def.resolve(defaultLbs);
				});
	
			} catch (e) {
				alert(e);
			} finally {
	
			}
		}
	
		getLbsByApp();
	
		return (typeof def.promise == 'function') ? def.promise() : def.promise;
	});


/***/ }),
/* 4 */
/***/ (function(module, exports) {

	function check(ua) {
		if (!ua) {
			return;
		}
	
		var os = {}, browser = {};
	
		var oscheck = {
			iphone: ua.match(/(iphone)\sos\s([\d_]+)/i),
			ipad: ua.match(/(ipad).*\s([\d_]+)/i),
			ipod: ua.match(/(ipod).*\s([\d_]+)/i),
			android: ua.match(/(android)\s([\d\.]+)/i),
			windows: ua.match(/Windows(\s+\w+)?\s+?(\d+\.\d+)/)
		};
	
		if (oscheck.ipod) {
			os.ios = os.ipod = true;
			os.version = oscheck.ipod[2].replace(/_/g, '.');
			os.name = 'ipod';
		}
		if (oscheck.ipad) {
			os.ios = os.ipad = true;
			os.version = oscheck.ipad[2].replace(/_/g, '.');
			os.name = 'ipad';
		}
		if (oscheck.iphone) {
			os.iphone = os.ios = true;
			os.version = oscheck.iphone[2].replace(/_/g, '.');
			os.name = 'iphone';
		}
		if (oscheck.android) {
			os.android = true;
			os.version = oscheck.android[2];
			os.name = 'android';
		}
		if (oscheck.windows) {
			os.windows = true;
			os.version = oscheck.windows[2];
			os.name = 'windows';
		}
	
		var browsercheck = {
			WeChat: ua.match(/MicroMessenger\/((\d+)\.(\d+))\.(\d+)/) || ua.match(/MicroMessenger\/((\d+)\.(\d+))/),
			MQQClient: (!ua.match(/QQReader/) &&ua.match(/QQ\/(\d+\.\d+)/i) || ua.match(/V1_AND_SQ_([\d\.]+)/)),//QQ阅读伪装成了QQ然而不具备QQ的jsapi
			MQQReader: ua.match(/QQReader/i),
			QQvideo: ua.match(/QQLiveBrowser\/([\d.]+)/),
			TBSSDK: ua.match(/MQQBrowser\/(\d+\.\d+)/i) && ua.match(/MSDK\/(\d+\.\d+)/),
			MQQBrowser: ua.match(/MQQBrowser\/(\d+\.\d+)/i),
			UCBrowser: ua.match(/ucbrowser\/(\d+\.\d+)/i),
			Qzone: ua.match(/Qzone\/[\w\d\_]*(\d\.\d)[\.\w\d\_]*/i),
			Weibo: ua.match(/Weibo/i),
			qqnews: ua.match(/qqnews\/(\d+\.\d+\.\d+)/i),
			QQLiveBroadcast: ua.match(/QQLiveBroadcast/i),
			kuaibao: ua.match(/qnreading\/(\d+\.\d+\.\d+)/i),
			liebao: ua.match(/LieBaoFast\/(\d+\.\d+\.\d+)/i),
			IEMobile: ua.match(/IEMobile(\/|\s+)(\d+\.\d+)/) || ua.match(/WPDesktop/),
			douban: ua.match(/com\.douban\.frodo\/(\d+\.\d+\.\d+)/i),
			MiuiBrowser: ua.match(/MiuiBrowser\/(\d+\.\d+)/i),
			Chrome: os.ios ? ua.match(/CriOS\/(\d+\.\d+)/) : ua.match(/Chrome\/(\d+\.\d+)/),
			Safari: ua.match(/Safari\/(\d+\.\d+)/)
		};
	
		if (browsercheck.MQQReader) {// 非主流的QQ阅读
			browser.MQQReader = true;
			browser.version = 1;
			browser.name = 'MQQReader';
		} else if (browsercheck.IEMobile) {
			browser.IEMobile = true;
			browser.version = 1;
			browser.name = 'IEMobile';
		} else {
			for (var i in browsercheck) {
				if (browsercheck[i]) {
					browser[i] = true;
					browser.version = browsercheck[i][1];
					browser.name = i;
					break;
				}
			}
		}
	
		return {
			browser: browser,
			os: os
		};
	}
	
	var cache = null;
	
	var exportee = function () {
		return cache || (cache = check(navigator.userAgent));
	};
	
	//注入到express或者connect的中间件
	exportee.__express = function (req, res, next) {
		req.ua = check(req.headers['user-agent']);
		next();
	};
	//注入到jquery或zepto
	exportee.__jquery = function ($) {
		$ = $ || window.jQuery || window.Zepto;
		var res = cache || (cache = check(navigator.userAgent));
		$.browser = res.browser;
		$.os = res.os;
	};
	
	exportee.__clearCache = function () {
	    cache = null;
	};
	
	module.exports = exportee;

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, exports, module) {
	    var $pop = document.querySelector('#alert'),
	        $confirm = document.querySelector('#alert_confirm'),
	        $cancel = document.querySelector('#alert_cancel'),
	        $msg = document.querySelector('#alert_msg');
	
	    var def;
	
	    $confirm.addEventListener('click', function() {
	        def && def.resolve();
	        $pop.style.display = "none";
	    });
	    $cancel.addEventListener('click', function() {
	        def && def.reject();
	        $pop.style.display = "none";
	    });
	
	    module.exports = function(msg, confirmTxt, cancelTxt, defer) {
	        def = defer || $.Deferred();
	        $pop.style.display = "block";
	        $msg.innerHTML = msg;
	        $confirm.innerHTML = confirmTxt;
	        $cancel.innerHTML = cancelTxt;
	        return typeof def.promise == 'function' ? def.promise() : def.promise;
	    };
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function(require,exports,module){
	
	    var key = "city";
	
	    module.exports = {
	        /**
	         * 获取城市信息
	         * @returns {{city_id: string, area_id: string}}
	         */
	        get : function(){
	            var value = localStorage.getItem(key);
	            if(typeof value !="string"){
	                return null;
	            }
	            value = value.split(",");
	            return {
	                city_id:value[0],
	                area_id:value[1]
	            }
	        },
	        /**
	         * 存储城市信息
	         * @param city_id
	         * @param area_id
	         */
	        set : function(city_id,area_id){
	            var value = Array.apply(null,arguments);
	            localStorage.setItem(key,value.join(","));
	        },
	        remove : function(){
	            localStorage.removeItem(key);
	        }
	    }
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__))

/***/ }),
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */
/***/ (function(module, exports) {

	/**
	 * exports: function(key, options)
	 * @param prefix       define a prefix of the keys in localStorage
	 * @param options
	 *      maxAge
	 *      limit           item limited in localStorage, defaults to 0(so all item will be saved in sessionStorage)
	 *      useSession      when an item is staled, detemine whether drop it or move it to sessionStorage, defaults to true
	 *      -
	 */
	
	(function(LruStorageFactory, CacheItemFactory, LRUArrayFactory) {
	  // if (window.define && define.cmd) {
	  //   define(function(r, e, module) {
	  //     module.exports =
	  //   });
	  // } else {
	  //   window.LruWebStorage = LruStorageFactory(CacheItemFactory(),
	  //     LRUArrayFactory());
	  // }
	  module.exports = LruStorageFactory(CacheItemFactory(), LRUArrayFactory());
	})(function(CacheItem, LRUArray) {
	  var STORAGE = {
	    local: window.localStorage,
	    session: window.sessionStorage
	  };
	
	  function LruStorage(prefix, options) {
	    this.prefix = prefix;
	    LruStorage.ATTRIBUTES.forEach(function(key) {
	      this[key] = options[key];
	    }, this);
	    this.onStale = options.onStale;
	
	    //keys
	    this.items = LRUArray('storageKey');
	    if (options._items) {
	      options._items.forEach(function(v) {
	        this.items.unshift(new CacheItem(v));
	      }, this);
	    }
	  }
	  LruStorage.ATTRIBUTES = ['maxAge', 'limit', 'useSession'];
	
	  LruStorage.prototype.set = function set(key, val, opt) {
	    var item;
	    //if there is no cacheItem storaged, create one
	    if (!(item = this.items.find(key))) {
	      item = new CacheItem({
	        key: key,
	        maxAge: Date.now() + this.maxAge
	      });
	      this.add(item);
	    }
	    //save value
	    STORAGE[item.level].setItem(this.prefix + '-' + item.storageKey, JSON.stringify(
	      val));
	    this.saveConfig();
	    return this;
	  };
	
	  LruStorage.prototype.get = function get(key, opt) {
	    var item;
	    //check if there is a cacheItem storaged yet
	    if (!(item = this.items.find(key))) return ({}).undefined;
	    if (item.isStale()) {
	      this.remove(this.items.indexOf(key));
	      return null;
	    }
	
	    return JSON.parse(STORAGE[item.level].getItem(this.prefix + '-' + item.storageKey));
	  };
	
	  LruStorage.prototype.remove = function(index) {
	    var item = this.items.arr[index];
	
	    if (typeof this.onStale == 'function') {
	      if (this.onStale(JSON.parse(STORAGE[item.level].getItem(this.prefix +
	          '-' + item.storageKey)), this.useSession)) return;
	    }
	    // console.log(this.useSession, index);
	    if (this.useSession) {
	      if (item.level == 'local') {
	        item.level = 'session';
	        STORAGE.local.removeItem(this.prefix + '-' + item.storageKey);
	        STORAGE.session.setItem(this.prefix + '-' + item.storageKey,
	          STORAGE.local.getItem(this.prefix + '-' + item.storageKey));
	      }
	
	    } else {
	      STORAGE[item.level].removeItem(this.prefix + '-' + item.storageKey);
	      if (index == this.items.length - 1) {
	        this.items.pop();
	      } else {
	        this.items.splice(index, 1);
	      }
	    }
	    return this;
	  };
	
	  LruStorage.prototype.add = function(item) {
	    //remove the last one when items out of limit
	    if (this.items.length >= this.limit && this.items.length > 0) {
	      // console.log(this.items.length, this.limit);
	      for (var i = Math.max(0, this.limit - 1); i < this.items.length; i++) {
	        this.remove(i);
	      }
	    }
	    this.items.unshift(item);
	    return this;
	  };
	
	  LruStorage.prototype.saveConfig = function saveConfig() {
	    var json = {
	      _items: []
	    };
	    //stringify all items and config
	    this.items.forEach(function(v) {
	      var citem = {};
	      CacheItem.ATTRIBUTES.forEach(function(key) {
	        citem[key] = v[key];
	      });
	      json._items.push(citem);
	    }, this);
	    LruStorage.ATTRIBUTES.forEach(function(attr) {
	      json[attr] = this[attr];
	    }, this);
	    STORAGE.local.setItem(this.prefix + '-lruconfig', JSON.stringify(json));
	  };
	
	  return function(prefix, options) {
	    var oldConfig = STORAGE.local.getItem(prefix + '-lruconfig') ? JSON.parse(
	      STORAGE.local.getItem(prefix + '-lruconfig')) : {};
	    options = options || {};
	
	    oldConfig.maxAge = options.maxAge || oldConfig.maxAge || Infinity;
	    oldConfig.limit = options.limit || oldConfig.limit || 0;
	    oldConfig.useSession = ('useSession' in options) ? options.useSession :
	      (('useSession' in oldConfig) ? oldConfig.useSession : true);
	    oldConfig.onStale = options.onStale || null;
	
	    return new LruStorage(prefix, oldConfig);
	  };
	
	
	}, function() {
	
	  function CacheItem(obj) {
	    this.storageKey = obj.storageKey || obj.key || '';
	    this.maxAge = obj.maxAge || 0;
	    this.level = obj.level || 'local';
	
	    if (this.level != 'session' && this.level != 'local') {
	      throw 'there is no webstorage interface named ' + this.level +
	        'Storage';
	    }
	  }
	  CacheItem.ATTRIBUTES = ['storageKey', 'maxAge', 'level'];
	  //create by a json string
	  CacheItem.fromJSON = function parse(str) {
	    var ret = {};
	    try {
	      str = JSON.parse(str);
	
	      CacheItem.ATTRIBUTES.forEach(function(v) {
	        this[v] = str[v];
	      }, ret);
	    } catch (e) {}
	    return ret;
	  };
	
	  //check if out of date
	  CacheItem.prototype.isStale = function isStale() {
	    return Date.now() > this.maxAge;
	  };
	
	  return CacheItem;
	
	}, function() {
	  function LRUArray(idkey) {
	    this.arr = [];
	    this.idkey = typeof idkey == 'function' ? idkey : function(item) {
	      return item[idkey];
	    };
	
	    var self = this;
	    Object.defineProperty(this, 'length', {
	      get: function() {
	        return self.arr.length;
	      },
	      set: function() {
	
	      }
	    });
	  }
	  ['forEach', 'push', 'shift', 'unshift', 'pop', 'every', 'concat', 'splice']
	  .forEach(function(key) {
	    LRUArray.prototype[key] = function() {
	      return this.arr[key].apply(this.arr, arguments);
	    };
	  });
	  LRUArray.prototype.update = function(id) {
	    var index = this.indexOf(id);
	    if (index === -1) return;
	    this.updateByIndex(index);
	  };
	  LRUArray.prototype.updateByIndex = function(index) {
	    if (this.arr.length <= index || index == -1) return;
	    var item = this.arr[index];
	    this.arr.splice(index, 1);
	    this.arr.unshift(item);
	  };
	  LRUArray.prototype.indexOf = function(id) {
	    var ret = -1;
	    //TODO improve the finding algorithm?
	    this.every(function(item, index) {
	      if (this.idkey(item) == id) {
	        ret = index;
	        return false;
	      }
	      return true;
	    }, this);
	    return ret;
	  };
	  LRUArray.prototype.find = function(key, silent) {
	    var index = this.indexOf(key);
	    var item = this.arr[index];
	    if (!silent) {
	      this.updateByIndex(index);
	    }
	    return item;
	  };
	
	  return function(key) {
	    return new LRUArray(key);
	  };
	});


/***/ }),
/* 14 */,
/* 15 */,
/* 16 */,
/* 17 */,
/* 18 */,
/* 19 */
/***/ (function(module, exports) {

	;
	(function() {
		'use strict';
	
		/**
		 * @preserve FastClick: polyfill to remove click delays on browsers with touch UIs.
		 *
		 * @codingstandard ftlabs-jsv2
		 * @copyright The Financial Times Limited [All Rights Reserved]
		 * @license MIT License (see LICENSE.txt)
		 */
	
		/*jslint browser:true, node:true*/
		/*global define, Event, Node*/
	
	
		/**
		 * Instantiate fast-clicking listeners on the specified layer.
		 *
		 * @constructor
		 * @param {Element} layer The layer to listen on
		 * @param {Object} [options={}] The options to override the defaults
		 */
		function FastClick(layer, options) {
			var oldOnClick;
	
			options = options || {};
	
			/**
			 * Whether a click is currently being tracked.
			 *
			 * @type boolean
			 */
			this.trackingClick = false;
	
	
			/**
			 * Timestamp for when click tracking started.
			 *
			 * @type number
			 */
			this.trackingClickStart = 0;
	
	
			/**
			 * The element being tracked for a click.
			 *
			 * @type EventTarget
			 */
			this.targetElement = null;
	
	
			/**
			 * X-coordinate of touch start event.
			 *
			 * @type number
			 */
			this.touchStartX = 0;
	
	
			/**
			 * Y-coordinate of touch start event.
			 *
			 * @type number
			 */
			this.touchStartY = 0;
	
	
			/**
			 * ID of the last touch, retrieved from Touch.identifier.
			 *
			 * @type number
			 */
			this.lastTouchIdentifier = 0;
	
	
			/**
			 * Touchmove boundary, beyond which a click will be cancelled.
			 *
			 * @type number
			 */
			this.touchBoundary = options.touchBoundary || 10;
	
	
			/**
			 * The FastClick layer.
			 *
			 * @type Element
			 */
			this.layer = layer;
	
			/**
			 * The minimum time between tap(touchstart and touchend) events
			 *
			 * @type number
			 */
			this.tapDelay = options.tapDelay || 200;
	
			/**
			 * The maximum time for a tap
			 *
			 * @type number
			 */
			this.tapTimeout = options.tapTimeout || 700;
	
			if (FastClick.notNeeded(layer)) {
				return;
			}
	
			// Some old versions of Android don't have Function.prototype.bind
			function bind(method, context) {
				return function() {
					return method.apply(context, arguments);
				};
			}
	
	
			var methods = ['onMouse', 'onClick', 'onTouchStart', 'onTouchMove',
				'onTouchEnd', 'onTouchCancel'
			];
			var context = this;
			for (var i = 0, l = methods.length; i < l; i++) {
				context[methods[i]] = bind(context[methods[i]], context);
			}
	
			// Set up event handlers as required
			if (deviceIsAndroid) {
				layer.addEventListener('mouseover', this.onMouse, true);
				layer.addEventListener('mousedown', this.onMouse, true);
				layer.addEventListener('mouseup', this.onMouse, true);
			}
	
			layer.addEventListener('click', this.onClick, true);
			layer.addEventListener('touchstart', this.onTouchStart, false);
			layer.addEventListener('touchmove', this.onTouchMove, false);
			layer.addEventListener('touchend', this.onTouchEnd, false);
			layer.addEventListener('touchcancel', this.onTouchCancel, false);
	
			// Hack is required for browsers that don't support Event#stopImmediatePropagation (e.g. Android 2)
			// which is how FastClick normally stops click events bubbling to callbacks registered on the FastClick
			// layer when they are cancelled.
			if (!Event.prototype.stopImmediatePropagation) {
				layer.removeEventListener = function(type, callback, capture) {
					var rmv = Node.prototype.removeEventListener;
					if (type === 'click') {
						rmv.call(layer, type, callback.hijacked || callback, capture);
					} else {
						rmv.call(layer, type, callback, capture);
					}
				};
	
				layer.addEventListener = function(type, callback, capture) {
					var adv = Node.prototype.addEventListener;
					if (type === 'click') {
						adv.call(layer, type, callback.hijacked || (callback.hijacked = function(
							event) {
							if (!event.propagationStopped) {
								callback(event);
							}
						}), capture);
					} else {
						adv.call(layer, type, callback, capture);
					}
				};
			}
	
			// If a handler is already declared in the element's onclick attribute, it will be fired before
			// FastClick's onClick handler. Fix this by pulling out the user-defined handler function and
			// adding it as listener.
			if (typeof layer.onclick === 'function') {
	
				// Android browser on at least 3.2 requires a new reference to the function in layer.onclick
				// - the old one won't work if passed to addEventListener directly.
				oldOnClick = layer.onclick;
				layer.addEventListener('click', function(event) {
					oldOnClick(event);
				}, false);
				layer.onclick = null;
			}
		}
	
		/**
		 * Windows Phone 8.1 fakes user agent string to look like Android and iPhone.
		 *
		 * @type boolean
		 */
		var deviceIsWindowsPhone = navigator.userAgent.indexOf("Windows Phone") >= 0;
	
		/**
		 * Android requires exceptions.
		 *
		 * @type boolean
		 */
		var deviceIsAndroid = navigator.userAgent.indexOf('Android') > 0 && !
			deviceIsWindowsPhone;
	
	
		/**
		 * iOS requires exceptions.
		 *
		 * @type boolean
		 */
		var deviceIsIOS = /iP(ad|hone|od)/.test(navigator.userAgent) && !
			deviceIsWindowsPhone;
	
	
		/**
		 * iOS 4 requires an exception for select elements.
		 *
		 * @type boolean
		 */
		var deviceIsIOS4 = deviceIsIOS && (/OS 4_\d(_\d)?/).test(navigator.userAgent);
	
	
		/**
		 * iOS 6.0-7.* requires the target element to be manually derived
		 *
		 * @type boolean
		 */
		var deviceIsIOSWithBadTarget = deviceIsIOS && (/OS [6-7]_\d/).test(navigator.userAgent);
	
		/**
		 * BlackBerry requires exceptions.
		 *
		 * @type boolean
		 */
		var deviceIsBlackBerry10 = navigator.userAgent.indexOf('BB10') > 0;
	
		/**
		 * Determine whether a given element requires a native click.
		 *
		 * @param {EventTarget|Element} target Target DOM element
		 * @returns {boolean} Returns true if the element needs a native click
		 */
		FastClick.prototype.needsClick = function(target) {
			switch (target.nodeName.toLowerCase()) {
	
				// Don't send a synthetic click to disabled inputs (issue #62)
				case 'button':
				case 'select':
				case 'textarea':
					if (target.disabled) {
						return true;
					}
	
					break;
				case 'input':
	
					// File inputs need real clicks on iOS 6 due to a browser bug (issue #68)
					if ((deviceIsIOS && target.type === 'file') || target.disabled) {
						return true;
					}
	
					break;
				case 'label':
				case 'iframe': // iOS8 homescreen apps can prevent events bubbling into frames
				case 'video':
					return true;
			}
	
			return (/\bneedsclick\b/).test(target.className);
		};
	
	
		/**
		 * Determine whether a given element requires a call to focus to simulate click into element.
		 *
		 * @param {EventTarget|Element} target Target DOM element
		 * @returns {boolean} Returns true if the element requires a call to focus to simulate native click.
		 */
		FastClick.prototype.needsFocus = function(target) {
			switch (target.nodeName.toLowerCase()) {
				case 'textarea':
					return true;
				case 'select':
					return !deviceIsAndroid;
				case 'input':
					switch (target.type) {
						case 'button':
						case 'checkbox':
						case 'file':
						case 'image':
						case 'radio':
						case 'submit':
							return false;
					}
	
					// No point in attempting to focus disabled inputs
					return !target.disabled && !target.readOnly;
				default:
					return (/\bneedsfocus\b/).test(target.className);
			}
		};
	
	
		/**
		 * Send a click event to the specified element.
		 *
		 * @param {EventTarget|Element} targetElement
		 * @param {Event} event
		 */
		FastClick.prototype.sendClick = function(targetElement, event) {
			var clickEvent, touch;
	
			// On some Android devices activeElement needs to be blurred otherwise the synthetic click will have no effect (#24)
			if (document.activeElement && document.activeElement !== targetElement) {
				document.activeElement.blur();
			}
	
			touch = event.changedTouches[0];
	
			// Synthesise a click event, with an extra attribute so it can be tracked
			clickEvent = document.createEvent('MouseEvents');
			clickEvent.initMouseEvent(this.determineEventType(targetElement), true,
				true, window, 1, touch.screenX, touch.screenY, touch.clientX, touch.clientY,
				false, false, false, false, 0, null);
			clickEvent.forwardedTouchEvent = true;
			targetElement.dispatchEvent(clickEvent);
		};
	
		FastClick.prototype.determineEventType = function(targetElement) {
	
			//Issue #159: Android Chrome Select Box does not open with a synthetic click event
			if (deviceIsAndroid && targetElement.tagName.toLowerCase() === 'select') {
				return 'mousedown';
			}
	
			return 'click';
		};
	
	
		/**
		 * @param {EventTarget|Element} targetElement
		 */
		FastClick.prototype.focus = function(targetElement) {
			var length;
	
			// Issue #160: on iOS 7, some input elements (e.g. date datetime month) throw a vague TypeError on setSelectionRange. These elements don't have an integer value for the selectionStart and selectionEnd properties, but unfortunately that can't be used for detection because accessing the properties also throws a TypeError. Just check the type instead. Filed as Apple bug #15122724.
			if (deviceIsIOS && targetElement.setSelectionRange && targetElement.type.indexOf(
					'date') !== 0 && targetElement.type !== 'time' && targetElement.type !==
				'month') {
				length = targetElement.value.length;
				targetElement.setSelectionRange(length, length);
			} else {
				targetElement.focus();
			}
		};
	
	
		/**
		 * Check whether the given target element is a child of a scrollable layer and if so, set a flag on it.
		 *
		 * @param {EventTarget|Element} targetElement
		 */
		FastClick.prototype.updateScrollParent = function(targetElement) {
			var scrollParent, parentElement;
	
			scrollParent = targetElement.fastClickScrollParent;
	
			// Attempt to discover whether the target element is contained within a scrollable layer. Re-check if the
			// target element was moved to another parent.
			if (!scrollParent || !scrollParent.contains(targetElement)) {
				parentElement = targetElement;
				do {
					if (parentElement.scrollHeight > parentElement.offsetHeight) {
						scrollParent = parentElement;
						targetElement.fastClickScrollParent = parentElement;
						break;
					}
	
					parentElement = parentElement.parentElement;
				} while (parentElement);
			}
	
			// Always update the scroll top tracker if possible.
			if (scrollParent) {
				scrollParent.fastClickLastScrollTop = scrollParent.scrollTop;
			}
		};
	
	
		/**
		 * @param {EventTarget} targetElement
		 * @returns {Element|EventTarget}
		 */
		FastClick.prototype.getTargetElementFromEventTarget = function(eventTarget) {
	
			// On some older browsers (notably Safari on iOS 4.1 - see issue #56) the event target may be a text node.
			if (eventTarget.nodeType === Node.TEXT_NODE) {
				return eventTarget.parentNode;
			}
	
			return eventTarget;
		};
	
	
		/**
		 * On touch start, record the position and scroll offset.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onTouchStart = function(event) {
			var targetElement, touch, selection;
	
			// Ignore multiple touches, otherwise pinch-to-zoom is prevented if both fingers are on the FastClick element (issue #111).
			if (event.targetTouches.length > 1) {
				return true;
			}
	
			targetElement = this.getTargetElementFromEventTarget(event.target);
			touch = event.targetTouches[0];
	
			if (deviceIsIOS) {
	
				// Only trusted events will deselect text on iOS (issue #49)
				selection = window.getSelection();
				if (selection.rangeCount && !selection.isCollapsed) {
					return true;
				}
	
				if (!deviceIsIOS4) {
	
					// Weird things happen on iOS when an alert or confirm dialog is opened from a click event callback (issue #23):
					// when the user next taps anywhere else on the page, new touchstart and touchend events are dispatched
					// with the same identifier as the touch event that previously triggered the click that triggered the alert.
					// Sadly, there is an issue on iOS 4 that causes some normal touch events to have the same identifier as an
					// immediately preceeding touch event (issue #52), so this fix is unavailable on that platform.
					// Issue 120: touch.identifier is 0 when Chrome dev tools 'Emulate touch events' is set with an iOS device UA string,
					// which causes all touch events to be ignored. As this block only applies to iOS, and iOS identifiers are always long,
					// random integers, it's safe to to continue if the identifier is 0 here.
					if (touch.identifier && touch.identifier === this.lastTouchIdentifier) {
						event.preventDefault();
						return false;
					}
	
					this.lastTouchIdentifier = touch.identifier;
	
					// If the target element is a child of a scrollable layer (using -webkit-overflow-scrolling: touch) and:
					// 1) the user does a fling scroll on the scrollable layer
					// 2) the user stops the fling scroll with another tap
					// then the event.target of the last 'touchend' event will be the element that was under the user's finger
					// when the fling scroll was started, causing FastClick to send a click event to that layer - unless a check
					// is made to ensure that a parent layer was not scrolled before sending a synthetic click (issue #42).
					this.updateScrollParent(targetElement);
				}
			}
	
			this.trackingClick = true;
			this.trackingClickStart = event.timeStamp;
			this.targetElement = targetElement;
	
			this.touchStartX = touch.pageX;
			this.touchStartY = touch.pageY;
	
			// Prevent phantom clicks on fast double-tap (issue #36)
			if ((event.timeStamp - this.lastClickTime) < this.tapDelay) {
				event.preventDefault();
			}
	
			return true;
		};
	
	
		/**
		 * Based on a touchmove event object, check whether the touch has moved past a boundary since it started.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.touchHasMoved = function(event) {
			var touch = event.changedTouches[0],
				boundary = this.touchBoundary;
	
			if (Math.abs(touch.pageX - this.touchStartX) > boundary || Math.abs(touch.pageY -
					this.touchStartY) > boundary) {
				return true;
			}
	
			return false;
		};
	
	
		/**
		 * Update the last position.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onTouchMove = function(event) {
			if (!this.trackingClick) {
				return true;
			}
	
			// If the touch has moved, cancel the click tracking
			if (this.targetElement !== this.getTargetElementFromEventTarget(event.target) ||
				this.touchHasMoved(event)) {
				this.trackingClick = false;
				this.targetElement = null;
			}
	
			return true;
		};
	
	
		/**
		 * Attempt to find the labelled control for the given label element.
		 *
		 * @param {EventTarget|HTMLLabelElement} labelElement
		 * @returns {Element|null}
		 */
		FastClick.prototype.findControl = function(labelElement) {
	
			// Fast path for newer browsers supporting the HTML5 control attribute
			if (labelElement.control !== undefined) {
				return labelElement.control;
			}
	
			// All browsers under test that support touch events also support the HTML5 htmlFor attribute
			if (labelElement.htmlFor) {
				return document.getElementById(labelElement.htmlFor);
			}
	
			// If no for attribute exists, attempt to retrieve the first labellable descendant element
			// the list of which is defined here: http://www.w3.org/TR/html5/forms.html#category-label
			return labelElement.querySelector(
				'button, input:not([type=hidden]), keygen, meter, output, progress, select, textarea'
			);
		};
	
	
		/**
		 * On touch end, determine whether to send a click event at once.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onTouchEnd = function(event) {
			var forElement, trackingClickStart, targetTagName, scrollParent, touch,
				targetElement = this.targetElement;
	
			if (!this.trackingClick) {
				return true;
			}
	
			// Prevent phantom clicks on fast double-tap (issue #36)
			if ((event.timeStamp - this.lastClickTime) < this.tapDelay) {
				this.cancelNextClick = true;
				return true;
			}
	
			if ((event.timeStamp - this.trackingClickStart) > this.tapTimeout) {
				return true;
			}
	
			// Reset to prevent wrong click cancel on input (issue #156).
			this.cancelNextClick = false;
	
			this.lastClickTime = event.timeStamp;
	
			trackingClickStart = this.trackingClickStart;
			this.trackingClick = false;
			this.trackingClickStart = 0;
	
			// On some iOS devices, the targetElement supplied with the event is invalid if the layer
			// is performing a transition or scroll, and has to be re-detected manually. Note that
			// for this to function correctly, it must be called *after* the event target is checked!
			// See issue #57; also filed as rdar://13048589 .
			if (deviceIsIOSWithBadTarget) {
				touch = event.changedTouches[0];
	
				// In certain cases arguments of elementFromPoint can be negative, so prevent setting targetElement to null
				targetElement = document.elementFromPoint(touch.pageX - window.pageXOffset,
					touch.pageY - window.pageYOffset) || targetElement;
				targetElement.fastClickScrollParent = this.targetElement.fastClickScrollParent;
			}
	
			targetTagName = targetElement.tagName.toLowerCase();
			if (targetTagName === 'label') {
				forElement = this.findControl(targetElement);
				if (forElement) {
					this.focus(targetElement);
					if (deviceIsAndroid) {
						return false;
					}
	
					targetElement = forElement;
				}
			} else if (this.needsFocus(targetElement)) {
	
				// Case 1: If the touch started a while ago (best guess is 100ms based on tests for issue #36) then focus will be triggered anyway. Return early and unset the target element reference so that the subsequent click will be allowed through.
				// Case 2: Without this exception for input elements tapped when the document is contained in an iframe, then any inputted text won't be visible even though the value attribute is updated as the user types (issue #37).
				if ((event.timeStamp - trackingClickStart) > 100 || (deviceIsIOS && window
						.top !== window && targetTagName === 'input')) {
					this.targetElement = null;
					return false;
				}
	
				this.focus(targetElement);
				this.sendClick(targetElement, event);
	
				// Select elements need the event to go through on iOS 4, otherwise the selector menu won't open.
				// Also this breaks opening selects when VoiceOver is active on iOS6, iOS7 (and possibly others)
				if (!deviceIsIOS || targetTagName !== 'select') {
					this.targetElement = null;
					event.preventDefault();
				}
	
				return false;
			}
	
			if (deviceIsIOS && !deviceIsIOS4) {
	
				// Don't send a synthetic click event if the target element is contained within a parent layer that was scrolled
				// and this tap is being used to stop the scrolling (usually initiated by a fling - issue #42).
				scrollParent = targetElement.fastClickScrollParent;
				if (scrollParent && scrollParent.fastClickLastScrollTop !== scrollParent.scrollTop) {
					return true;
				}
			}
	
			// Prevent the actual click from going though - unless the target node is marked as requiring
			// real clicks or if it is in the whitelist in which case only non-programmatic clicks are permitted.
			if (!this.needsClick(targetElement)) {
				event.preventDefault();
				this.sendClick(targetElement, event);
			}
	
			return false;
		};
	
	
		/**
		 * On touch cancel, stop tracking the click.
		 *
		 * @returns {void}
		 */
		FastClick.prototype.onTouchCancel = function() {
			this.trackingClick = false;
			this.targetElement = null;
		};
	
	
		/**
		 * Determine mouse events which should be permitted.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onMouse = function(event) {
	
			// If a target element was never set (because a touch event was never fired) allow the event
			if (!this.targetElement) {
				return true;
			}
	
			if (event.forwardedTouchEvent) {
				return true;
			}
	
			// Programmatically generated events targeting a specific element should be permitted
			if (!event.cancelable) {
				return true;
			}
	
			// Derive and check the target element to see whether the mouse event needs to be permitted;
			// unless explicitly enabled, prevent non-touch click events from triggering actions,
			// to prevent ghost/doubleclicks.
			if (!this.needsClick(this.targetElement) || this.cancelNextClick) {
	
				// Prevent any user-added listeners declared on FastClick element from being fired.
				if (event.stopImmediatePropagation) {
					event.stopImmediatePropagation();
				} else {
	
					// Part of the hack for browsers that don't support Event#stopImmediatePropagation (e.g. Android 2)
					event.propagationStopped = true;
				}
	
				// Cancel the event
				event.stopPropagation();
				event.preventDefault();
	
				return false;
			}
	
			// If the mouse event is permitted, return true for the action to go through.
			return true;
		};
	
	
		/**
		 * On actual clicks, determine whether this is a touch-generated click, a click action occurring
		 * naturally after a delay after a touch (which needs to be cancelled to avoid duplication), or
		 * an actual click which should be permitted.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onClick = function(event) {
			var permitted;
	
			// It's possible for another FastClick-like library delivered with third-party code to fire a click event before FastClick does (issue #44). In that case, set the click-tracking flag back to false and return early. This will cause onTouchEnd to return early.
			if (this.trackingClick) {
				this.targetElement = null;
				this.trackingClick = false;
				return true;
			}
	
			// Very odd behaviour on iOS (issue #18): if a submit element is present inside a form and the user hits enter in the iOS simulator or clicks the Go button on the pop-up OS keyboard the a kind of 'fake' click event will be triggered with the submit-type input element as the target.
			if (event.target.type === 'submit' && event.detail === 0) {
				return true;
			}
	
			permitted = this.onMouse(event);
	
			// Only unset targetElement if the click is not permitted. This will ensure that the check for !targetElement in onMouse fails and the browser's click doesn't go through.
			if (!permitted) {
				this.targetElement = null;
			}
	
			// If clicks are permitted, return true for the action to go through.
			return permitted;
		};
	
	
		/**
		 * Remove all FastClick's event listeners.
		 *
		 * @returns {void}
		 */
		FastClick.prototype.destroy = function() {
			var layer = this.layer;
	
			if (deviceIsAndroid) {
				layer.removeEventListener('mouseover', this.onMouse, true);
				layer.removeEventListener('mousedown', this.onMouse, true);
				layer.removeEventListener('mouseup', this.onMouse, true);
			}
	
			layer.removeEventListener('click', this.onClick, true);
			layer.removeEventListener('touchstart', this.onTouchStart, false);
			layer.removeEventListener('touchmove', this.onTouchMove, false);
			layer.removeEventListener('touchend', this.onTouchEnd, false);
			layer.removeEventListener('touchcancel', this.onTouchCancel, false);
		};
	
	
		/**
		 * Check whether FastClick is needed.
		 *
		 * @param {Element} layer The layer to listen on
		 */
		FastClick.notNeeded = function(layer) {
			var metaViewport;
			var chromeVersion;
			var blackberryVersion;
			var firefoxVersion;
	
			// Devices that don't support touch don't need FastClick
			if (typeof window.ontouchstart === 'undefined') {
				return true;
			}
	
			// Chrome version - zero for other browsers
			chromeVersion = +(/Chrome\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[1];
	
			if (chromeVersion) {
	
				if (deviceIsAndroid) {
					metaViewport = document.querySelector('meta[name=viewport]');
	
					if (metaViewport) {
						// Chrome on Android with user-scalable="no" doesn't need FastClick (issue #89)
						if (metaViewport.content.indexOf('user-scalable=no') !== -1) {
							return true;
						}
						// Chrome 32 and above with width=device-width or less don't need FastClick
						if (chromeVersion > 31 && document.documentElement.scrollWidth <= window
							.outerWidth) {
							return true;
						}
					}
	
					// Chrome desktop doesn't need FastClick (issue #15)
				} else {
					return true;
				}
			}
	
			if (deviceIsBlackBerry10) {
				blackberryVersion = navigator.userAgent.match(
					/Version\/([0-9]*)\.([0-9]*)/);
	
				// BlackBerry 10.3+ does not require Fastclick library.
				// https://github.com/ftlabs/fastclick/issues/251
				if (blackberryVersion[1] >= 10 && blackberryVersion[2] >= 3) {
					metaViewport = document.querySelector('meta[name=viewport]');
	
					if (metaViewport) {
						// user-scalable=no eliminates click delay.
						if (metaViewport.content.indexOf('user-scalable=no') !== -1) {
							return true;
						}
						// width=device-width (or less than device-width) eliminates click delay.
						if (document.documentElement.scrollWidth <= window.outerWidth) {
							return true;
						}
					}
				}
			}
	
			// IE10 with -ms-touch-action: none or manipulation, which disables double-tap-to-zoom (issue #97)
			if (layer.style.msTouchAction === 'none' || layer.style.touchAction ===
				'manipulation') {
				return true;
			}
	
			// Firefox version - zero for other browsers
			firefoxVersion = +(/Firefox\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[
				1];
	
			if (firefoxVersion >= 27) {
				// Firefox 27+ does not have tap delay if the content is not zoomable - https://bugzilla.mozilla.org/show_bug.cgi?id=922896
	
				metaViewport = document.querySelector('meta[name=viewport]');
				if (metaViewport && (metaViewport.content.indexOf('user-scalable=no') !==
						-1 || document.documentElement.scrollWidth <= window.outerWidth)) {
					return true;
				}
			}
	
			// IE11: prefixed -ms-touch-action is no longer supported and it's recomended to use non-prefixed version
			// http://msdn.microsoft.com/en-us/library/windows/apps/Hh767313.aspx
			if (layer.style.touchAction === 'none' || layer.style.touchAction ===
				'manipulation') {
				return true;
			}
	
			return false;
		};
	
	
		/**
		 * Factory method for creating a FastClick object
		 *
		 * @param {Element} layer The layer to listen on
		 * @param {Object} [options={}] The options to override the defaults
		 */
		FastClick.attach = function(layer, options) {
			return new FastClick(layer, options);
		};
	
	
		// if (typeof define === 'function' && define.cmd) {
		// 	define(function(require, exports, module) {
		// 		module.exports = FastClick;
		// 	});
		// } else {
		// 	window.FastClick = FastClick;
		// }
		module.exports = FastClick;
	}());


/***/ }),
/* 20 */,
/* 21 */,
/* 22 */,
/* 23 */,
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, e, module) {
	    var qs = function() {return document.querySelector.apply(document, arguments)};
	
	    var $error = qs('#error'),
	        $errorMsg = qs('#error_msg'),
	        $subTit = qs('#error_subtit'),
	        $retry = qs('#retry');
	
	    var defer;
	
	    var listener = function() {
	        defer.resolve();
	        $retry.removeEventListener('click', listener);
	        $error.style.display = 'none';
	    };
	
	    module.exports = function(msg, btnTxt, subTit, def) {
	        defer = def || $.Deferred();
	        $errorMsg.textContent = msg;
	        $retry.textContent = btnTxt;
	        subTit && ($subTit.textContent = subTit);
	        $error.style.display = 'block';
	        $retry.addEventListener('click', listener);
	        return typeof defer.promise == 'function' ? defer.promise() : defer.promise;
	    };
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),
/* 25 */,
/* 26 */,
/* 27 */,
/* 28 */,
/* 29 */,
/* 30 */,
/* 31 */,
/* 32 */,
/* 33 */,
/* 34 */,
/* 35 */,
/* 36 */,
/* 37 */,
/* 38 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, e, module) {
	    var $loading = document.querySelector('#loading');
	
	    module.exports = {
	        loaded: function loaded() {
	            $loading.style.display = 'none';
	        },
	        loading: function loading() {
	            $loading.style.display = 'block';
	        }
	    };
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),
/* 39 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;/**
	 * 由于QZHTTP的json callback命名不能含有"."
	 * 所以angular的jsonp服务就这样被鄙视了。
	 * 所以就要手动修复
	 * #远古代码虐我千百遍
	 */
	(function(factory) {
		!(__WEBPACK_AMD_DEFINE_RESULT__ = function(require, exports, module) {
			module.exports = function(ngModule) {
				factory(ngModule);
			}
		}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	})(function(ngModule) {
		ngModule
			.config(['$httpProvider', function($hp) {
				$hp.interceptors.push('jsonpInterceptor');
			}])
			.factory('jsonpInterceptor', ['$timeout', '$window', '$q', function($timeout, $window, $q) {
				return {
					'request': function(config) {
						if (config.method === 'JSONP') {
							var callbackId = angular.callbacks.counter.toString(36);
							config.callbackName = 'angular_callbacks_' + callbackId;
							config.url = config.url.replace('JSON_CALLBACK', config.callbackName);
	
							$timeout(function() {
								$window[config.callbackName] = angular.callbacks['_' + callbackId];
							}, 0, false);
						}
	
						return config;
					},
	
					'response': function(response) {
						var config = response.config;
						if (config.method === 'JSONP') {
							delete $window[config.callbackName]; // cleanup
						}
	
						return response;
					},
	
					'responseError': function(rejection) {
						var config = rejection.config;
						if (config.method === 'JSONP') {
							delete $window[config.callbackName]; // cleanup
						}
	
						return $q.reject(rejection);
					}
				};
			}]);
	});


/***/ }),
/* 40 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;(function (factory) {
		!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, exports, module) {
			module.exports = function (ngModule) {
				__webpack_require__(41)(ngModule);
				factory(ngModule);
			}
		}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	})(function (ngModule) {
		ngModule
			.factory('$getUrlParam', ['$filterXSS', function ($filterXSS) {
	
				return function (name, url) {
					var r = new RegExp("(\\?|#|&)" + name + "=([^&#]*)(&|#|$)");
					url = url || location.href;
					var m = url.match(r);
					return (!m ? "" : $filterXSS(m[2]));
				};
			}]);
	});

/***/ }),
/* 41 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;(function (factory) {
		!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, exports, module) {
			module.exports = function (ngModule) {
				factory(ngModule);
			}
		}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	})(function (ngModule) {
		ngModule
			.factory('$filterXSS', function () {
	
				return function (str) {
					if (typeof str != "string")return str;
					return str.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;").replace(/\'/g, "&apos;");
				};
			});
	});

/***/ }),
/* 42 */
/***/ (function(module, exports, __webpack_require__) {

	/**
	 */
	var boss = __webpack_require__(2);
	module.exports = function(ngModule, event) {
		boss(event);//pv
		ngModule
				.directive('boss', function() {
					return {
						link: function($scope, element) {
							element.on('click', function() {
								boss(element.attr('_boss'));
							});
						}
					};
				});
	};

/***/ }),
/* 43 */,
/* 44 */,
/* 45 */,
/* 46 */,
/* 47 */,
/* 48 */,
/* 49 */,
/* 50 */,
/* 51 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;(function(func) {
		!(__WEBPACK_AMD_DEFINE_RESULT__ = function(require, exports, module) {
			exports.registerNgService = function(ngModule) {
				ngModule.factory('$txvAreaData', ['$http', function($http) {
					return function(city_id) {
						return func(city_id, $http);
					};
				}]);
			};
		}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	})(function(city_id, $http) {
		return $http.jsonp("https://data.video.qq.com/fcgi-bin/dataout?auto_id=1744&otype=json&callback=JSON_CALLBACK", {
			params: {
				otype: 'json',
				city: city_id
			}
		}).error(function() {
			return $http.jsonp("https://data.video.qq.com/fcgi-bin/dataout?auto_id=1744&otype=json&callback=JSON_CALLBACK", {
				params: {
					otype: 'json',
					city: city_id
				}
			});
		}).success(function(ret) {
			return ret.town.unshift({
				id: 0,
				n: "全部"
			});
		});
	});

/***/ })
/******/ ]);