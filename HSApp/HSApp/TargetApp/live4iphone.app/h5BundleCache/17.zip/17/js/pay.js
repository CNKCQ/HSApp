/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	var boss = __webpack_require__(2);
	boss.delegate('app_v_pay');
	var orderid = $.util.getUrlParam("order_id");
	var userDef = __webpack_require__(27),
		toAppData = {},
		refreshTimer = null;
	
	var template = __webpack_require__(9);
	template.helper("https", function (url) {
		return url.replace ? url.replace('http', 'https') : url;
	});
	window.onerror = function (l, s, t) {
		$("#log").append("window.onerror INFO_FILE_LINE", l + "_" + s + "_" + t + "<br/>");
	}
	
	
	function formatTimeBySec(s, formatStr, isShowZero, isShowZeroSec) {
		if (isNaN(s) || typeof formatStr != "string") {
			return "";
		}
		var ret = {};
		isShowZero = typeof isShowZero == 'boolean' ? isShowZero : true;
		isShowZeroSec = typeof isShowZeroSec == 'boolean' ? isShowZeroSec : true;
		ret.h = Math.floor(s / 3600);
		ret.hh = ret.h < 10 ? ("0" + ret.h) : ret.h;
		ret.m = Math.floor(s / 60) - ret.h * 60;
		if (!(/{h+}/.test(formatStr))) {
			ret.m += ret.h * 60;
		}
		ret.mm = ret.m < 10 ? ("0" + ret.m) : ret.m;
		ret.s = s % 60;
		if (!(/{m+}/.test(formatStr))) {
			ret.s += ret.m * 60;
		}
		ret.ss = ret.s < 10 ? ("0" + ret.s) : ret.s;
		if (ret.h < 1 && !isShowZero) {
			formatStr = formatStr.replace(/{h+}[^{]+/, "");
			if (ret.m < 1) {
				formatStr = formatStr.replace(/{m+}[^{]+/, "");
			}
		}
		if (ret.s < 1 && !isShowZeroSec) {
			formatStr = formatStr.replace(/{s+}[^{]+/, "");
		}
		return formatStr.replace(/{([smh]+)}/g, function (m, key) {
			return typeof(ret[key]) === "undefined" ? m : ret[key];
		});
	}
	
	function setCount(expireSecond) {
		var timer = null;
	
		function countDown() {
			expireSecond--;
			$("#count").html(formatTimeBySec(expireSecond, "{mm}:{ss}"));
			if (expireSecond <= 0) {
				gotoResult();
				clearTimeout(timer)
			}
			else {
				timer = setTimeout(countDown, 1000);
			}
		}
	
		timer = setTimeout(countDown, 1000);
	
	}
	loadInfo();
	function loadInfo() {
		userDef.done(function (user) {
			var payfn = __webpack_require__(28),
				paydef = payfn($.extend({
					order_id: orderid
				}, user));
	
			paydef.done(function (res) {//取微信支付的必要数据
				var data = {},
					wxprev = "wx_";
				for (var k in res) {
					if (k.indexOf(wxprev) == 0) {
						toAppData[k.substr(3)] = res[k];
					}
				}
				$("#gotopay").show();
				$("#log").append("toAppData:" + JSON.stringify(toAppData) + "<br/>")
			}).always(function (res) {
				$("#log").append("response:" + JSON.stringify(res) + "<br/>" + "<br/>")
			}).fail(function (res) {
	
			});
			var orderfn = __webpack_require__(29),//取订单详情
				orderdef = orderfn($.extend({
					order_id: orderid
				}, user));
	
			orderdef.done(function (res) {
				if (res && res.status != 1) {//状态不是待支付，
					gotoResult();
				}
			});
	
			$.when(paydef, orderdef).done(function (d1, d2) {
				if (d2.price) {
					if (d2.price % 100) {
						d2.price = (d2.price / 100).toFixed(2) + "元";
					}
					else {
						d2.price = (d2.price / 100)
					}
				}
	
				if (d2.price_discount) {
					if (d2.price_discount % 100) {
						d2.price_discount = (d2.price_discount / 100).toFixed(2) + "元";
					}
					else {
						d2.price_discount = (d2.price_discount / 100)
					}
				}
				var expire = d1.expired_time;
				d2.expire = formatTimeBySec(expire, "{mm}:{ss}")
				var orderbase = __webpack_require__(30),
					theater_info = __webpack_require__(31),
					plat_info = __webpack_require__(33);
				$(document.body).append(orderbase(d2) + theater_info(d2) + plat_info(d2));
	
				setCount(expire);
			}).fail(function (wx, status) {
				var error = __webpack_require__(24),
					msg = getErrorCode(wx, status),
					def = error("获取支付信息失败了", "点击重新获取", msg);
				def.done(loadInfo);
			}).always(function () {
				$("#loading").hide();
			})
		});
	}
	
	function getErrorCode(wx, status) {
		if (wx && wx.retcode == -11 || status && status.retcode == -11) {
			openLogin();
			return "";
		}
		if (wx && wx.retcode) {
			return wx.errmsg + "," + "错误码：" + wx.retcode;
		}
		if (status && status.retcode) {
			return wx.errmsg + "," + "错误码：" + status.retcode;
		}
		return "请检查网络连接是否出错";
	}
	
	
	$(document.body).on("click", "#gotopay", function (event) {
		event.preventDefault();
		$("#log").append("start invoke pullWXPay:" + "<br/>")
		TenvideoJSBridge.invoke("pullWXPay", toAppData, function (res) {
			clearTimeout(refreshTimer);
			var code = "",
				old = res;
			$("#log").append("after pullWXPay:" + JSON.stringify(res) + "<br/>")
			if (typeof res == "string") {
				try {
					res = JSON.parse(res);
					code = res.errCode;
					if (typeof res.errCode == "undefined") {
						code = old;
					}
	
				}
				catch (e) {
					code = -1;
				}
			}
			if (code == 0) {
				gotoResult(true);
			}
			else if (code == -1) {
				alert("支付失败")
			}
			else if (code == 404) {//无网络
				__webpack_require__(34)("支付失败了，请检查网络连接后重新点击支付")
			}
			else if (code == -2) {//用户取消，无需操作
	
			}
		});
	
		$("#log").append("invoke pullWXPay end:" + "<br/>")
	});
	
	
	function gotoResult(forceSuccess) {
		var url = "result.html?order_id=" + orderid;
		if (forceSuccess) {
			url += "&success=1"
		}
		if (typeof history.replaceState == "function") {
			history.replaceState({}, "", url);
		}
		document.location.replace(url)
	}
	
	function openLogin() {
		QQVideoBridge.loginTv().done(function (res) {
			var msgtit = "",
				btnTxt = "点击登录";
			if (res && res.data) {
				if (res.data.errCode == 2) {
					msgtit = "需要登录才能进行支付";
					//用户取消登录
				}
				else if (res.data.errCode == 1) {
					msgtit = "登录失败了，需要登录才能进行支付";
					btnTxt = "点击重新登录"
					//登录失败
				}
				else if (res.data.errCode == 0) {
					location.reload();
					return;
				}
			}
			var error = __webpack_require__(24),
				def = error(msgtit, btnTxt, "");
			def.done(openLogin);
		})
	}
	QQVideoBridge.setMoreInfo({"hasRefresh": true, "hasShare": false, "hasFollow": false});
	
	
	QQVideoBridge.on("onAppEnterForeground", function () {
		$("#log").append("onAppEnterForeground,切回前台了" + "<br/>")
		refreshTimer = setTimeout(function () {
			location.reload();
		}, 2000)
	})
	


/***/ }),
/* 1 */,
/* 2 */
/***/ (function(module, exports) {

	// http://tapd.oa.com/tvideo/prong/stories/view/1010031991056992805?url_cache_key=dc4c5bdd3ef3797a13e788c323168a6f&action_entry_type=story_tree_list
	var sessionStorage = window.sessionStorage || {
			getItem: function () {
			}, setItem: function () {
			}, removeItem: function () {
			}
		};
	var base_url = "https://btrace.qq.com/kvcollect?BossId=3243&Pwd=1546101498&plat=1&ua=" + navigator.userAgent + "&_dc=" + Math.random();
	var ref;
	
	
	//播放页来源
	if (location.href.indexOf('app.package.play') != -1) {
		sessionStorage.setItem('piao-ref', ref = 11);
	} else if (location.href.indexOf('app.package.user') != -1 || location.href.indexOf('app.package.channel') != -1) {
		sessionStorage.setItem('piao-ref', ref = 12);
	} else {
		ref = sessionStorage.getItem('piao-ref') || 12;
	}
	base_url += '&ref=' + ref;
	
	var exp = function (event, cid) {
		var g_btrace_BOSS = new Image(1, 1);
		g_btrace_BOSS.src = base_url + '&event=' + event + (cid ? ('&cid=' + cid) : '');
	};
	exp.delegate = function (event) {
		var $ = window.jQuery || window.Zepto;
		exp(event);//pv
		$(document.body).on('click', '[_boss]', function (e) {
			exp($(e.currentTarget).attr('_boss'));
		});
	};
	module.exports = exp;

/***/ }),
/* 3 */,
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */
/***/ (function(module, exports) {

	/*TMODJS:{}*/
	!function () {
		function a(a, b) {
			return (/string|function/.test(typeof b) ? h : g)(a, b)
		}
	
		function b(a, c) {
			return "string" != typeof a && (c = typeof a, "number" === c ? a += "" : a = "function" === c ? b(a.call(a)) : ""), a
		}
	
		function c(a) {
			return l[a]
		}
	
		function d(a) {
			return b(a).replace(/&(?![\w#]+;)|[<>"']/g, c)
		}
	
		function e(a, b) {
			if (m(a))for (var c = 0, d = a.length; d > c; c++)b.call(a, a[c], c, a); else for (c in a)b.call(a, a[c], c)
		}
	
		function f(a, b) {
			var c = /(\/)[^\/]+\1\.\.\1/, d = ("./" + a).replace(/[^\/]+$/, ""), e = d + b;
			for (e = e.replace(/\/\.\//g, "/"); e.match(c);)e = e.replace(c, "/");
			return e
		}
	
		function g(b, c) {
			var d = a.get(b) || i({filename: b, name: "Render Error", message: "Template not found"});
			return c ? d(c) : d
		}
	
		function h(a, b) {
			if ("string" == typeof b) {
				var c = b;
				b = function () {
					return new k(c)
				}
			}
			var d = j[a] = function (c) {
				try {
					return new b(c, a) + ""
				} catch (d) {
					return i(d)()
				}
			};
			return d.prototype = b.prototype = n, d.toString = function () {
				return b + ""
			}, d
		}
	
		function i(a) {
			var b = "{Template Error}", c = a.stack || "";
			if (c)c = c.split("\n").slice(0, 2).join("\n"); else for (var d in a)c += "<" + d + ">\n" + a[d] + "\n\n";
			return function () {
				return "object" == typeof console && console.error(b + "\n\n" + c), b
			}
		}
	
		var j = a.cache = {}, k = this.String, l = {
			"<": "&#60;",
			">": "&#62;",
			'"': "&#34;",
			"'": "&#39;",
			"&": "&#38;"
		}, m = Array.isArray || function (a) {
				return "[object Array]" === {}.toString.call(a)
			}, n = a.utils = {
			$helpers: {}, $include: function (a, b, c) {
				return a = f(c, a), g(a, b)
			}, $string: b, $escape: d, $each: e
		}, o = a.helpers = n.$helpers;
		a.get = function (a) {
			return j[a.replace(/^\.\//, "")]
		}, a.helper = function (a, b) {
			o[a] = b
		}, module.exports = a
	}();

/***/ }),
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */,
/* 14 */,
/* 15 */,
/* 16 */,
/* 17 */,
/* 18 */,
/* 19 */,
/* 20 */,
/* 21 */,
/* 22 */,
/* 23 */,
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, e, module) {
	    var qs = function() {return document.querySelector.apply(document, arguments)};
	
	    var $error = qs('#error'),
	        $errorMsg = qs('#error_msg'),
	        $subTit = qs('#error_subtit'),
	        $retry = qs('#retry');
	
	    var defer;
	
	    var listener = function() {
	        defer.resolve();
	        $retry.removeEventListener('click', listener);
	        $error.style.display = 'none';
	    };
	
	    module.exports = function(msg, btnTxt, subTit, def) {
	        defer = def || $.Deferred();
	        $errorMsg.textContent = msg;
	        $retry.textContent = btnTxt;
	        subTit && ($subTit.textContent = subTit);
	        $error.style.display = 'block';
	        $retry.addEventListener('click', listener);
	        return typeof defer.promise == 'function' ? defer.promise() : defer.promise;
	    };
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),
/* 25 */,
/* 26 */,
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function(require,exports,module){
	    //api组件太。。。，完全都没处理，还要页面自己来处理。。。那是什么api。。
	    var userDef = QQVideoBridge.getCookie({type:["tv"]}),
	        def = $.Deferred();
	
	    userDef.done(function(res){
	        console.log(res)
	        if(res.state==0){
	            var tvcookie = res.data.result.tv,
	                reg = /vuserid=(\d+)\;vusession=(\w+)\;/;
	            reg.test(tvcookie);
	            var data = {
	                    vuserid: RegExp.$1,
	                    vusession :RegExp.$2
	                };
	            def.resolve(data)
	        }
	        else{
	            def.reject(res)
	        }
	    }).fail(function(){
	        def.reject(res)
	        alert("get user info failed")
	    });
	
	    module.exports = def.promise();
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__))

/***/ }),
/* 28 */
/***/ (function(module, exports) {

	
	function getData(data,def,isretry){
	    $.ajax({
	        url: "https://ticketapi.video.qq.com/wireless_order_repay?otype=json",
	        data : data,
	        timeout : 120000,
	        dataType: "jsonp"
	    }).done(function(res) {
	        if (res.retcode == 0) {
	            def.resolve(res);
	        }
	        else{
	            if(!isretry){
	                getData(data,def,true)
	            }
	            else{
	                def.reject(res);
	            }
	        }
	    }).fail(function(res) {
	        if(!isretry){
	            getData(data,def,true)
	        }
	        else{
	            def.reject(res);
	        }
	    });
	}
	
	/**
	 *
	 * @param data {vuserid:xx,vusession:x,order_id:xx}
	 * @returns {*|Object}
	 */
	module.exports = function(data){
	    var def = $.Deferred();
	    getData(data,def);
	    return def.promise();
	};


/***/ }),
/* 29 */
/***/ (function(module, exports) {

	
	function getData(data,def,isretry){
	    $.ajax({
	        url: "https://ticketapi.video.qq.com/wireless_order_status?otype=json",
	        data : data,
	        timeout : 120000,
	        dataType: "jsonp"
	    }).done(function(res) {
	        if (res.retcode == 0) {
	            def.resolve(res);
	        }
	        else{
	            if(!isretry){
	                getData(data,def,true)
	            }
	            else{
	                def.reject(res);
	            }
	        }
	    }).fail(function(res) {
	        if(!isretry){
	            getData(data,def,true)
	        }
	        else{
	            def.reject(res);
	        }
	    });
	}
	
	/**
	 *
	 * @param data {vuserid:xx,vusession:x,order_id:xx}
	 * @returns {*|Object}
	 */
	module.exports = function(data){
	    var def = $.Deferred();
	    getData(data,def);
	    return def.promise();
	};

/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

	var template=__webpack_require__(9);
	module.exports=template('tpl/pay/order_base',function($data,$filename
	/*``*/) {
	'use strict';var $utils=this,$helpers=$utils.$helpers,$escape=$utils.$escape,expire=$data.expire,price_discount=$data.price_discount,price=$data.price,$out='';$out+='<div class="section_board"> <p class="notice_count">请在<span class="inner" id="count">';
	$out+=$escape(expire);
	$out+='</span>内完成支付， 逾期座位将不再保留。</p> <p class="txt">订单金额</p> <p class="price" id="price">￥';
	$out+=$escape(price_discount ? price_discount : price);
	$out+='</p> <a href="javascript:;" class="btn_strong btn_payment" id="gotopay" _boss="app_b_pay_result"><i class="icon_wechat"></i>去微信支付</a> </div> ';
	return new String($out);
	});

/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

	
	var theater_info = __webpack_require__(32);
	module.exports = function(data){
	    if (data.seats) {
	        data.seats = data.seats.split("、");
	    }
	    return theater_info(data);
	};


/***/ }),
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

	var template=__webpack_require__(9);
	module.exports=template('tpl/result/theater_info',function($data,$filename
	/*``*/) {
	'use strict';var $utils=this,$helpers=$utils.$helpers,$escape=$utils.$escape,film_poster=$data.film_poster,film_name=$data.film_name,theater_name=$data.theater_name,film_date=$data.film_date,film_time=$data.film_time,theater_addr=$data.theater_addr,recv_phone=$data.recv_phone,$each=$utils.$each,seats=$data.seats,seat=$data.seat,$index=$data.$index,$out='';$out+='<ul class="ticket_list"> <li class="item"> <div class="figure_ticket"> <a href="javascript:;" class="figure"><img alt="" src="';
	$out+=$escape($helpers. https(film_poster ));
	$out+='"></a> <h5 class="title">';
	$out+=$escape(film_name);
	$out+='</h5> <p class="txt">';
	$out+=$escape(theater_name);
	$out+=' ';
	$out+=$escape(film_date.substr(5));
	$out+=' ';
	$out+=$escape(film_time);
	$out+='</p> <p class="txt">';
	$out+=$escape(theater_addr);
	$out+='</p> <p class="txt">接收兑换码手机号：';
	$out+=$escape(recv_phone);
	$out+='</p> </div> <div class="item_btm">';
	$each(seats,function(seat,$index){
	$out+=' <a href="javascript:;" class="btn_simi">';
	$out+=$escape(seat);
	$out+='</a>';
	});
	$out+=' </div> </li> </ul>';
	return new String($out);
	});

/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

	var template=__webpack_require__(9);
	module.exports=template('tpl/result/plat_info',function($data,$filename
	/*``*/) {
	'use strict';var $utils=this,$helpers=$utils.$helpers,$escape=$utils.$escape,c_name=$data.c_name,c_phone=$data.c_phone,$out='';$out+='<section class="ticket_explain"> <p class="txt">票由';
	$out+=$escape(c_name);
	$out+='提供，支付后不可退换。</p> <p class="txt">客服电话：</p> <a class="strong" href="tel:';
	$out+=$escape(c_phone);
	$out+='">';
	$out+=$escape(c_phone);
	$out+='</a> </section>';
	return new String($out);
	});

/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function(r, e, module) {
		var $toast = $('#toast'),
			$msg = $toast.find('p'),
			timer;
	
		module.exports = function(msg) {
	        $msg.text(msg);
			$toast.show();
			if (timer) {
				clearTimeout(timer);
			}
			timer = setTimeout(function() {
				$toast.hide();
			}, 2000);
		};
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ })
/******/ ]);