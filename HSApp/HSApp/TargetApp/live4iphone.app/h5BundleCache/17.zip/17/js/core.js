/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	__webpack_require__(16);
	__webpack_require__(17);
	__webpack_require__(18);
	__webpack_require__(19);
	__webpack_require__(20);
	module.exports = __webpack_require__(21);


/***/ }),
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */,
/* 14 */,
/* 15 */,
/* 16 */
/***/ (function(module, exports) {

	/* Zepto v1.1.4 - zepto event ajax form ie - zeptojs.com/license */
	var Zepto=function(){function L(t){return null==t?String(t):j[S.call(t)]||"object"}function Z(t){return"function"==L(t)}function $(t){return null!=t&&t==t.window}function _(t){return null!=t&&t.nodeType==t.DOCUMENT_NODE}function D(t){return"object"==L(t)}function R(t){return D(t)&&!$(t)&&Object.getPrototypeOf(t)==Object.prototype}function M(t){return"number"==typeof t.length}function k(t){return s.call(t,function(t){return null!=t})}function z(t){return t.length>0?n.fn.concat.apply([],t):t}function F(t){return t.replace(/::/g,"/").replace(/([A-Z]+)([A-Z][a-z])/g,"$1_$2").replace(/([a-z\d])([A-Z])/g,"$1_$2").replace(/_/g,"-").toLowerCase()}function q(t){return t in f?f[t]:f[t]=new RegExp("(^|\\s)"+t+"(\\s|$)")}function H(t,e){return"number"!=typeof e||c[F(t)]?e:e+"px"}function I(t){var e,n;return u[t]||(e=a.createElement(t),a.body.appendChild(e),n=getComputedStyle(e,"").getPropertyValue("display"),e.parentNode.removeChild(e),"none"==n&&(n="block"),u[t]=n),u[t]}function V(t){return"children"in t?o.call(t.children):n.map(t.childNodes,function(t){return 1==t.nodeType?t:void 0})}function B(n,i,r){for(e in i)r&&(R(i[e])||A(i[e]))?(R(i[e])&&!R(n[e])&&(n[e]={}),A(i[e])&&!A(n[e])&&(n[e]=[]),B(n[e],i[e],r)):i[e]!==t&&(n[e]=i[e])}function U(t,e){return null==e?n(t):n(t).filter(e)}function J(t,e,n,i){return Z(e)?e.call(t,n,i):e}function X(t,e,n){null==n?t.removeAttribute(e):t.setAttribute(e,n)}function W(e,n){var i=e.className,r=i&&i.baseVal!==t;return n===t?r?i.baseVal:i:void(r?i.baseVal=n:e.className=n)}function Y(t){var e;try{return t?"true"==t||("false"==t?!1:"null"==t?null:/^0/.test(t)||isNaN(e=Number(t))?/^[\[\{]/.test(t)?n.parseJSON(t):t:e):t}catch(i){return t}}function G(t,e){e(t);for(var n=0,i=t.childNodes.length;i>n;n++)G(t.childNodes[n],e)}var t,e,n,i,C,N,r=[],o=r.slice,s=r.filter,a=window.document,u={},f={},c={"column-count":1,columns:1,"font-weight":1,"line-height":1,opacity:1,"z-index":1,zoom:1},l=/^\s*<(\w+|!)[^>]*>/,h=/^<(\w+)\s*\/?>(?:<\/\1>|)$/,p=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,d=/^(?:body|html)$/i,m=/([A-Z])/g,g=["val","css","html","text","data","width","height","offset"],v=["after","prepend","before","append"],y=a.createElement("table"),x=a.createElement("tr"),b={tr:a.createElement("tbody"),tbody:y,thead:y,tfoot:y,td:x,th:x,"*":a.createElement("div")},w=/complete|loaded|interactive/,E=/^[\w-]*$/,j={},S=j.toString,T={},O=a.createElement("div"),P={tabindex:"tabIndex",readonly:"readOnly","for":"htmlFor","class":"className",maxlength:"maxLength",cellspacing:"cellSpacing",cellpadding:"cellPadding",rowspan:"rowSpan",colspan:"colSpan",usemap:"useMap",frameborder:"frameBorder",contenteditable:"contentEditable"},A=Array.isArray||function(t){return t instanceof Array};return T.matches=function(t,e){if(!e||!t||1!==t.nodeType)return!1;var n=t.webkitMatchesSelector||t.mozMatchesSelector||t.oMatchesSelector||t.matchesSelector;if(n)return n.call(t,e);var i,r=t.parentNode,o=!r;return o&&(r=O).appendChild(t),i=~T.qsa(r,e).indexOf(t),o&&O.removeChild(t),i},C=function(t){return t.replace(/-+(.)?/g,function(t,e){return e?e.toUpperCase():""})},N=function(t){return s.call(t,function(e,n){return t.indexOf(e)==n})},T.fragment=function(e,i,r){var s,u,f;return h.test(e)&&(s=n(a.createElement(RegExp.$1))),s||(e.replace&&(e=e.replace(p,"<$1></$2>")),i===t&&(i=l.test(e)&&RegExp.$1),i in b||(i="*"),f=b[i],f.innerHTML=""+e,s=n.each(o.call(f.childNodes),function(){f.removeChild(this)})),R(r)&&(u=n(s),n.each(r,function(t,e){g.indexOf(t)>-1?u[t](e):u.attr(t,e)})),s},T.Z=function(t,e){return t=t||[],t.__proto__=n.fn,t.selector=e||"",t},T.isZ=function(t){return t instanceof T.Z},T.init=function(e,i){var r;if(!e)return T.Z();if("string"==typeof e)if(e=e.trim(),"<"==e[0]&&l.test(e))r=T.fragment(e,RegExp.$1,i),e=null;else{if(i!==t)return n(i).find(e);r=T.qsa(a,e)}else{if(Z(e))return n(a).ready(e);if(T.isZ(e))return e;if(A(e))r=k(e);else if(D(e))r=[e],e=null;else if(l.test(e))r=T.fragment(e.trim(),RegExp.$1,i),e=null;else{if(i!==t)return n(i).find(e);r=T.qsa(a,e)}}return T.Z(r,e)},n=function(t,e){return T.init(t,e)},n.extend=function(t){var e,n=o.call(arguments,1);return"boolean"==typeof t&&(e=t,t=n.shift()),n.forEach(function(n){B(t,n,e)}),t},T.qsa=function(t,e){var n,i="#"==e[0],r=!i&&"."==e[0],s=i||r?e.slice(1):e,a=E.test(s);return _(t)&&a&&i?(n=t.getElementById(s))?[n]:[]:1!==t.nodeType&&9!==t.nodeType?[]:o.call(a&&!i?r?t.getElementsByClassName(s):t.getElementsByTagName(e):t.querySelectorAll(e))},n.contains=a.documentElement.contains?function(t,e){return t!==e&&t.contains(e)}:function(t,e){for(;e&&(e=e.parentNode);)if(e===t)return!0;return!1},n.type=L,n.isFunction=Z,n.isWindow=$,n.isArray=A,n.isPlainObject=R,n.isEmptyObject=function(t){var e;for(e in t)return!1;return!0},n.inArray=function(t,e,n){return r.indexOf.call(e,t,n)},n.camelCase=C,n.trim=function(t){return null==t?"":String.prototype.trim.call(t)},n.uuid=0,n.support={},n.expr={},n.map=function(t,e){var n,r,o,i=[];if(M(t))for(r=0;r<t.length;r++)n=e(t[r],r),null!=n&&i.push(n);else for(o in t)n=e(t[o],o),null!=n&&i.push(n);return z(i)},n.each=function(t,e){var n,i;if(M(t)){for(n=0;n<t.length;n++)if(e.call(t[n],n,t[n])===!1)return t}else for(i in t)if(e.call(t[i],i,t[i])===!1)return t;return t},n.grep=function(t,e){return s.call(t,e)},window.JSON&&(n.parseJSON=JSON.parse),n.each("Boolean Number String Function Array Date RegExp Object Error".split(" "),function(t,e){j["[object "+e+"]"]=e.toLowerCase()}),n.fn={forEach:r.forEach,reduce:r.reduce,push:r.push,sort:r.sort,indexOf:r.indexOf,concat:r.concat,map:function(t){return n(n.map(this,function(e,n){return t.call(e,n,e)}))},slice:function(){return n(o.apply(this,arguments))},ready:function(t){return w.test(a.readyState)&&a.body?t(n):a.addEventListener("DOMContentLoaded",function(){t(n)},!1),this},get:function(e){return e===t?o.call(this):this[e>=0?e:e+this.length]},toArray:function(){return this.get()},size:function(){return this.length},remove:function(){return this.each(function(){null!=this.parentNode&&this.parentNode.removeChild(this)})},each:function(t){return r.every.call(this,function(e,n){return t.call(e,n,e)!==!1}),this},filter:function(t){return Z(t)?this.not(this.not(t)):n(s.call(this,function(e){return T.matches(e,t)}))},add:function(t,e){return n(N(this.concat(n(t,e))))},is:function(t){return this.length>0&&T.matches(this[0],t)},not:function(e){var i=[];if(Z(e)&&e.call!==t)this.each(function(t){e.call(this,t)||i.push(this)});else{var r="string"==typeof e?this.filter(e):M(e)&&Z(e.item)?o.call(e):n(e);this.forEach(function(t){r.indexOf(t)<0&&i.push(t)})}return n(i)},has:function(t){return this.filter(function(){return D(t)?n.contains(this,t):n(this).find(t).size()})},eq:function(t){return-1===t?this.slice(t):this.slice(t,+t+1)},first:function(){var t=this[0];return t&&!D(t)?t:n(t)},last:function(){var t=this[this.length-1];return t&&!D(t)?t:n(t)},find:function(t){var e,i=this;return e=t?"object"==typeof t?n(t).filter(function(){var t=this;return r.some.call(i,function(e){return n.contains(e,t)})}):1==this.length?n(T.qsa(this[0],t)):this.map(function(){return T.qsa(this,t)}):[]},closest:function(t,e){var i=this[0],r=!1;for("object"==typeof t&&(r=n(t));i&&!(r?r.indexOf(i)>=0:T.matches(i,t));)i=i!==e&&!_(i)&&i.parentNode;return n(i)},parents:function(t){for(var e=[],i=this;i.length>0;)i=n.map(i,function(t){return(t=t.parentNode)&&!_(t)&&e.indexOf(t)<0?(e.push(t),t):void 0});return U(e,t)},parent:function(t){return U(N(this.pluck("parentNode")),t)},children:function(t){return U(this.map(function(){return V(this)}),t)},contents:function(){return this.map(function(){return o.call(this.childNodes)})},siblings:function(t){return U(this.map(function(t,e){return s.call(V(e.parentNode),function(t){return t!==e})}),t)},empty:function(){return this.each(function(){this.innerHTML=""})},pluck:function(t){return n.map(this,function(e){return e[t]})},show:function(){return this.each(function(){"none"==this.style.display&&(this.style.display=""),"none"==getComputedStyle(this,"").getPropertyValue("display")&&(this.style.display=I(this.nodeName))})},replaceWith:function(t){return this.before(t).remove()},wrap:function(t){var e=Z(t);if(this[0]&&!e)var i=n(t).get(0),r=i.parentNode||this.length>1;return this.each(function(o){n(this).wrapAll(e?t.call(this,o):r?i.cloneNode(!0):i)})},wrapAll:function(t){if(this[0]){n(this[0]).before(t=n(t));for(var e;(e=t.children()).length;)t=e.first();n(t).append(this)}return this},wrapInner:function(t){var e=Z(t);return this.each(function(i){var r=n(this),o=r.contents(),s=e?t.call(this,i):t;o.length?o.wrapAll(s):r.append(s)})},unwrap:function(){return this.parent().each(function(){n(this).replaceWith(n(this).children())}),this},clone:function(){return this.map(function(){return this.cloneNode(!0)})},hide:function(){return this.css("display","none")},toggle:function(e){return this.each(function(){var i=n(this);(e===t?"none"==i.css("display"):e)?i.show():i.hide()})},prev:function(t){return n(this.pluck("previousElementSibling")).filter(t||"*")},next:function(t){return n(this.pluck("nextElementSibling")).filter(t||"*")},html:function(t){return 0 in arguments?this.each(function(e){var i=this.innerHTML;n(this).empty().append(J(this,t,e,i))}):0 in this?this[0].innerHTML:null},text:function(t){return 0 in arguments?this.each(function(e){var n=J(this,t,e,this.textContent);this.textContent=null==n?"":""+n}):0 in this?this[0].textContent:null},attr:function(n,i){var r;return"string"!=typeof n||1 in arguments?this.each(function(t){if(1===this.nodeType)if(D(n))for(e in n)X(this,e,n[e]);else X(this,n,J(this,i,t,this.getAttribute(n)))}):this.length&&1===this[0].nodeType?!(r=this[0].getAttribute(n))&&n in this[0]?this[0][n]:r:t},removeAttr:function(t){return this.each(function(){1===this.nodeType&&X(this,t)})},prop:function(t,e){return t=P[t]||t,1 in arguments?this.each(function(n){this[t]=J(this,e,n,this[t])}):this[0]&&this[0][t]},data:function(e,n){var i="data-"+e.replace(m,"-$1").toLowerCase(),r=1 in arguments?this.attr(i,n):this.attr(i);return null!==r?Y(r):t},val:function(t){return 0 in arguments?this.each(function(e){this.value=J(this,t,e,this.value)}):this[0]&&(this[0].multiple?n(this[0]).find("option").filter(function(){return this.selected}).pluck("value"):this[0].value)},offset:function(t){if(t)return this.each(function(e){var i=n(this),r=J(this,t,e,i.offset()),o=i.offsetParent().offset(),s={top:r.top-o.top,left:r.left-o.left};"static"==i.css("position")&&(s.position="relative"),i.css(s)});if(!this.length)return null;var e=this[0].getBoundingClientRect();return{left:e.left+window.pageXOffset,top:e.top+window.pageYOffset,width:Math.round(e.width),height:Math.round(e.height)}},css:function(t,i){if(arguments.length<2){var r=this[0],o=getComputedStyle(r,"");if(!r)return;if("string"==typeof t)return r.style[C(t)]||o.getPropertyValue(t);if(A(t)){var s={};return n.each(A(t)?t:[t],function(t,e){s[e]=r.style[C(e)]||o.getPropertyValue(e)}),s}}var a="";if("string"==L(t))i||0===i?a=F(t)+":"+H(t,i):this.each(function(){this.style.removeProperty(F(t))});else for(e in t)t[e]||0===t[e]?a+=F(e)+":"+H(e,t[e])+";":this.each(function(){this.style.removeProperty(F(e))});return this.each(function(){this.style.cssText+=";"+a})},index:function(t){return t?this.indexOf(n(t)[0]):this.parent().children().indexOf(this[0])},hasClass:function(t){return t?r.some.call(this,function(t){return this.test(W(t))},q(t)):!1},addClass:function(t){return t?this.each(function(e){i=[];var r=W(this),o=J(this,t,e,r);o.split(/\s+/g).forEach(function(t){n(this).hasClass(t)||i.push(t)},this),i.length&&W(this,r+(r?" ":"")+i.join(" "))}):this},removeClass:function(e){return this.each(function(n){return e===t?W(this,""):(i=W(this),J(this,e,n,i).split(/\s+/g).forEach(function(t){i=i.replace(q(t)," ")}),void W(this,i.trim()))})},toggleClass:function(e,i){return e?this.each(function(r){var o=n(this),s=J(this,e,r,W(this));s.split(/\s+/g).forEach(function(e){(i===t?!o.hasClass(e):i)?o.addClass(e):o.removeClass(e)})}):this},scrollTop:function(e){if(this.length){var n="scrollTop"in this[0];return e===t?n?this[0].scrollTop:this[0].pageYOffset:this.each(n?function(){this.scrollTop=e}:function(){this.scrollTo(this.scrollX,e)})}},scrollLeft:function(e){if(this.length){var n="scrollLeft"in this[0];return e===t?n?this[0].scrollLeft:this[0].pageXOffset:this.each(n?function(){this.scrollLeft=e}:function(){this.scrollTo(e,this.scrollY)})}},position:function(){if(this.length){var t=this[0],e=this.offsetParent(),i=this.offset(),r=d.test(e[0].nodeName)?{top:0,left:0}:e.offset();return i.top-=parseFloat(n(t).css("margin-top"))||0,i.left-=parseFloat(n(t).css("margin-left"))||0,r.top+=parseFloat(n(e[0]).css("border-top-width"))||0,r.left+=parseFloat(n(e[0]).css("border-left-width"))||0,{top:i.top-r.top,left:i.left-r.left}}},offsetParent:function(){return this.map(function(){for(var t=this.offsetParent||a.body;t&&!d.test(t.nodeName)&&"static"==n(t).css("position");)t=t.offsetParent;return t})}},n.fn.detach=n.fn.remove,["width","height"].forEach(function(e){var i=e.replace(/./,function(t){return t[0].toUpperCase()});n.fn[e]=function(r){var o,s=this[0];return r===t?$(s)?s["inner"+i]:_(s)?s.documentElement["scroll"+i]:(o=this.offset())&&o[e]:this.each(function(t){s=n(this),s.css(e,J(this,r,t,s[e]()))})}}),v.forEach(function(t,e){var i=e%2;n.fn[t]=function(){var t,o,r=n.map(arguments,function(e){return t=L(e),"object"==t||"array"==t||null==e?e:T.fragment(e)}),s=this.length>1;return r.length<1?this:this.each(function(t,u){o=i?u:u.parentNode,u=0==e?u.nextSibling:1==e?u.firstChild:2==e?u:null;var f=n.contains(a.documentElement,o);r.forEach(function(t){if(s)t=t.cloneNode(!0);else if(!o)return n(t).remove();o.insertBefore(t,u),f&&G(t,function(t){null==t.nodeName||"SCRIPT"!==t.nodeName.toUpperCase()||t.type&&"text/javascript"!==t.type||t.src||window.eval.call(window,t.innerHTML)})})})},n.fn[i?t+"To":"insert"+(e?"Before":"After")]=function(e){return n(e)[t](this),this}}),T.Z.prototype=n.fn,T.uniq=N,T.deserializeValue=Y,n.zepto=T,n}();window.Zepto=Zepto,void 0===window.$&&(window.$=Zepto),function(t){function l(t){return t._zid||(t._zid=e++)}function h(t,e,n,i){if(e=p(e),e.ns)var r=d(e.ns);return(s[l(t)]||[]).filter(function(t){return!(!t||e.e&&t.e!=e.e||e.ns&&!r.test(t.ns)||n&&l(t.fn)!==l(n)||i&&t.sel!=i)})}function p(t){var e=(""+t).split(".");return{e:e[0],ns:e.slice(1).sort().join(" ")}}function d(t){return new RegExp("(?:^| )"+t.replace(" "," .* ?")+"(?: |$)")}function m(t,e){return t.del&&!u&&t.e in f||!!e}function g(t){return c[t]||u&&f[t]||t}function v(e,i,r,o,a,u,f){var h=l(e),d=s[h]||(s[h]=[]);i.split(/\s/).forEach(function(i){if("ready"==i)return t(document).ready(r);var s=p(i);s.fn=r,s.sel=a,s.e in c&&(r=function(e){var n=e.relatedTarget;return!n||n!==this&&!t.contains(this,n)?s.fn.apply(this,arguments):void 0}),s.del=u;var l=u||r;s.proxy=function(t){if(t=j(t),!t.isImmediatePropagationStopped()){t.data=o;var i=l.apply(e,t._args==n?[t]:[t].concat(t._args));return i===!1&&(t.preventDefault(),t.stopPropagation()),i}},s.i=d.length,d.push(s),"addEventListener"in e&&e.addEventListener(g(s.e),s.proxy,m(s,f))})}function y(t,e,n,i,r){var o=l(t);(e||"").split(/\s/).forEach(function(e){h(t,e,n,i).forEach(function(e){delete s[o][e.i],"removeEventListener"in t&&t.removeEventListener(g(e.e),e.proxy,m(e,r))})})}function j(e,i){return(i||!e.isDefaultPrevented)&&(i||(i=e),t.each(E,function(t,n){var r=i[t];e[t]=function(){return this[n]=x,r&&r.apply(i,arguments)},e[n]=b}),(i.defaultPrevented!==n?i.defaultPrevented:"returnValue"in i?i.returnValue===!1:i.getPreventDefault&&i.getPreventDefault())&&(e.isDefaultPrevented=x)),e}function S(t){var e,i={originalEvent:t};for(e in t)w.test(e)||t[e]===n||(i[e]=t[e]);return j(i,t)}var n,e=1,i=Array.prototype.slice,r=t.isFunction,o=function(t){return"string"==typeof t},s={},a={},u="onfocusin"in window,f={focus:"focusin",blur:"focusout"},c={mouseenter:"mouseover",mouseleave:"mouseout"};a.click=a.mousedown=a.mouseup=a.mousemove="MouseEvents",t.event={add:v,remove:y},t.proxy=function(e,n){var s=2 in arguments&&i.call(arguments,2);if(r(e)){var a=function(){return e.apply(n,s?s.concat(i.call(arguments)):arguments)};return a._zid=l(e),a}if(o(n))return s?(s.unshift(e[n],e),t.proxy.apply(null,s)):t.proxy(e[n],e);throw new TypeError("expected function")},t.fn.bind=function(t,e,n){return this.on(t,e,n)},t.fn.unbind=function(t,e){return this.off(t,e)},t.fn.one=function(t,e,n,i){return this.on(t,e,n,i,1)};var x=function(){return!0},b=function(){return!1},w=/^([A-Z]|returnValue$|layer[XY]$)/,E={preventDefault:"isDefaultPrevented",stopImmediatePropagation:"isImmediatePropagationStopped",stopPropagation:"isPropagationStopped"};t.fn.delegate=function(t,e,n){return this.on(e,t,n)},t.fn.undelegate=function(t,e,n){return this.off(e,t,n)},t.fn.live=function(e,n){return t(document.body).delegate(this.selector,e,n),this},t.fn.die=function(e,n){return t(document.body).undelegate(this.selector,e,n),this},t.fn.on=function(e,s,a,u,f){var c,l,h=this;return e&&!o(e)?(t.each(e,function(t,e){h.on(t,s,a,e,f)}),h):(o(s)||r(u)||u===!1||(u=a,a=s,s=n),(r(a)||a===!1)&&(u=a,a=n),u===!1&&(u=b),h.each(function(n,r){f&&(c=function(t){return y(r,t.type,u),u.apply(this,arguments)}),s&&(l=function(e){var n,o=t(e.target).closest(s,r).get(0);return o&&o!==r?(n=t.extend(S(e),{currentTarget:o,liveFired:r}),(c||u).apply(o,[n].concat(i.call(arguments,1)))):void 0}),v(r,e,u,a,s,l||c)}))},t.fn.off=function(e,i,s){var a=this;return e&&!o(e)?(t.each(e,function(t,e){a.off(t,i,e)}),a):(o(i)||r(s)||s===!1||(s=i,i=n),s===!1&&(s=b),a.each(function(){y(this,e,s,i)}))},t.fn.trigger=function(e,n){return e=o(e)||t.isPlainObject(e)?t.Event(e):j(e),e._args=n,this.each(function(){"dispatchEvent"in this?this.dispatchEvent(e):t(this).triggerHandler(e,n)})},t.fn.triggerHandler=function(e,n){var i,r;return this.each(function(s,a){i=S(o(e)?t.Event(e):e),i._args=n,i.target=a,t.each(h(a,e.type||e),function(t,e){return r=e.proxy(i),i.isImmediatePropagationStopped()?!1:void 0})}),r},"focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select keydown keypress keyup error".split(" ").forEach(function(e){t.fn[e]=function(t){return t?this.bind(e,t):this.trigger(e)}}),["focus","blur"].forEach(function(e){t.fn[e]=function(t){return t?this.bind(e,t):this.each(function(){try{this[e]()}catch(t){}}),this}}),t.Event=function(t,e){o(t)||(e=t,t=e.type);var n=document.createEvent(a[t]||"Events"),i=!0;if(e)for(var r in e)"bubbles"==r?i=!!e[r]:n[r]=e[r];return n.initEvent(t,i,!0),j(n)}}(Zepto),function(t){function l(e,n,i){var r=t.Event(n);return t(e).trigger(r,i),!r.isDefaultPrevented()}function h(t,e,i,r){return t.global?l(e||n,i,r):void 0}function p(e){e.global&&0===t.active++&&h(e,null,"ajaxStart")}function d(e){e.global&&!--t.active&&h(e,null,"ajaxStop")}function m(t,e){var n=e.context;return e.beforeSend.call(n,t,e)===!1||h(e,n,"ajaxBeforeSend",[t,e])===!1?!1:void h(e,n,"ajaxSend",[t,e])}function g(t,e,n,i){var r=n.context,o="success";n.success.call(r,t,o,e),i&&i.resolveWith(r,[t,o,e]),h(n,r,"ajaxSuccess",[e,n,t]),y(o,e,n)}function v(t,e,n,i,r){var o=i.context;i.error.call(o,n,e,t),r&&r.rejectWith(o,[n,e,t]),h(i,o,"ajaxError",[n,i,t||e]),y(e,n,i)}function y(t,e,n){var i=n.context;n.complete.call(i,e,t),h(n,i,"ajaxComplete",[e,n]),d(n)}function x(){}function b(t){return t&&(t=t.split(";",2)[0]),t&&(t==f?"html":t==u?"json":s.test(t)?"script":a.test(t)&&"xml")||"text"}function w(t,e){return""==e?t:(t+"&"+e).replace(/[&?]{1,2}/,"?")}function E(e){e.processData&&e.data&&"string"!=t.type(e.data)&&(e.data=t.param(e.data,e.traditional)),!e.data||e.type&&"GET"!=e.type.toUpperCase()||(e.url=w(e.url,e.data),e.data=void 0)}function j(e,n,i,r){return t.isFunction(n)&&(r=i,i=n,n=void 0),t.isFunction(i)||(r=i,i=void 0),{url:e,data:n,success:i,dataType:r}}function T(e,n,i,r){var o,s=t.isArray(n),a=t.isPlainObject(n);t.each(n,function(n,u){o=t.type(u),r&&(n=i?r:r+"["+(a||"object"==o||"array"==o?n:"")+"]"),!r&&s?e.add(u.name,u.value):"array"==o||!i&&"object"==o?T(e,u,i,n):e.add(n,u)})}var i,r,e=0,n=window.document,o=/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,s=/^(?:text|application)\/javascript/i,a=/^(?:text|application)\/xml/i,u="application/json",f="text/html",c=/^\s*$/;t.active=0,t.ajaxJSONP=function(i,r){if(!("type"in i))return t.ajax(i);var f,h,o=i.jsonpCallback,s=(t.isFunction(o)?o():o)||"jsonp"+ ++e,a=n.createElement("script"),u=window[s],c=function(e){t(a).triggerHandler("error",e||"abort")},l={abort:c};return r&&r.promise(l),t(a).on("load error",function(e,n){clearTimeout(h),t(a).off().remove(),"error"!=e.type&&f?g(f[0],l,i,r):v(null,n||"error",l,i,r),window[s]=u,f&&t.isFunction(u)&&u(f[0]),u=f=void 0}),m(l,i)===!1?(c("abort"),l):(window[s]=function(){f=arguments},a.src=i.url.replace(/\?(.+)=\?/,"?$1="+s),n.head.appendChild(a),i.timeout>0&&(h=setTimeout(function(){c("timeout")},i.timeout)),l)},t.ajaxSettings={type:"GET",beforeSend:x,success:x,error:x,complete:x,context:null,global:!0,xhr:function(){return new window.XMLHttpRequest},accepts:{script:"text/javascript, application/javascript, application/x-javascript",json:u,xml:"application/xml, text/xml",html:f,text:"text/plain"},crossDomain:!1,timeout:0,processData:!0,cache:!0},t.ajax=function(e){var n=t.extend({},e||{}),o=t.Deferred&&t.Deferred();for(i in t.ajaxSettings)void 0===n[i]&&(n[i]=t.ajaxSettings[i]);p(n),n.crossDomain||(n.crossDomain=/^([\w-]+:)?\/\/([^\/]+)/.test(n.url)&&RegExp.$2!=window.location.host),n.url||(n.url=window.location.toString()),E(n);var s=n.dataType,a=/\?.+=\?/.test(n.url);if(a&&(s="jsonp"),n.cache!==!1&&(e&&e.cache===!0||"script"!=s&&"jsonp"!=s)||(n.url=w(n.url,"_="+Date.now())),"jsonp"==s)return a||(n.url=w(n.url,n.jsonp?n.jsonp+"=?":n.jsonp===!1?"":"callback=?")),t.ajaxJSONP(n,o);var j,u=n.accepts[s],f={},l=function(t,e){f[t.toLowerCase()]=[t,e]},h=/^([\w-]+:)\/\//.test(n.url)?RegExp.$1:window.location.protocol,d=n.xhr(),y=d.setRequestHeader;if(o&&o.promise(d),n.crossDomain||l("X-Requested-With","XMLHttpRequest"),l("Accept",u||"*/*"),(u=n.mimeType||u)&&(u.indexOf(",")>-1&&(u=u.split(",",2)[0]),d.overrideMimeType&&d.overrideMimeType(u)),(n.contentType||n.contentType!==!1&&n.data&&"GET"!=n.type.toUpperCase())&&l("Content-Type",n.contentType||"application/x-www-form-urlencoded"),n.headers)for(r in n.headers)l(r,n.headers[r]);if(d.setRequestHeader=l,d.onreadystatechange=function(){if(4==d.readyState){d.onreadystatechange=x,clearTimeout(j);var e,i=!1;if(d.status>=200&&d.status<300||304==d.status||0==d.status&&"file:"==h){s=s||b(n.mimeType||d.getResponseHeader("content-type")),e=d.responseText;try{"script"==s?(1,eval)(e):"xml"==s?e=d.responseXML:"json"==s&&(e=c.test(e)?null:t.parseJSON(e))}catch(r){i=r}i?v(i,"parsererror",d,n,o):g(e,d,n,o)}else v(d.statusText||null,d.status?"error":"abort",d,n,o)}},m(d,n)===!1)return d.abort(),v(null,"abort",d,n,o),d;if(n.xhrFields)for(r in n.xhrFields)d[r]=n.xhrFields[r];var S="async"in n?n.async:!0;d.open(n.type,n.url,S,n.username,n.password);for(r in f)y.apply(d,f[r]);return n.timeout>0&&(j=setTimeout(function(){d.onreadystatechange=x,d.abort(),v(null,"timeout",d,n,o)},n.timeout)),d.send(n.data?n.data:null),d},t.get=function(){return t.ajax(j.apply(null,arguments))},t.post=function(){var e=j.apply(null,arguments);return e.type="POST",t.ajax(e)},t.getJSON=function(){var e=j.apply(null,arguments);return e.dataType="json",t.ajax(e)},t.fn.load=function(e,n,i){if(!this.length)return this;var a,r=this,s=e.split(/\s/),u=j(e,n,i),f=u.success;return s.length>1&&(u.url=s[0],a=s[1]),u.success=function(e){r.html(a?t("<div>").html(e.replace(o,"")).find(a):e),f&&f.apply(r,arguments)},t.ajax(u),this};var S=encodeURIComponent;t.param=function(t,e){var n=[];return n.add=function(t,e){this.push(S(t)+"="+S(e))},T(n,t,e),n.join("&").replace(/%20/g,"+")}}(Zepto),function(t){t.fn.serializeArray=function(){var n,e=[];return t([].slice.call(this.get(0).elements)).each(function(){n=t(this);var i=n.attr("type");"fieldset"!=this.nodeName.toLowerCase()&&!this.disabled&&"submit"!=i&&"reset"!=i&&"button"!=i&&("radio"!=i&&"checkbox"!=i||this.checked)&&e.push({name:n.attr("name"),value:n.val()})}),e},t.fn.serialize=function(){var t=[];return this.serializeArray().forEach(function(e){t.push(encodeURIComponent(e.name)+"="+encodeURIComponent(e.value))}),t.join("&")},t.fn.submit=function(e){if(e)this.bind("submit",e);else if(this.length){var n=t.Event("submit");this.eq(0).trigger(n),n.isDefaultPrevented()||this.get(0).submit()}return this}}(Zepto),function(t){"__proto__"in{}||t.extend(t.zepto,{Z:function(e,n){return e=e||[],t.extend(e,t.fn),e.selector=n||"",e.__Z=!0,e},isZ:function(e){return"array"===t.type(e)&&"__Z"in e}});try{getComputedStyle(void 0)}catch(e){var n=getComputedStyle;window.getComputedStyle=function(t){try{return n(t)}catch(e){return null}}}}(Zepto);


/***/ }),
/* 17 */
/***/ (function(module, exports) {

	//     Zepto.js
	//     (c) 2010-2015 Thomas Fuchs
	//     Zepto.js may be freely distributed under the MIT license.
	//
	//     Some code (c) 2005, 2013 jQuery Foundation, Inc. and other contributors
	
	;(function($){
	    var slice = Array.prototype.slice
	
	    function Deferred(func) {
	        var tuples = [
	                // action, add listener, listener list, final state
	                [ "resolve", "done", $.Callbacks({once:1, memory:1}), "resolved" ],
	                [ "reject", "fail", $.Callbacks({once:1, memory:1}), "rejected" ],
	                [ "notify", "progress", $.Callbacks({memory:1}) ]
	            ],
	            state = "pending",
	            promise = {
	                state: function() {
	                    return state
	                },
	                always: function() {
	                    deferred.done(arguments).fail(arguments)
	                    return this
	                },
	                then: function(/* fnDone [, fnFailed [, fnProgress]] */) {
	                    var fns = arguments
	                    return Deferred(function(defer){
	                        $.each(tuples, function(i, tuple){
	                            var fn = $.isFunction(fns[i]) && fns[i]
	                            deferred[tuple[1]](function(){
	                                var returned = fn && fn.apply(this, arguments)
	                                if (returned && $.isFunction(returned.promise)) {
	                                    returned.promise()
	                                        .done(defer.resolve)
	                                        .fail(defer.reject)
	                                        .progress(defer.notify)
	                                } else {
	                                    var context = this === promise ? defer.promise() : this,
	                                        values = fn ? [returned] : arguments
	                                    defer[tuple[0] + "With"](context, values)
	                                }
	                            })
	                        })
	                        fns = null
	                    }).promise()
	                },
	
	                promise: function(obj) {
	                    return obj != null ? $.extend( obj, promise ) : promise
	                }
	            },
	            deferred = {}
	
	        $.each(tuples, function(i, tuple){
	            var list = tuple[2],
	                stateString = tuple[3]
	
	            promise[tuple[1]] = list.add
	
	            if (stateString) {
	                list.add(function(){
	                    state = stateString
	                }, tuples[i^1][2].disable, tuples[2][2].lock)
	            }
	
	            deferred[tuple[0]] = function(){
	                deferred[tuple[0] + "With"](this === deferred ? promise : this, arguments)
	                return this
	            }
	            deferred[tuple[0] + "With"] = list.fireWith
	        })
	
	        promise.promise(deferred)
	        if (func) func.call(deferred, deferred)
	        return deferred
	    }
	
	    $.when = function(sub) {
	        var resolveValues = slice.call(arguments),
	            len = resolveValues.length,
	            i = 0,
	            remain = len !== 1 || (sub && $.isFunction(sub.promise)) ? len : 0,
	            deferred = remain === 1 ? sub : Deferred(),
	            progressValues, progressContexts, resolveContexts,
	            updateFn = function(i, ctx, val){
	                return function(value){
	                    ctx[i] = this
	                    val[i] = arguments.length > 1 ? slice.call(arguments) : value
	                    if (val === progressValues) {
	                        deferred.notifyWith(ctx, val)
	                    } else if (!(--remain)) {
	                        deferred.resolveWith(ctx, val)
	                    }
	                }
	            }
	
	        if (len > 1) {
	            progressValues = new Array(len)
	            progressContexts = new Array(len)
	            resolveContexts = new Array(len)
	            for ( ; i < len; ++i ) {
	                if (resolveValues[i] && $.isFunction(resolveValues[i].promise)) {
	                    resolveValues[i].promise()
	                        .done(updateFn(i, resolveContexts, resolveValues))
	                        .fail(deferred.reject)
	                        .progress(updateFn(i, progressContexts, progressValues))
	                } else {
	                    --remain
	                }
	            }
	        }
	        if (!remain) deferred.resolveWith(resolveContexts, resolveValues)
	        return deferred.promise()
	    }
	
	    $.Deferred = Deferred
	})(Zepto)

/***/ }),
/* 18 */
/***/ (function(module, exports) {

	//     Zepto.js
	//     (c) 2010-2015 Thomas Fuchs
	//     Zepto.js may be freely distributed under the MIT license.
	
	;(function($){
	    // Create a collection of callbacks to be fired in a sequence, with configurable behaviour
	    // Option flags:
	    //   - once: Callbacks fired at most one time.
	    //   - memory: Remember the most recent context and arguments
	    //   - stopOnFalse: Cease iterating over callback list
	    //   - unique: Permit adding at most one instance of the same callback
	    $.Callbacks = function(options) {
	        options = $.extend({}, options)
	
	        var memory, // Last fire value (for non-forgettable lists)
	            fired,  // Flag to know if list was already fired
	            firing, // Flag to know if list is currently firing
	            firingStart, // First callback to fire (used internally by add and fireWith)
	            firingLength, // End of the loop when firing
	            firingIndex, // Index of currently firing callback (modified by remove if needed)
	            list = [], // Actual callback list
	            stack = !options.once && [], // Stack of fire calls for repeatable lists
	            fire = function(data) {
	                memory = options.memory && data
	                fired = true
	                firingIndex = firingStart || 0
	                firingStart = 0
	                firingLength = list.length
	                firing = true
	                for ( ; list && firingIndex < firingLength ; ++firingIndex ) {
	                    if (list[firingIndex].apply(data[0], data[1]) === false && options.stopOnFalse) {
	                        memory = false
	                        break
	                    }
	                }
	                firing = false
	                if (list) {
	                    if (stack) stack.length && fire(stack.shift())
	                    else if (memory) list.length = 0
	                    else Callbacks.disable()
	                }
	            },
	
	            Callbacks = {
	                add: function() {
	                    if (list) {
	                        var start = list.length,
	                            add = function(args) {
	                                $.each(args, function(_, arg){
	                                    if (typeof arg === "function") {
	                                        if (!options.unique || !Callbacks.has(arg)) list.push(arg)
	                                    }
	                                    else if (arg && arg.length && typeof arg !== 'string') add(arg)
	                                })
	                            }
	                        add(arguments)
	                        if (firing) firingLength = list.length
	                        else if (memory) {
	                            firingStart = start
	                            fire(memory)
	                        }
	                    }
	                    return this
	                },
	                remove: function() {
	                    if (list) {
	                        $.each(arguments, function(_, arg){
	                            var index
	                            while ((index = $.inArray(arg, list, index)) > -1) {
	                                list.splice(index, 1)
	                                // Handle firing indexes
	                                if (firing) {
	                                    if (index <= firingLength) --firingLength
	                                    if (index <= firingIndex) --firingIndex
	                                }
	                            }
	                        })
	                    }
	                    return this
	                },
	                has: function(fn) {
	                    return !!(list && (fn ? $.inArray(fn, list) > -1 : list.length))
	                },
	                empty: function() {
	                    firingLength = list.length = 0
	                    return this
	                },
	                disable: function() {
	                    list = stack = memory = undefined
	                    return this
	                },
	                disabled: function() {
	                    return !list
	                },
	                lock: function() {
	                    stack = undefined;
	                    if (!memory) Callbacks.disable()
	                    return this
	                },
	                locked: function() {
	                    return !stack
	                },
	                fireWith: function(context, args) {
	                    if (list && (!fired || stack)) {
	                        args = args || []
	                        args = [context, args.slice ? args.slice() : args]
	                        if (firing) stack.push(args)
	                        else fire(args)
	                    }
	                    return this
	                },
	                fire: function() {
	                    return Callbacks.fireWith(this, arguments)
	                },
	                fired: function() {
	                    return !!fired
	                }
	            }
	
	        return Callbacks
	    }
	})(Zepto);


/***/ }),
/* 19 */
/***/ (function(module, exports) {

	;
	(function() {
		'use strict';
	
		/**
		 * @preserve FastClick: polyfill to remove click delays on browsers with touch UIs.
		 *
		 * @codingstandard ftlabs-jsv2
		 * @copyright The Financial Times Limited [All Rights Reserved]
		 * @license MIT License (see LICENSE.txt)
		 */
	
		/*jslint browser:true, node:true*/
		/*global define, Event, Node*/
	
	
		/**
		 * Instantiate fast-clicking listeners on the specified layer.
		 *
		 * @constructor
		 * @param {Element} layer The layer to listen on
		 * @param {Object} [options={}] The options to override the defaults
		 */
		function FastClick(layer, options) {
			var oldOnClick;
	
			options = options || {};
	
			/**
			 * Whether a click is currently being tracked.
			 *
			 * @type boolean
			 */
			this.trackingClick = false;
	
	
			/**
			 * Timestamp for when click tracking started.
			 *
			 * @type number
			 */
			this.trackingClickStart = 0;
	
	
			/**
			 * The element being tracked for a click.
			 *
			 * @type EventTarget
			 */
			this.targetElement = null;
	
	
			/**
			 * X-coordinate of touch start event.
			 *
			 * @type number
			 */
			this.touchStartX = 0;
	
	
			/**
			 * Y-coordinate of touch start event.
			 *
			 * @type number
			 */
			this.touchStartY = 0;
	
	
			/**
			 * ID of the last touch, retrieved from Touch.identifier.
			 *
			 * @type number
			 */
			this.lastTouchIdentifier = 0;
	
	
			/**
			 * Touchmove boundary, beyond which a click will be cancelled.
			 *
			 * @type number
			 */
			this.touchBoundary = options.touchBoundary || 10;
	
	
			/**
			 * The FastClick layer.
			 *
			 * @type Element
			 */
			this.layer = layer;
	
			/**
			 * The minimum time between tap(touchstart and touchend) events
			 *
			 * @type number
			 */
			this.tapDelay = options.tapDelay || 200;
	
			/**
			 * The maximum time for a tap
			 *
			 * @type number
			 */
			this.tapTimeout = options.tapTimeout || 700;
	
			if (FastClick.notNeeded(layer)) {
				return;
			}
	
			// Some old versions of Android don't have Function.prototype.bind
			function bind(method, context) {
				return function() {
					return method.apply(context, arguments);
				};
			}
	
	
			var methods = ['onMouse', 'onClick', 'onTouchStart', 'onTouchMove',
				'onTouchEnd', 'onTouchCancel'
			];
			var context = this;
			for (var i = 0, l = methods.length; i < l; i++) {
				context[methods[i]] = bind(context[methods[i]], context);
			}
	
			// Set up event handlers as required
			if (deviceIsAndroid) {
				layer.addEventListener('mouseover', this.onMouse, true);
				layer.addEventListener('mousedown', this.onMouse, true);
				layer.addEventListener('mouseup', this.onMouse, true);
			}
	
			layer.addEventListener('click', this.onClick, true);
			layer.addEventListener('touchstart', this.onTouchStart, false);
			layer.addEventListener('touchmove', this.onTouchMove, false);
			layer.addEventListener('touchend', this.onTouchEnd, false);
			layer.addEventListener('touchcancel', this.onTouchCancel, false);
	
			// Hack is required for browsers that don't support Event#stopImmediatePropagation (e.g. Android 2)
			// which is how FastClick normally stops click events bubbling to callbacks registered on the FastClick
			// layer when they are cancelled.
			if (!Event.prototype.stopImmediatePropagation) {
				layer.removeEventListener = function(type, callback, capture) {
					var rmv = Node.prototype.removeEventListener;
					if (type === 'click') {
						rmv.call(layer, type, callback.hijacked || callback, capture);
					} else {
						rmv.call(layer, type, callback, capture);
					}
				};
	
				layer.addEventListener = function(type, callback, capture) {
					var adv = Node.prototype.addEventListener;
					if (type === 'click') {
						adv.call(layer, type, callback.hijacked || (callback.hijacked = function(
							event) {
							if (!event.propagationStopped) {
								callback(event);
							}
						}), capture);
					} else {
						adv.call(layer, type, callback, capture);
					}
				};
			}
	
			// If a handler is already declared in the element's onclick attribute, it will be fired before
			// FastClick's onClick handler. Fix this by pulling out the user-defined handler function and
			// adding it as listener.
			if (typeof layer.onclick === 'function') {
	
				// Android browser on at least 3.2 requires a new reference to the function in layer.onclick
				// - the old one won't work if passed to addEventListener directly.
				oldOnClick = layer.onclick;
				layer.addEventListener('click', function(event) {
					oldOnClick(event);
				}, false);
				layer.onclick = null;
			}
		}
	
		/**
		 * Windows Phone 8.1 fakes user agent string to look like Android and iPhone.
		 *
		 * @type boolean
		 */
		var deviceIsWindowsPhone = navigator.userAgent.indexOf("Windows Phone") >= 0;
	
		/**
		 * Android requires exceptions.
		 *
		 * @type boolean
		 */
		var deviceIsAndroid = navigator.userAgent.indexOf('Android') > 0 && !
			deviceIsWindowsPhone;
	
	
		/**
		 * iOS requires exceptions.
		 *
		 * @type boolean
		 */
		var deviceIsIOS = /iP(ad|hone|od)/.test(navigator.userAgent) && !
			deviceIsWindowsPhone;
	
	
		/**
		 * iOS 4 requires an exception for select elements.
		 *
		 * @type boolean
		 */
		var deviceIsIOS4 = deviceIsIOS && (/OS 4_\d(_\d)?/).test(navigator.userAgent);
	
	
		/**
		 * iOS 6.0-7.* requires the target element to be manually derived
		 *
		 * @type boolean
		 */
		var deviceIsIOSWithBadTarget = deviceIsIOS && (/OS [6-7]_\d/).test(navigator.userAgent);
	
		/**
		 * BlackBerry requires exceptions.
		 *
		 * @type boolean
		 */
		var deviceIsBlackBerry10 = navigator.userAgent.indexOf('BB10') > 0;
	
		/**
		 * Determine whether a given element requires a native click.
		 *
		 * @param {EventTarget|Element} target Target DOM element
		 * @returns {boolean} Returns true if the element needs a native click
		 */
		FastClick.prototype.needsClick = function(target) {
			switch (target.nodeName.toLowerCase()) {
	
				// Don't send a synthetic click to disabled inputs (issue #62)
				case 'button':
				case 'select':
				case 'textarea':
					if (target.disabled) {
						return true;
					}
	
					break;
				case 'input':
	
					// File inputs need real clicks on iOS 6 due to a browser bug (issue #68)
					if ((deviceIsIOS && target.type === 'file') || target.disabled) {
						return true;
					}
	
					break;
				case 'label':
				case 'iframe': // iOS8 homescreen apps can prevent events bubbling into frames
				case 'video':
					return true;
			}
	
			return (/\bneedsclick\b/).test(target.className);
		};
	
	
		/**
		 * Determine whether a given element requires a call to focus to simulate click into element.
		 *
		 * @param {EventTarget|Element} target Target DOM element
		 * @returns {boolean} Returns true if the element requires a call to focus to simulate native click.
		 */
		FastClick.prototype.needsFocus = function(target) {
			switch (target.nodeName.toLowerCase()) {
				case 'textarea':
					return true;
				case 'select':
					return !deviceIsAndroid;
				case 'input':
					switch (target.type) {
						case 'button':
						case 'checkbox':
						case 'file':
						case 'image':
						case 'radio':
						case 'submit':
							return false;
					}
	
					// No point in attempting to focus disabled inputs
					return !target.disabled && !target.readOnly;
				default:
					return (/\bneedsfocus\b/).test(target.className);
			}
		};
	
	
		/**
		 * Send a click event to the specified element.
		 *
		 * @param {EventTarget|Element} targetElement
		 * @param {Event} event
		 */
		FastClick.prototype.sendClick = function(targetElement, event) {
			var clickEvent, touch;
	
			// On some Android devices activeElement needs to be blurred otherwise the synthetic click will have no effect (#24)
			if (document.activeElement && document.activeElement !== targetElement) {
				document.activeElement.blur();
			}
	
			touch = event.changedTouches[0];
	
			// Synthesise a click event, with an extra attribute so it can be tracked
			clickEvent = document.createEvent('MouseEvents');
			clickEvent.initMouseEvent(this.determineEventType(targetElement), true,
				true, window, 1, touch.screenX, touch.screenY, touch.clientX, touch.clientY,
				false, false, false, false, 0, null);
			clickEvent.forwardedTouchEvent = true;
			targetElement.dispatchEvent(clickEvent);
		};
	
		FastClick.prototype.determineEventType = function(targetElement) {
	
			//Issue #159: Android Chrome Select Box does not open with a synthetic click event
			if (deviceIsAndroid && targetElement.tagName.toLowerCase() === 'select') {
				return 'mousedown';
			}
	
			return 'click';
		};
	
	
		/**
		 * @param {EventTarget|Element} targetElement
		 */
		FastClick.prototype.focus = function(targetElement) {
			var length;
	
			// Issue #160: on iOS 7, some input elements (e.g. date datetime month) throw a vague TypeError on setSelectionRange. These elements don't have an integer value for the selectionStart and selectionEnd properties, but unfortunately that can't be used for detection because accessing the properties also throws a TypeError. Just check the type instead. Filed as Apple bug #15122724.
			if (deviceIsIOS && targetElement.setSelectionRange && targetElement.type.indexOf(
					'date') !== 0 && targetElement.type !== 'time' && targetElement.type !==
				'month') {
				length = targetElement.value.length;
				targetElement.setSelectionRange(length, length);
			} else {
				targetElement.focus();
			}
		};
	
	
		/**
		 * Check whether the given target element is a child of a scrollable layer and if so, set a flag on it.
		 *
		 * @param {EventTarget|Element} targetElement
		 */
		FastClick.prototype.updateScrollParent = function(targetElement) {
			var scrollParent, parentElement;
	
			scrollParent = targetElement.fastClickScrollParent;
	
			// Attempt to discover whether the target element is contained within a scrollable layer. Re-check if the
			// target element was moved to another parent.
			if (!scrollParent || !scrollParent.contains(targetElement)) {
				parentElement = targetElement;
				do {
					if (parentElement.scrollHeight > parentElement.offsetHeight) {
						scrollParent = parentElement;
						targetElement.fastClickScrollParent = parentElement;
						break;
					}
	
					parentElement = parentElement.parentElement;
				} while (parentElement);
			}
	
			// Always update the scroll top tracker if possible.
			if (scrollParent) {
				scrollParent.fastClickLastScrollTop = scrollParent.scrollTop;
			}
		};
	
	
		/**
		 * @param {EventTarget} targetElement
		 * @returns {Element|EventTarget}
		 */
		FastClick.prototype.getTargetElementFromEventTarget = function(eventTarget) {
	
			// On some older browsers (notably Safari on iOS 4.1 - see issue #56) the event target may be a text node.
			if (eventTarget.nodeType === Node.TEXT_NODE) {
				return eventTarget.parentNode;
			}
	
			return eventTarget;
		};
	
	
		/**
		 * On touch start, record the position and scroll offset.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onTouchStart = function(event) {
			var targetElement, touch, selection;
	
			// Ignore multiple touches, otherwise pinch-to-zoom is prevented if both fingers are on the FastClick element (issue #111).
			if (event.targetTouches.length > 1) {
				return true;
			}
	
			targetElement = this.getTargetElementFromEventTarget(event.target);
			touch = event.targetTouches[0];
	
			if (deviceIsIOS) {
	
				// Only trusted events will deselect text on iOS (issue #49)
				selection = window.getSelection();
				if (selection.rangeCount && !selection.isCollapsed) {
					return true;
				}
	
				if (!deviceIsIOS4) {
	
					// Weird things happen on iOS when an alert or confirm dialog is opened from a click event callback (issue #23):
					// when the user next taps anywhere else on the page, new touchstart and touchend events are dispatched
					// with the same identifier as the touch event that previously triggered the click that triggered the alert.
					// Sadly, there is an issue on iOS 4 that causes some normal touch events to have the same identifier as an
					// immediately preceeding touch event (issue #52), so this fix is unavailable on that platform.
					// Issue 120: touch.identifier is 0 when Chrome dev tools 'Emulate touch events' is set with an iOS device UA string,
					// which causes all touch events to be ignored. As this block only applies to iOS, and iOS identifiers are always long,
					// random integers, it's safe to to continue if the identifier is 0 here.
					if (touch.identifier && touch.identifier === this.lastTouchIdentifier) {
						event.preventDefault();
						return false;
					}
	
					this.lastTouchIdentifier = touch.identifier;
	
					// If the target element is a child of a scrollable layer (using -webkit-overflow-scrolling: touch) and:
					// 1) the user does a fling scroll on the scrollable layer
					// 2) the user stops the fling scroll with another tap
					// then the event.target of the last 'touchend' event will be the element that was under the user's finger
					// when the fling scroll was started, causing FastClick to send a click event to that layer - unless a check
					// is made to ensure that a parent layer was not scrolled before sending a synthetic click (issue #42).
					this.updateScrollParent(targetElement);
				}
			}
	
			this.trackingClick = true;
			this.trackingClickStart = event.timeStamp;
			this.targetElement = targetElement;
	
			this.touchStartX = touch.pageX;
			this.touchStartY = touch.pageY;
	
			// Prevent phantom clicks on fast double-tap (issue #36)
			if ((event.timeStamp - this.lastClickTime) < this.tapDelay) {
				event.preventDefault();
			}
	
			return true;
		};
	
	
		/**
		 * Based on a touchmove event object, check whether the touch has moved past a boundary since it started.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.touchHasMoved = function(event) {
			var touch = event.changedTouches[0],
				boundary = this.touchBoundary;
	
			if (Math.abs(touch.pageX - this.touchStartX) > boundary || Math.abs(touch.pageY -
					this.touchStartY) > boundary) {
				return true;
			}
	
			return false;
		};
	
	
		/**
		 * Update the last position.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onTouchMove = function(event) {
			if (!this.trackingClick) {
				return true;
			}
	
			// If the touch has moved, cancel the click tracking
			if (this.targetElement !== this.getTargetElementFromEventTarget(event.target) ||
				this.touchHasMoved(event)) {
				this.trackingClick = false;
				this.targetElement = null;
			}
	
			return true;
		};
	
	
		/**
		 * Attempt to find the labelled control for the given label element.
		 *
		 * @param {EventTarget|HTMLLabelElement} labelElement
		 * @returns {Element|null}
		 */
		FastClick.prototype.findControl = function(labelElement) {
	
			// Fast path for newer browsers supporting the HTML5 control attribute
			if (labelElement.control !== undefined) {
				return labelElement.control;
			}
	
			// All browsers under test that support touch events also support the HTML5 htmlFor attribute
			if (labelElement.htmlFor) {
				return document.getElementById(labelElement.htmlFor);
			}
	
			// If no for attribute exists, attempt to retrieve the first labellable descendant element
			// the list of which is defined here: http://www.w3.org/TR/html5/forms.html#category-label
			return labelElement.querySelector(
				'button, input:not([type=hidden]), keygen, meter, output, progress, select, textarea'
			);
		};
	
	
		/**
		 * On touch end, determine whether to send a click event at once.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onTouchEnd = function(event) {
			var forElement, trackingClickStart, targetTagName, scrollParent, touch,
				targetElement = this.targetElement;
	
			if (!this.trackingClick) {
				return true;
			}
	
			// Prevent phantom clicks on fast double-tap (issue #36)
			if ((event.timeStamp - this.lastClickTime) < this.tapDelay) {
				this.cancelNextClick = true;
				return true;
			}
	
			if ((event.timeStamp - this.trackingClickStart) > this.tapTimeout) {
				return true;
			}
	
			// Reset to prevent wrong click cancel on input (issue #156).
			this.cancelNextClick = false;
	
			this.lastClickTime = event.timeStamp;
	
			trackingClickStart = this.trackingClickStart;
			this.trackingClick = false;
			this.trackingClickStart = 0;
	
			// On some iOS devices, the targetElement supplied with the event is invalid if the layer
			// is performing a transition or scroll, and has to be re-detected manually. Note that
			// for this to function correctly, it must be called *after* the event target is checked!
			// See issue #57; also filed as rdar://13048589 .
			if (deviceIsIOSWithBadTarget) {
				touch = event.changedTouches[0];
	
				// In certain cases arguments of elementFromPoint can be negative, so prevent setting targetElement to null
				targetElement = document.elementFromPoint(touch.pageX - window.pageXOffset,
					touch.pageY - window.pageYOffset) || targetElement;
				targetElement.fastClickScrollParent = this.targetElement.fastClickScrollParent;
			}
	
			targetTagName = targetElement.tagName.toLowerCase();
			if (targetTagName === 'label') {
				forElement = this.findControl(targetElement);
				if (forElement) {
					this.focus(targetElement);
					if (deviceIsAndroid) {
						return false;
					}
	
					targetElement = forElement;
				}
			} else if (this.needsFocus(targetElement)) {
	
				// Case 1: If the touch started a while ago (best guess is 100ms based on tests for issue #36) then focus will be triggered anyway. Return early and unset the target element reference so that the subsequent click will be allowed through.
				// Case 2: Without this exception for input elements tapped when the document is contained in an iframe, then any inputted text won't be visible even though the value attribute is updated as the user types (issue #37).
				if ((event.timeStamp - trackingClickStart) > 100 || (deviceIsIOS && window
						.top !== window && targetTagName === 'input')) {
					this.targetElement = null;
					return false;
				}
	
				this.focus(targetElement);
				this.sendClick(targetElement, event);
	
				// Select elements need the event to go through on iOS 4, otherwise the selector menu won't open.
				// Also this breaks opening selects when VoiceOver is active on iOS6, iOS7 (and possibly others)
				if (!deviceIsIOS || targetTagName !== 'select') {
					this.targetElement = null;
					event.preventDefault();
				}
	
				return false;
			}
	
			if (deviceIsIOS && !deviceIsIOS4) {
	
				// Don't send a synthetic click event if the target element is contained within a parent layer that was scrolled
				// and this tap is being used to stop the scrolling (usually initiated by a fling - issue #42).
				scrollParent = targetElement.fastClickScrollParent;
				if (scrollParent && scrollParent.fastClickLastScrollTop !== scrollParent.scrollTop) {
					return true;
				}
			}
	
			// Prevent the actual click from going though - unless the target node is marked as requiring
			// real clicks or if it is in the whitelist in which case only non-programmatic clicks are permitted.
			if (!this.needsClick(targetElement)) {
				event.preventDefault();
				this.sendClick(targetElement, event);
			}
	
			return false;
		};
	
	
		/**
		 * On touch cancel, stop tracking the click.
		 *
		 * @returns {void}
		 */
		FastClick.prototype.onTouchCancel = function() {
			this.trackingClick = false;
			this.targetElement = null;
		};
	
	
		/**
		 * Determine mouse events which should be permitted.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onMouse = function(event) {
	
			// If a target element was never set (because a touch event was never fired) allow the event
			if (!this.targetElement) {
				return true;
			}
	
			if (event.forwardedTouchEvent) {
				return true;
			}
	
			// Programmatically generated events targeting a specific element should be permitted
			if (!event.cancelable) {
				return true;
			}
	
			// Derive and check the target element to see whether the mouse event needs to be permitted;
			// unless explicitly enabled, prevent non-touch click events from triggering actions,
			// to prevent ghost/doubleclicks.
			if (!this.needsClick(this.targetElement) || this.cancelNextClick) {
	
				// Prevent any user-added listeners declared on FastClick element from being fired.
				if (event.stopImmediatePropagation) {
					event.stopImmediatePropagation();
				} else {
	
					// Part of the hack for browsers that don't support Event#stopImmediatePropagation (e.g. Android 2)
					event.propagationStopped = true;
				}
	
				// Cancel the event
				event.stopPropagation();
				event.preventDefault();
	
				return false;
			}
	
			// If the mouse event is permitted, return true for the action to go through.
			return true;
		};
	
	
		/**
		 * On actual clicks, determine whether this is a touch-generated click, a click action occurring
		 * naturally after a delay after a touch (which needs to be cancelled to avoid duplication), or
		 * an actual click which should be permitted.
		 *
		 * @param {Event} event
		 * @returns {boolean}
		 */
		FastClick.prototype.onClick = function(event) {
			var permitted;
	
			// It's possible for another FastClick-like library delivered with third-party code to fire a click event before FastClick does (issue #44). In that case, set the click-tracking flag back to false and return early. This will cause onTouchEnd to return early.
			if (this.trackingClick) {
				this.targetElement = null;
				this.trackingClick = false;
				return true;
			}
	
			// Very odd behaviour on iOS (issue #18): if a submit element is present inside a form and the user hits enter in the iOS simulator or clicks the Go button on the pop-up OS keyboard the a kind of 'fake' click event will be triggered with the submit-type input element as the target.
			if (event.target.type === 'submit' && event.detail === 0) {
				return true;
			}
	
			permitted = this.onMouse(event);
	
			// Only unset targetElement if the click is not permitted. This will ensure that the check for !targetElement in onMouse fails and the browser's click doesn't go through.
			if (!permitted) {
				this.targetElement = null;
			}
	
			// If clicks are permitted, return true for the action to go through.
			return permitted;
		};
	
	
		/**
		 * Remove all FastClick's event listeners.
		 *
		 * @returns {void}
		 */
		FastClick.prototype.destroy = function() {
			var layer = this.layer;
	
			if (deviceIsAndroid) {
				layer.removeEventListener('mouseover', this.onMouse, true);
				layer.removeEventListener('mousedown', this.onMouse, true);
				layer.removeEventListener('mouseup', this.onMouse, true);
			}
	
			layer.removeEventListener('click', this.onClick, true);
			layer.removeEventListener('touchstart', this.onTouchStart, false);
			layer.removeEventListener('touchmove', this.onTouchMove, false);
			layer.removeEventListener('touchend', this.onTouchEnd, false);
			layer.removeEventListener('touchcancel', this.onTouchCancel, false);
		};
	
	
		/**
		 * Check whether FastClick is needed.
		 *
		 * @param {Element} layer The layer to listen on
		 */
		FastClick.notNeeded = function(layer) {
			var metaViewport;
			var chromeVersion;
			var blackberryVersion;
			var firefoxVersion;
	
			// Devices that don't support touch don't need FastClick
			if (typeof window.ontouchstart === 'undefined') {
				return true;
			}
	
			// Chrome version - zero for other browsers
			chromeVersion = +(/Chrome\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[1];
	
			if (chromeVersion) {
	
				if (deviceIsAndroid) {
					metaViewport = document.querySelector('meta[name=viewport]');
	
					if (metaViewport) {
						// Chrome on Android with user-scalable="no" doesn't need FastClick (issue #89)
						if (metaViewport.content.indexOf('user-scalable=no') !== -1) {
							return true;
						}
						// Chrome 32 and above with width=device-width or less don't need FastClick
						if (chromeVersion > 31 && document.documentElement.scrollWidth <= window
							.outerWidth) {
							return true;
						}
					}
	
					// Chrome desktop doesn't need FastClick (issue #15)
				} else {
					return true;
				}
			}
	
			if (deviceIsBlackBerry10) {
				blackberryVersion = navigator.userAgent.match(
					/Version\/([0-9]*)\.([0-9]*)/);
	
				// BlackBerry 10.3+ does not require Fastclick library.
				// https://github.com/ftlabs/fastclick/issues/251
				if (blackberryVersion[1] >= 10 && blackberryVersion[2] >= 3) {
					metaViewport = document.querySelector('meta[name=viewport]');
	
					if (metaViewport) {
						// user-scalable=no eliminates click delay.
						if (metaViewport.content.indexOf('user-scalable=no') !== -1) {
							return true;
						}
						// width=device-width (or less than device-width) eliminates click delay.
						if (document.documentElement.scrollWidth <= window.outerWidth) {
							return true;
						}
					}
				}
			}
	
			// IE10 with -ms-touch-action: none or manipulation, which disables double-tap-to-zoom (issue #97)
			if (layer.style.msTouchAction === 'none' || layer.style.touchAction ===
				'manipulation') {
				return true;
			}
	
			// Firefox version - zero for other browsers
			firefoxVersion = +(/Firefox\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[
				1];
	
			if (firefoxVersion >= 27) {
				// Firefox 27+ does not have tap delay if the content is not zoomable - https://bugzilla.mozilla.org/show_bug.cgi?id=922896
	
				metaViewport = document.querySelector('meta[name=viewport]');
				if (metaViewport && (metaViewport.content.indexOf('user-scalable=no') !==
						-1 || document.documentElement.scrollWidth <= window.outerWidth)) {
					return true;
				}
			}
	
			// IE11: prefixed -ms-touch-action is no longer supported and it's recomended to use non-prefixed version
			// http://msdn.microsoft.com/en-us/library/windows/apps/Hh767313.aspx
			if (layer.style.touchAction === 'none' || layer.style.touchAction ===
				'manipulation') {
				return true;
			}
	
			return false;
		};
	
	
		/**
		 * Factory method for creating a FastClick object
		 *
		 * @param {Element} layer The layer to listen on
		 * @param {Object} [options={}] The options to override the defaults
		 */
		FastClick.attach = function(layer, options) {
			return new FastClick(layer, options);
		};
	
	
		// if (typeof define === 'function' && define.cmd) {
		// 	define(function(require, exports, module) {
		// 		module.exports = FastClick;
		// 	});
		// } else {
		// 	window.FastClick = FastClick;
		// }
		module.exports = FastClick;
	}());


/***/ }),
/* 20 */
/***/ (function(module, exports) {

	/**
		@fileOverview 腾讯视频APP中提供的接口进行封装成统一的对外接口
		@author	devingao
		@version 2014.07.24
		@modified 2014.10.16
		@dependent 接口实现了两套处理方法，	如果通过setDeferred设置过Promise模型的话，	就可使用Promise异步链式模式实现，	    否则使用参数中的回调函数实现结果返回。
		@interfece
			loadQQUserInfo	获取QQ用户信息
			loadWxUserInfo	获取微信用户信息
			loadTvUserInfo	获取腾讯视频票据
			loginTv		登陆微信影视圈
			loginQQ		登陆QQ
			notify(不可用)
			share(不可用)
			loadTagInfos	获取打点信息
			closeH5			关闭H5
			showH5			显示H5
			hideH5			隐藏H5
			qllogs			打印日志
			getAttentionState	获取关注状态
			setAttentionState	设置关注状态
			shareMoment			分享到影视圈
			getPlayerSize		获取播放器大小
			getDeviceId			获取设备ID
			getCurrentTime		获取当前的播放器时间
			on (onQQVideoOrientation 屏幕旋转  , onTagTimeUp 打点时间到达, onControllerStateChange) 注册时间
			off 解除事件
			trigger 触发一个事件
		@remark
			所有返回值：
			{
				state: "0", 	//接口返回状态，0:成功， 1:失败
				data: {} ,	  //放回数据的JSON化，null为不能JSON化
				origdata: "", //返回的原始数据
				msg: ""		  //错误信息
			}
	 */
	;(function () {
		//初始化Promise方法
		var ua = navigator.userAgent;
		var p_ios = ua.match(/(iPhone\sOS)\s([\d_]+)/);
		var p_adr = ua.match(/(Android)\s+([\d.]+)/);
		var isIOS = p_ios ? true : false;
		var isAdr = !isIOS && p_adr ? true : false;
	
		if(window.QQVideoBridge){
			return;
		}
	
		var isNewBridge_android = true;
		var arr_temp = ua.match(/QQLiveBrowser[\s\/]*(\d+(\.\d+)*)/i);
		if(isAdr && arr_temp){
			var version = arr_temp[1];
			if(version < "4.0.0.0"){
				isNewBridge_android = false;
			}
		}
	
		//默认的Promise模型，防止出错
		var Deferred  = function(){
			return {
				reject: function(){
					return this;
				},
				resolve: function(){
					return this;
				},
				done: function(){
					return this;
				},
				fail: function(){
				}
			};
		};
		if(window.$ && $.Deferred){
			//Zepto和jquery的Promise
			Deferred = function(){
				return $.Deferred();
			};
		}else if(window.txmv && txmv.base && txmv.base.Deferred){
			//腾讯视频基础库的Promise
			Deferred = function(){
				return new txmv.base.Deferred();
			};
		}
	
		//将正确返回的回调函数与Promise模型中的resolve绑定，保证resolve的时候，也同样会调用回调函数
		function RsyncDefer(func_suc)
		{
			var defer = Deferred();
			var _funcResolve = defer.resolve;
			defer.resolve = function(){
				_funcResolve.apply(this , Array.prototype.slice.call(arguments, 0));
				func_suc && func_suc.apply && func_suc.apply(null , Array.prototype.slice.call(arguments, 0));
			};
			return defer;
		}
	
		/**
		 * @descripton 解析JSON数据
		 */
		function _parseJSON(str_json)
		{
			var json_msg = null;
			try{
				json_msg = JSON.parse(str_json);
			}catch(e){
				json_msg = null;
			}
			return json_msg;
		}
	
		/*
		 * 调用接口的默认逻辑
		 * @param
		 *		handleName 接口名
		 *		json_param 参数名
		 *		fun_suc 返回值
		 */
		function _handlerDefaultTpl(handleName , json_param , func_suc )
		{
			var defer = RsyncDefer(func_suc);				
			_callBridge(handleName , json_param , function(json_msg){
				defer.resolve(json_msg);
			},function(json_error){
				defer.resolve(json_error);
			});
			return defer;
		}
	
		/** @description 调用IOS的接口
			@param {str} str_method 所使用的接口的名字
			@param {str} str_param 输入的参数
			@param {str} func_suc 调用成功的回调函数
		*/
		function _callBridge(str_method , str_param , func_suc)
		{
			var defer = RsyncDefer(func_suc);
			if(isAdr && !isNewBridge_android){
				var str_msg = "";
				var json_result = {
					state : 0
				};
				try{
					if(str_param != null){
						if(typeof str_param == "object"){
							str_param = JSON.stringify(str_param);
						}
						str_msg = Android[handleName](str_param);
					} else{
						str_msg = Android[handleName]();
					}
					json_result.origdata = str_msg;
				} catch(e){
					json_result.state = 1;
					json_result.msg = "Bridge Error(" + handleName + ")";
				}
	
				if(!json_result.state) {
					json_result.data = _parseJSON(json_result.origdata);
				}
				defer.resolve(json_result);
			}else{
				_Bridge(function(json_msg){
					if(json_msg && json_msg.state)
					{
						defer.resolve({
							state: 1,
							msg: "No Bridge Applied!"
						});
					} else {
						TenvideoJSBridge.invoke(str_method , str_param , function(str_msg){
							var json_res = {};
							json_res = _parseJSON(str_msg);
							defer.resolve({
								state: 0,
								origdata: str_msg,
								data: json_res
							});
						});
					}
				});
			}
			return defer;
		}
	
		/** @description 获取ios的接口
		 * @param
				func_suc 获取到ios接口之后的回调函数
			@remark 首先判断ios接口是否存在，如果不存在的话，就监听下接口ready的事件，如果再5秒钟内两者都没有获取到接口，就提示失败
		*/
		function _Bridge(func_suc){
			var defer = RsyncDefer(func_suc);
	
			if(window.TenvideoJSBridge){
				defer.resolve(window.TenvideoJSBridge);
			}else{
				_mergeBridges().done(function(){
					defer.resolve(window.TenvideoJSBridge);
				});
				//如果5秒钟之后，还是没有对应的接口，就直接返回false，说明拉取接口失败了。
				setTimeout(function(){
					if(!window.TenvideoJSBridge){
						defer.resolve({
							state: 1,
							msg: "No Bridge Applied!"
						});
					} else {
						defer.resolve();
					}
				} , _IOS_BRIDGE_TIMEOUT);
			}
			return defer;
		}
	
		var mergeBirigesDefer = null;
		window._isNewBridge = false;
		function _mergeBridges(){
			if(mergeBirigesDefer){
				return mergeBirigesDefer;
			}
			mergeBirigesDefer = new Deferred();
			document.addEventListener('onTenvideoJSBridgeReady', function() {
				window._isNewBridge = true;
				if(isAdr){
					mergeBirigesDefer.resolve(window.TenvideoJSBridge);
				}
			});
			document.addEventListener('WebViewJavascriptBridgeReady', function() {
				if(window._isNewBridge){
					mergeBirigesDefer.resolve(window.TenvideoJSBridge);
				}else{
					$.extend(window.TenvideoJSBridge,window.WebViewJavascriptBridge);
					window.TenvideoJSBridge.invoke = window.WebViewJavascriptBridge.callHandler;
					window.TenvideoJSBridge.on = window.WebViewJavascriptBridge.registerHandler;
	
					setTimeout(function(){
						mergeBirigesDefer.resolve(window.TenvideoJSBridge);
					},100);
				}
			});
			return mergeBirigesDefer;
		}
	
		function _registerHandler(str_method , func_caller , func_suc)
		{
			var defer = RsyncDefer(func_suc);
			_Bridge(function(json_msg){
				if(json_msg && json_msg.state)
				{
					defer.resolve({
						state: 1,
						msg: "No Bridge Applied!"
					});
				} else {
					defer.resolve({
						state: 0
					});
					TenvideoJSBridge.on(str_method , function(data, responseCallback) {
						func_caller && func_caller(data);
						responseCallback&&responseCallback("SUCESS");
					});
				}
			});
			return defer;
		}
	
		/** @description 创建随即函数名，避免公共函数名字一直
			@return {str} 函数名
			@remark 生成一个随即函数名，如果随即函数名已经在页面中存在，就重新生成一个，防止冲突
		*/
		var i_funcNum = 0;
		function _createRandomFunc(){
			var str_funcName = "TenvideoJSBridge_AutoFunc" + i_funcNum + "_" + String.fromCharCode(65 + Math.random() * 10e6 % 26) + Math.ceil(Math.random() * 10e6).toString();
	
			if(window[str_funcName]){
				return _createRandomFunc();
			}
			i_funcNum++;
			return str_funcName;
		}
		var _IOS_BRIDGE_TIMEOUT = 5000;
	
		QQVideoBridge = {
			/*
			 * 设置Bridge的超时时间
			 */
			setIosBridgeTimeout: function(i_time){
				_IOS_BRIDGE_TIMEOUT = i_time || 5000;
			},
			/** @description 设置Deferred函数
				@param {func} func_deferred 生成promise对象的函数
			*/
			setDeferred: function(func_deferred){
				Deferred = func_deferred;
			},
			checkApi: function(json_param , func_suc ){
				return _handlerDefaultTpl("checkApi" , json_param , func_suc);
			},
			getAppInfo: function(json_param , func_suc ){
				return _handlerDefaultTpl("getAppInfo" , json_param , func_suc);
			},
			getDeviceInfo: function(json_param , func_suc ){
				return _handlerDefaultTpl("getDeviceInfo" , json_param , func_suc);
			},
			shareWeixinTimeline: function(json_param , func_suc ){
				return _handlerDefaultTpl("shareWeixinTimeline" , json_param , func_suc);
			},
			shareWeixinUser: function(json_param , func_suc ){
				return _handlerDefaultTpl("shareWeixinUser" , json_param , func_suc);
			},
			shareQQUser: function(json_param , func_suc ){
				return _handlerDefaultTpl("shareQQUser" , json_param , func_suc);
			},
			shareQzone: function(json_param , func_suc ){
				return _handlerDefaultTpl("shareQzone" , json_param , func_suc);
			},
			shareSinaWeibo: function(json_param , func_suc ){
				return _handlerDefaultTpl("shareSinaWeibo" , json_param , func_suc);
			},
			shareTxWeibo: function(json_param , func_suc ){
				return _handlerDefaultTpl("shareTxWeibo" , json_param , func_suc);
			},
			openUrl: function(json_param , func_suc ){
				return _handlerDefaultTpl("openUrl" , json_param , func_suc);
			},
			isInstalled: function(json_param , func_suc ){
				return _handlerDefaultTpl("isInstalled" , json_param , func_suc);
			},
			launch3rdApp: function(json_param , func_suc ){
				return _handlerDefaultTpl("launch3rdApp" , json_param , func_suc);
			},
			getLocation: function(json_param , func_suc ){
				return _handlerDefaultTpl("getLocation" , json_param , func_suc);
			},
			getPayVip: function(json_param , func_suc ){
				return _handlerDefaultTpl("getPayVip" , json_param , func_suc);
			},
			getTicketNum: function(json_param , func_suc ){
				return _handlerDefaultTpl("getTicketNum" , json_param , func_suc);
			},
			setMoreInfo: function(json_param , func_suc ){
				return _handlerDefaultTpl("setMoreInfo" , json_param , func_suc);
			},
			openToolsDialog: function(json_param , func_suc ){
				return _handlerDefaultTpl("openToolsDialog" , json_param , func_suc);
			},
			/** @description 取当前用户主登录帐号的cookie，目前"qq"或者"wx"两种以及未登录 ,tenvideoJSBridge才支持
				@param:无
				@return	{defer}返回结果：
					res.result: {"userInfo":{"nickname":"", "headImgUrl":"", "uin":""}, "type":"qq"}
					res.errCode: 参考统一的说明
					res.errMsg: 参考统一的说明
			*/
			getMainUserInfo: function(json_param , func_suc ){
				var defer = RsyncDefer(func_suc);
	
				function unifyDataFunc(json_msg){
					if(json_msg.state == 0 && json_msg.data){
						$.extend(json_msg.data, json_msg.data.cookie);//将获取的值变为json_msg.data下的属性
					}
					defer.resolve(json_msg);
				};
				_handlerDefaultTpl("getMainUserInfo" , json_param, unifyDataFunc);
	
				return defer;
			},
			/**
			*/
			getUserInfo: function(json_param , func_suc ){
				var defer = RsyncDefer(func_suc);
	
				function unifyDataFunc(json_msg){
					if(json_msg.state == 0 && json_msg.data && json_msg.data.result){
						$.extend(json_msg.data, json_msg.data.result);//将获取的值变为json_msg.data下的属性
					}
					defer.resolve(json_msg);
				};
				_handlerDefaultTpl("getUserInfo" , json_param, unifyDataFunc);
	
				return defer;
			},
			/** @description 获取当前主登录帐号的用户信息，目前"qq"、"wx"两种以及未登录,tenvideoJSBridge才支持
				@param:无
				@return	{defer}返回结果：
					res.result: {cookie: "uin=2504981145;skey=MM1D13bKyp;lsky=00030000f39a74308eab906372e38b87b2653811caccb152b1b723748d0b8914051122eee8c17d173681fc3b;", type: "qq"}
					res.errCode: 参考统一的说明
					res.errMsg: 参考统一的说明
			*/
			getMainCookie: function(json_param , func_suc ){
				var defer = RsyncDefer(func_suc);
	
				function unifyDataFunc(json_msg){
					if(json_msg.state == 0 && json_msg.data && json_msg.data.result){
						$.extend(json_msg.data, json_msg.data.result);//将获取的值变为json_msg.data下的属性
					}
					defer.resolve(json_msg);
				};
				_handlerDefaultTpl("getMainCookie" , json_param, unifyDataFunc);
	
	
				return defer;
			},
			/** @description 获取用户的QQ信息
				@return {defer}
					 {"qq": "uin=2504981145;skey=MM1D13bKyp;lsky=00030000f39a74308eab906372e38b87b2653811caccb152b1b723748d0b8914051122eee8c17d173681fc3b;", "wx":""}
			*/
			getCookie: function(json_param , func_suc ){
				var self = this;
				var defer = RsyncDefer(func_suc);
	
				function unifyDataFunc(json_msg){
					if(json_msg.state == 0 && json_msg.data && json_msg.data.result){
						json_msg.data.qq = json_msg.data.result.qq;//将获取的值变为json_msg.data下的属性
						json_msg.data.wx =json_msg.data.result.wx;//将获取的值变为json_msg.data下的属性
						json_msg.data.tv = json_msg.data.result.tv;//将获取的值变为json_msg.data下的属性
					}
					defer.resolve(json_msg);
				};
				_handlerDefaultTpl("getCookie" , json_param, unifyDataFunc);
				return defer;
			},
			/** @description 获取用户的QQ信息
				@return {defer}
					defer_done:
						uin: QQ号,
						lskey: key值,
						skey: key值,
						nickName: 用户昵称
					defer_fail:
						state:错误码
						msg: 错误信息
			*/
			getQQCookie: function(json_param , func_suc ){
				var self = this;
				var defer = RsyncDefer(func_suc);
				self.getCookie({type:["qq"]} , func_suc).done(function(json_msg){
					defer.resolve(json_msg);
				});
	
				return defer;
			},
			/** @description 获取用户的微信信息
				@return {defer}
					defer_done:
						open_id: 微信的openid,
						access_token: access_token,
						headimgurl: 头像,
						nickName: 用户昵称
					defer_fail:
						state:错误码
						msg: 错误信息
			*/
			getWXCookie: function(json_param , func_suc){
				var self = this;
				var defer = RsyncDefer(func_suc);
				self.getCookie({type:["wx"]} , func_suc).done(function(json_msg){
					defer.resolve(json_msg);
				});
				return defer;
			},
			/** @description 获取用户的视频账号信息
				@return {defer}
					defer_done:
						user_id: 视频账号,
						session: 用户的key值,
						headimgurl: 头像,
						nickName: 用户昵称
					defer_fail:
						state:错误码
						msg: 错误信息
			*/
			getTVCookie: function(json_param , func_suc){
				var self = this;
				var defer = RsyncDefer(func_suc);
				self.getCookie({type:["tv"]} , func_suc).done(function(json_msg){
					defer.resolve(json_msg);
				});
				return defer;
			},
			/** @description 调起微信登陆，新接口才支持
			*/
			loginWx: function(json_param , func_suc){
				return _handlerDefaultTpl("actionLogin" , {"type":"wx"}  , func_suc);
			},
			/** @description 调起QQ登陆
			*/
			loginQQ: function(json_param , func_suc){
				return _handlerDefaultTpl("actionLogin" , {"type":"qq"}  , func_suc);
			},
			/** @description 调起影视圈登陆
			*/
			loginTv: function(json_param , func_suc){
				return _handlerDefaultTpl("actionLogin" , {"type":"tv"}  , func_suc);
			},
			notify: function(json_param , func_suc){
				return _handlerDefaultTpl("setNotifyInfo" , json_param , func_suc);
			},
			/*
			 * @description 分享按钮
			 */
			share: function(json_param , func_suc) {
				return _handlerDefaultTpl("setShareInfo" , json_param , func_suc);
			},
			/*
			 * 获取打点信息，结构为：[
					[{
							"cate" : 4096, //打点类型 		cate&4096==4096代表互动投票
							"gds" : [{
									"ac" : "0.59,0.63"//展示坐标		格式x,y ******************
									"af" : 1, //是否有答案	0:无答案	1:有答案
									"e" : 0, //事件 			0:投票   	1:揭晓结果
									"et" : 240, //投票结束时间戳
									"iu" : "http://blank.cdc.im/m/html/test.html", //互动URL
									"ps" : 0, //播放状态		0:暂停   	1:继续播放
									"sid" : "11", //投票ID
									"sp" : "http://i.gtimg.cn/qqlive/images/20140924/i1411543060_1.jpg", //主题图片URL
								}
								 {
									"ac" : "0.59,0.63"//展示坐标		格式x,y
									"af" : 1, //是否有答案	0:无答案	1:有答案
									"e" : 0, //事件 			0:投票   	1:揭晓结果
									"et" : 240, //投票结束时间戳
									"iu" : "http://blank.cdc.im/m/html/test.html", //互动URL
									"ps" : 0, //播放状态		0:暂停   	1:继续播放
									"sid" : "11", //投票ID
									"sp" : "http://i.gtimg.cn/qqlive/images/20140924/i1411543060_1.jpg", //主题图片URL
								}
							],
							"pt" : 180, //投票开始时间戳
							"ti" : "投票主题"
						}
					]
				]
			 */
			getTagInfos: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("getTagInfos" , null , func_suc);
			},
			/*
			 * 关闭webview
			 */
			closeH5: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("closeH5" , null , func_suc);
			},
			/*
			 * 显示webview
			 */
			showH5: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("showH5" , null , func_suc);
			},
			/*
			 * 隐藏webview
			 */
			hideH5: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("hideH5" , null , func_suc);
			},
			/*
			 * 向APP日志文件中打印日志
			 */
			qllogs: function(str_param , func_suc)
			{
				return _handlerDefaultTpl("qllogs" , str_param , func_suc);
			},
			/*
			 * 获取当前页面的关注状态
			 */
			getAttentionState: function(func_suc)
			{
				return _handlerDefaultTpl("getAttentionState" , null , func_suc);
			},
			/*
			 * 设置关注状态
			 * @param 1: 关注 0：取消关注
			 * @return 返回 1成功 0失败
			 */
			setAttentionState: function(i_attentionState, func_suc)
			{
				return _handlerDefaultTpl("setAttentionState" , i_attentionState , func_suc);
			},
			/*
			 * 分享到影视圈
			 */
			shareMoment: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("shareMoment" , null , func_suc);
			},
			/*
			 * 获取播放器大小
			 * @return {w: h:}
			 */
			getPlayerSize: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("getPlayerSize" , null , func_suc);
			},
			/*
			 * 获取设备ID
			 */
			getDeviceId: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("getDeviceId" , null , func_suc);
			},
			getAppId: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("getAppId" , null , func_suc);
			},
			/*
			 * 获取播放器当前的播放时间
			 */
			getCurrentTime: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("getCurrentTime" , null , func_suc);
			},
			getVideoInfo: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("getVideoInfo" , null , func_suc);
			},
			/*
			 * 分享到任何地方
			 * {
				useCustomeInfo:                     0 ：使用默认的分享信息，1：使用自定义的分享信息
				webShareID:              string类型
				webShareTitle:           string类型
				webShareSubTitle:     string类型
				webShareImageURL:  string类型
				webShareURL:           string类型
			   }
			 */
			shareTo: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("shareTo" , json_param , func_suc);
			},
			pauseVideo: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("setPlayerState" , 0 , func_suc);
			},
			playVideo: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("setPlayerState" , 1 , func_suc);
			},
			openWebview: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("openWebview" , json_param , func_suc);
			},
			shareScreenCapture: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("shareScreenCapture" , json_param , func_suc);
			},
			loadEffectInfo: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("loadEffectInfo" , json_param , func_suc);
			},
			finishpay: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("finishpay" , json_param , func_suc);
			},
			jumpVideo: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("jumpVideo" , json_param , func_suc);
			},
			jumpWatchTimeInVideo: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("jumpWatchTimeInVideo" , json_param , func_suc);
			},
			shareFromH5: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("shareFromH5" , json_param , func_suc);
			},
			openWebview: function(json_param , func_suc)
			{
				return _handlerDefaultTpl("openWebview" , json_param , func_suc);
			}
		};
	
		var json_event = {};
		/*
		 * 注册APP的回调事件
		 */
		QQVideoBridge.on = function(str_event , func_suc)
		{
			if(!json_event[str_event])
			{
				json_event[str_event] = {
					eventName: str_event,
					func: []
				};
				window[str_event] = function()
				{
					for(var i in json_event[str_event].func)
					{
						json_event[str_event].func[i].apply(null , Array.prototype.slice.call(arguments, 0));
					}
				}
				_registerHandler(str_event , window[str_event] , function(){
				});
			}
			json_event[str_event].func.push(func_suc);
		}
		/*
		 * 删除APP的回调事件
		 */
		QQVideoBridge.off = function(str_event , func_suc)
		{
			if(!json_event[str_event])
			{
				return;
			}
	
			if(!func_suc)
			{
				json_event[str_event].func = [];
			}
	
			for(var i = json_event[str_event].func.length - 1; i >= 0 ; i--)
			{
				if(json_event[str_event].func[i] == func_suc)
				{
					json_event[str_event].func.splice(i , 1);
				}
			}
		}
		/*
		 * 触发事件
		 */
		QQVideoBridge.trigger = function(str_event)
		{
			if(!json_event[str_event])
			{
				return;
			}
			window[str_event].apply(null , Array.prototype.slice.call(arguments, 1));
		}
	
		window.QQVideoBridge = QQVideoBridge;
	})();


/***/ }),
/* 21 */
/***/ (function(module, exports) {

	(function (lib) {
		var com = {
			filterXSS: function (str) {
				if (typeof str != "string")return str;
				return str.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;").replace(/\'/g, "&apos;");
			},
			getUrlParam: function (name, url) {
				var r = new RegExp("(\\?|#|&)" + name + "=([^&#]*)(&|#|$)");
				var url = url || location.href;
				var m = url.match(r);
				return (!m ? "" : this.filterXSS(m[2]));
			},
			getCoverDetailUrl : function(cid,isPause){
				var url = "tenvideo2://?action=1&insideapp=YES&cover_id="+cid;
				if(isPause){
					url += "&auto_play=NO"
				}
				return url;
			}
		};
		lib.util = lib.util || {};
		lib.extend(lib.util, com);
	})($);

/***/ })
/******/ ]);