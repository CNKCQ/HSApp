/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	QQVideoBridge.setMoreInfo({"hasRefresh": true, "hasShare": false, "hasFollow": false});
	var base = __webpack_require__(1),
		hotFilm = new base(),
		store = __webpack_require__(6),
		cityinfo = store.get(),
		city_id = "";
	if (cityinfo) {
		city_id = cityinfo.city_id;
	}
	hotFilm.getList(city_id, true);
	hotFilm.changeCity();
	hotFilm.bindReload();

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

	var boss = __webpack_require__(2);
	boss.delegate('app_v_index');
	var lbs = __webpack_require__(3),
		city_info = {
			name: "",
			id: ""
		},
		lbs_city_info = {
			name: "",
			id: ""
		};
	var confirmPop = __webpack_require__(5);
	var cityStorage = __webpack_require__(6);
	
	window.onerror = function (err) {
		$("#log").append("window.error:" + JSON.stringify(err))
	};
	
	function base(fn) {
		this.dataFn = fn || __webpack_require__(7);
	}
	
	var template = __webpack_require__(9);
	template.helper('getDateFormat', (function () {
		var now = new Date(),
			year = now.getFullYear();
	
		return function (str) {
			if (typeof str != "string") {
				return "";
			}
			if (str.indexOf(year) == 0) {
				str = str.replace(year + "-", "");
			} else {
				str = str.replace("-", "年");
			}
			str = str.replace("-", "月") + "日";
			return str;
		}
	})());
	template.helper("getUrl", function (cid) {
		return $.util.getCoverDetailUrl(cid, true)
	});
	template.helper("https", function (url) {
		return url.replace ? url.replace('http', 'https') : url;
	});
	
	$("._replaceurl").on("click", function (event) {
		event.preventDefault();
		if (typeof history.replaceState == "function") {
			history.replaceState({}, "选影片", this.href)
		}
		location.replace(this.href);
	});
	
	
	base.prototype = {
		getList: function (city_id, isFirstTime) {
			var me = this;
			lbs.done(function (_lbs) {
	
				var fn = me.dataFn,
					param = $.extend({
						city_id: city_id
					}, _lbs), //,{lng:116.394495,lat:39.950565})
					def = fn(param);
	
				def.done(function (res) {
	
					if (res.films) {
						var tpl = __webpack_require__(10);
					} else {
						var tpl = __webpack_require__(11);
					}
					res.is_trailer = location.href.indexOf("trailer.html") != -1;
					$("#list").html(tpl(res));
	
				}).fail(function (res) {
					var tpl = __webpack_require__(12);
					res = res || {};
					if (res.errmsg) {
						res.msg = res.errmsg;
					} else {
						res.msg = "请检查网络连接是否出错"
					}
					if (res.retcode) {
						res.msg += "错误码：" + res.retcode;
					}
					$("#list").html(tpl(res));
					$("#log").append("error:" + JSON.stringify(res))
				}).always(function (res) {
					$("#list").scrollTop(0);
					$("#loading").hide();
	
					res = res || {};
					$("#city_name").text(res.city_nm || "定位城市失败");
					$("#change_city").css({
						visibility: "visible"
					});
					city_info.name = res.city_nm;
					city_info.id = res.city_id;
					lbs_city_info.name = res.gps_city_nm || lbs_city_info
							.name;
					lbs_city_info.id = res.gps_city_id || lbs_city_info.id;
	
					var lruStorage = __webpack_require__(13);
					var yesterdayCity = lruStorage(
						'yesterdayCity', {
							limit: 1,
							maxAge: 24 * 60 * 60 * 1000,
							useSession: false,
							onStale: function (item) {
								if (item.nm != res.gps_city_nm) {
									confirmPop('系统定位您在' + res.gps_city_nm +
										'，是否切换？', '切换', '取消', $.Deferred())
										.then(function () {
											city_info.city_id = res.gps_city_id;
											city_info.city = res.gps_city_nm;
											city_info.area_id = 0;
											me.getList(res.gps_city_id);
	
											cityStorage.set(res.gps_city_id, 0);
										});
								}
							}
						});
					yesterdayCity.get('city');
					yesterdayCity.set('city', {
						id: res.city_id,
						nm: res.city_nm
					});
				})
			})
		},
		changeCity: function () {
			var me = this;
			$("#change_city").on("click", function (event) {
				event.preventDefault();
				var pop = __webpack_require__(14),
					def = pop(lbs_city_info, city_info);
				def.done(function (cityInfo) {
					if (cityInfo.id == city_info.id) {
						return;
					}
					city_info = cityInfo;
					$("#city_name").text(city_info.name);
					me.showLoading();
					me.getList(city_info.id);
				})
	
			})
		},
		showLoading: function () {
			$("#list").empty();
			$("#loading").show();
		},
		bindReload: function () {
			var me = this;
			$(document.body).on("click", "._reload", function (event) {
				$("#list").empty();
				me.showLoading();
				event.preventDefault();
				me.getList(city_info.id);
			})
		}
	};
	module.exports = base;
	


/***/ }),
/* 2 */
/***/ (function(module, exports) {

	// http://tapd.oa.com/tvideo/prong/stories/view/1010031991056992805?url_cache_key=dc4c5bdd3ef3797a13e788c323168a6f&action_entry_type=story_tree_list
	var sessionStorage = window.sessionStorage || {
			getItem: function () {
			}, setItem: function () {
			}, removeItem: function () {
			}
		};
	var base_url = "https://btrace.qq.com/kvcollect?BossId=3243&Pwd=1546101498&plat=1&ua=" + navigator.userAgent + "&_dc=" + Math.random();
	var ref;
	
	
	//播放页来源
	if (location.href.indexOf('app.package.play') != -1) {
		sessionStorage.setItem('piao-ref', ref = 11);
	} else if (location.href.indexOf('app.package.user') != -1 || location.href.indexOf('app.package.channel') != -1) {
		sessionStorage.setItem('piao-ref', ref = 12);
	} else {
		ref = sessionStorage.getItem('piao-ref') || 12;
	}
	base_url += '&ref=' + ref;
	
	var exp = function (event, cid) {
		var g_btrace_BOSS = new Image(1, 1);
		g_btrace_BOSS.src = base_url + '&event=' + event + (cid ? ('&cid=' + cid) : '');
	};
	exp.delegate = function (event) {
		var $ = window.jQuery || window.Zepto;
		exp(event);//pv
		$(document.body).on('click', '[_boss]', function (e) {
			exp($(e.currentTarget).attr('_boss'));
		});
	};
	module.exports = exp;

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

	(function (factory) {
		if (window.angular) {
			//支持以angular服务(service/factory)形式注册使用。
			module.exports.registerNgService = function (ngModule) {
				ngModule.factory('$txvlbs', ['$q', function ($q) {
					return factory(window.QQVideoBridge, $q.defer, __webpack_require__(4)());
				}]);
			}
		} else {
	
			module.exports = factory(window.QQVideoBridge, $.Deferred, __webpack_require__(4)());
		}
	})(function (QQVideoBridge, Deferred, ua) {
	
	
		var def = Deferred(),
			defaultLbs = {
				lng: 900,
				lat: 900,
				_lbsfail: true
			};
		if (!ua.browser.QQvideo) {
			def.resolve(defaultLbs);
			return (typeof def.promise == 'function') ? def.promise() : def.promise;
		}
	
		function getLbsByApp() {
			var timer = setTimeout(function () {
				def.resolve(defaultLbs);
			}, 5000);
			try {
				QQVideoBridge.getLocation(null, function (res) {
					clearTimeout(timer);
					if (res.state == '0') {
						if (res.data) {
							if (res.data.errCode == '0') {
								if (res.data.result) {
	
									// lat,lon,poiName,address
									// error含义
									//其中状态0代表：一次进入用户允许获取
									//状态-1代表：第一次进入用户不允许获取
									//状态-2代表：系统弹出“去设置打开定位服务”
	
									var result = res.data.result,
										pos = {
											lng: result.lon,
											lat: result.lat,
											name: result.poiName
										};
									def.resolve(pos);
									return;
								}
							} else {
								def.resolve(defaultLbs, res.data)
								return;
							}
						}
						def.resolve(defaultLbs);
					} else {
						def.resolve(defaultLbs);
					}
				}).fail(function () {
					def.resolve(defaultLbs);
				});
	
			} catch (e) {
				alert(e);
			} finally {
	
			}
		}
	
		getLbsByApp();
	
		return (typeof def.promise == 'function') ? def.promise() : def.promise;
	});


/***/ }),
/* 4 */
/***/ (function(module, exports) {

	function check(ua) {
		if (!ua) {
			return;
		}
	
		var os = {}, browser = {};
	
		var oscheck = {
			iphone: ua.match(/(iphone)\sos\s([\d_]+)/i),
			ipad: ua.match(/(ipad).*\s([\d_]+)/i),
			ipod: ua.match(/(ipod).*\s([\d_]+)/i),
			android: ua.match(/(android)\s([\d\.]+)/i),
			windows: ua.match(/Windows(\s+\w+)?\s+?(\d+\.\d+)/)
		};
	
		if (oscheck.ipod) {
			os.ios = os.ipod = true;
			os.version = oscheck.ipod[2].replace(/_/g, '.');
			os.name = 'ipod';
		}
		if (oscheck.ipad) {
			os.ios = os.ipad = true;
			os.version = oscheck.ipad[2].replace(/_/g, '.');
			os.name = 'ipad';
		}
		if (oscheck.iphone) {
			os.iphone = os.ios = true;
			os.version = oscheck.iphone[2].replace(/_/g, '.');
			os.name = 'iphone';
		}
		if (oscheck.android) {
			os.android = true;
			os.version = oscheck.android[2];
			os.name = 'android';
		}
		if (oscheck.windows) {
			os.windows = true;
			os.version = oscheck.windows[2];
			os.name = 'windows';
		}
	
		var browsercheck = {
			WeChat: ua.match(/MicroMessenger\/((\d+)\.(\d+))\.(\d+)/) || ua.match(/MicroMessenger\/((\d+)\.(\d+))/),
			MQQClient: (!ua.match(/QQReader/) &&ua.match(/QQ\/(\d+\.\d+)/i) || ua.match(/V1_AND_SQ_([\d\.]+)/)),//QQ阅读伪装成了QQ然而不具备QQ的jsapi
			MQQReader: ua.match(/QQReader/i),
			QQvideo: ua.match(/QQLiveBrowser\/([\d.]+)/),
			TBSSDK: ua.match(/MQQBrowser\/(\d+\.\d+)/i) && ua.match(/MSDK\/(\d+\.\d+)/),
			MQQBrowser: ua.match(/MQQBrowser\/(\d+\.\d+)/i),
			UCBrowser: ua.match(/ucbrowser\/(\d+\.\d+)/i),
			Qzone: ua.match(/Qzone\/[\w\d\_]*(\d\.\d)[\.\w\d\_]*/i),
			Weibo: ua.match(/Weibo/i),
			qqnews: ua.match(/qqnews\/(\d+\.\d+\.\d+)/i),
			QQLiveBroadcast: ua.match(/QQLiveBroadcast/i),
			kuaibao: ua.match(/qnreading\/(\d+\.\d+\.\d+)/i),
			liebao: ua.match(/LieBaoFast\/(\d+\.\d+\.\d+)/i),
			IEMobile: ua.match(/IEMobile(\/|\s+)(\d+\.\d+)/) || ua.match(/WPDesktop/),
			douban: ua.match(/com\.douban\.frodo\/(\d+\.\d+\.\d+)/i),
			MiuiBrowser: ua.match(/MiuiBrowser\/(\d+\.\d+)/i),
			Chrome: os.ios ? ua.match(/CriOS\/(\d+\.\d+)/) : ua.match(/Chrome\/(\d+\.\d+)/),
			Safari: ua.match(/Safari\/(\d+\.\d+)/)
		};
	
		if (browsercheck.MQQReader) {// 非主流的QQ阅读
			browser.MQQReader = true;
			browser.version = 1;
			browser.name = 'MQQReader';
		} else if (browsercheck.IEMobile) {
			browser.IEMobile = true;
			browser.version = 1;
			browser.name = 'IEMobile';
		} else {
			for (var i in browsercheck) {
				if (browsercheck[i]) {
					browser[i] = true;
					browser.version = browsercheck[i][1];
					browser.name = i;
					break;
				}
			}
		}
	
		return {
			browser: browser,
			os: os
		};
	}
	
	var cache = null;
	
	var exportee = function () {
		return cache || (cache = check(navigator.userAgent));
	};
	
	//注入到express或者connect的中间件
	exportee.__express = function (req, res, next) {
		req.ua = check(req.headers['user-agent']);
		next();
	};
	//注入到jquery或zepto
	exportee.__jquery = function ($) {
		$ = $ || window.jQuery || window.Zepto;
		var res = cache || (cache = check(navigator.userAgent));
		$.browser = res.browser;
		$.os = res.os;
	};
	
	exportee.__clearCache = function () {
	    cache = null;
	};
	
	module.exports = exportee;

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, exports, module) {
	    var $pop = document.querySelector('#alert'),
	        $confirm = document.querySelector('#alert_confirm'),
	        $cancel = document.querySelector('#alert_cancel'),
	        $msg = document.querySelector('#alert_msg');
	
	    var def;
	
	    $confirm.addEventListener('click', function() {
	        def && def.resolve();
	        $pop.style.display = "none";
	    });
	    $cancel.addEventListener('click', function() {
	        def && def.reject();
	        $pop.style.display = "none";
	    });
	
	    module.exports = function(msg, confirmTxt, cancelTxt, defer) {
	        def = defer || $.Deferred();
	        $pop.style.display = "block";
	        $msg.innerHTML = msg;
	        $confirm.innerHTML = confirmTxt;
	        $cancel.innerHTML = cancelTxt;
	        return typeof def.promise == 'function' ? def.promise() : def.promise;
	    };
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function(require,exports,module){
	
	    var key = "city";
	
	    module.exports = {
	        /**
	         * 获取城市信息
	         * @returns {{city_id: string, area_id: string}}
	         */
	        get : function(){
	            var value = localStorage.getItem(key);
	            if(typeof value !="string"){
	                return null;
	            }
	            value = value.split(",");
	            return {
	                city_id:value[0],
	                area_id:value[1]
	            }
	        },
	        /**
	         * 存储城市信息
	         * @param city_id
	         * @param area_id
	         */
	        set : function(city_id,area_id){
	            var value = Array.apply(null,arguments);
	            localStorage.setItem(key,value.join(","));
	        },
	        remove : function(){
	            localStorage.removeItem(key);
	        }
	    }
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__))

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

	var getData = __webpack_require__(8);
	
	module.exports = function (param) {
		return getData("wireless_hot_films", param);
	};

/***/ }),
/* 8 */
/***/ (function(module, exports) {

	function getData(cginame, data, def, isretry) {
		$.ajax({
			url: "https://ticketapi.video.qq.com/" + cginame + "?otype=json",
			data: data,
			timeout: 120000,
			dataType: "jsonp"
		}).done(function (res) {
			if (res.retcode == 0) {
				def.resolve(res);
			}
			else {
				if (!isretry) {
					getData(cginame, data, def, true)
				}
				else {
					def.reject(res);
				}
			}
		}).fail(function (res) {
			if (!isretry) {
				getData(cginame, data, def, true)
			}
			else {
				def.reject(res);
			}
		});
	}
	
	/**
	 *
	 * @param data {vuserid:xx,vusession:x,order_id:xx}
	 * @returns {*|Object}
	 */
	module.exports = function (cginame, data) {
		var def = $.Deferred();
		getData(cginame, data, def);
		return def.promise();
	}


/***/ }),
/* 9 */
/***/ (function(module, exports) {

	/*TMODJS:{}*/
	!function () {
		function a(a, b) {
			return (/string|function/.test(typeof b) ? h : g)(a, b)
		}
	
		function b(a, c) {
			return "string" != typeof a && (c = typeof a, "number" === c ? a += "" : a = "function" === c ? b(a.call(a)) : ""), a
		}
	
		function c(a) {
			return l[a]
		}
	
		function d(a) {
			return b(a).replace(/&(?![\w#]+;)|[<>"']/g, c)
		}
	
		function e(a, b) {
			if (m(a))for (var c = 0, d = a.length; d > c; c++)b.call(a, a[c], c, a); else for (c in a)b.call(a, a[c], c)
		}
	
		function f(a, b) {
			var c = /(\/)[^\/]+\1\.\.\1/, d = ("./" + a).replace(/[^\/]+$/, ""), e = d + b;
			for (e = e.replace(/\/\.\//g, "/"); e.match(c);)e = e.replace(c, "/");
			return e
		}
	
		function g(b, c) {
			var d = a.get(b) || i({filename: b, name: "Render Error", message: "Template not found"});
			return c ? d(c) : d
		}
	
		function h(a, b) {
			if ("string" == typeof b) {
				var c = b;
				b = function () {
					return new k(c)
				}
			}
			var d = j[a] = function (c) {
				try {
					return new b(c, a) + ""
				} catch (d) {
					return i(d)()
				}
			};
			return d.prototype = b.prototype = n, d.toString = function () {
				return b + ""
			}, d
		}
	
		function i(a) {
			var b = "{Template Error}", c = a.stack || "";
			if (c)c = c.split("\n").slice(0, 2).join("\n"); else for (var d in a)c += "<" + d + ">\n" + a[d] + "\n\n";
			return function () {
				return "object" == typeof console && console.error(b + "\n\n" + c), b
			}
		}
	
		var j = a.cache = {}, k = this.String, l = {
			"<": "&#60;",
			">": "&#62;",
			'"': "&#34;",
			"'": "&#39;",
			"&": "&#38;"
		}, m = Array.isArray || function (a) {
				return "[object Array]" === {}.toString.call(a)
			}, n = a.utils = {
			$helpers: {}, $include: function (a, b, c) {
				return a = f(c, a), g(a, b)
			}, $string: b, $escape: d, $each: e
		}, o = a.helpers = n.$helpers;
		a.get = function (a) {
			return j[a.replace(/^\.\//, "")]
		}, a.helper = function (a, b) {
			o[a] = b
		}, module.exports = a
	}();

/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

	var template=__webpack_require__(9);
	module.exports=template('tpl/index/item',function($data,$filename
	/*``*/) {
	'use strict';var $utils=this,$helpers=$utils.$helpers,$each=$utils.$each,films=$data.films,film=$data.film,index=$data.index,$escape=$utils.$escape,is_trailer=$data.is_trailer,$out='';$each(films,function(film,index){
	$out+=' <li class="list_item"> <a href="';
	$out+=$escape($helpers. getUrl(film.cid ));
	$out+='" class="figure" tabindex="-1" _hot="ticket.index.play"> <img class="figure_img" alt="';
	$out+=$escape(film.name);
	$out+='" src="';
	$out+=$escape($helpers. https(film.img ));
	$out+='" srcset="';
	$out+=$escape($helpers. https(film.img ));
	$out+='"> </a> <a href="';
	$out+=$escape($helpers. getUrl(film.cid ));
	$out+='" class="figure_info"> <strong class="figure_title"> <span class="title">';
	$out+=$escape(film.name);
	$out+='</span><span class="score">';
	$out+=$escape(film.score);
	$out+='</span> </strong> <div class="figure_txt"> <span class="txt">';
	$out+=$escape(film.sub_title);
	$out+='</span> </div> <div class="figure_time">';
	$out+=$escape($helpers. getDateFormat(film.ondate ));
	$out+='上映</div> </a> ';
	if(!is_trailer){
	$out+=' <a class="btn_buy" href="theater_list.html?film_id=';
	$out+=$escape(film.id);
	$out+='" _hot="ticket.index.buy">购票</a> ';
	}
	$out+=' </li> ';
	});
	$out+=' ';
	return new String($out);
	});

/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

	var template=__webpack_require__(9);
	module.exports=template('tpl/index/empty','<div class="page_container"> <ul class="ticket_list ticket_empty"> <li class="item"> <span class="icon_ticket_empty"></span> <h6 class="title">附近没有影院喔</h6> <p class="notice">试试选择其他区域</p> </li> </ul> </div>');

/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

	var template=__webpack_require__(9);
	module.exports=template('tpl/index/error','<div class="page_container"> <div class="notice_contain"> <div class="notice_wrap"> <i class="icon_notice"></i> <h5 class="title">座位拉取失败</h5> <h6 class="sub">请检查网络连接是否出错</h6> <a href="javascript:;" class="btn_strong">点击重试</a> </div> </div> </div>');

/***/ }),
/* 13 */
/***/ (function(module, exports) {

	/**
	 * exports: function(key, options)
	 * @param prefix       define a prefix of the keys in localStorage
	 * @param options
	 *      maxAge
	 *      limit           item limited in localStorage, defaults to 0(so all item will be saved in sessionStorage)
	 *      useSession      when an item is staled, detemine whether drop it or move it to sessionStorage, defaults to true
	 *      -
	 */
	
	(function(LruStorageFactory, CacheItemFactory, LRUArrayFactory) {
	  // if (window.define && define.cmd) {
	  //   define(function(r, e, module) {
	  //     module.exports =
	  //   });
	  // } else {
	  //   window.LruWebStorage = LruStorageFactory(CacheItemFactory(),
	  //     LRUArrayFactory());
	  // }
	  module.exports = LruStorageFactory(CacheItemFactory(), LRUArrayFactory());
	})(function(CacheItem, LRUArray) {
	  var STORAGE = {
	    local: window.localStorage,
	    session: window.sessionStorage
	  };
	
	  function LruStorage(prefix, options) {
	    this.prefix = prefix;
	    LruStorage.ATTRIBUTES.forEach(function(key) {
	      this[key] = options[key];
	    }, this);
	    this.onStale = options.onStale;
	
	    //keys
	    this.items = LRUArray('storageKey');
	    if (options._items) {
	      options._items.forEach(function(v) {
	        this.items.unshift(new CacheItem(v));
	      }, this);
	    }
	  }
	  LruStorage.ATTRIBUTES = ['maxAge', 'limit', 'useSession'];
	
	  LruStorage.prototype.set = function set(key, val, opt) {
	    var item;
	    //if there is no cacheItem storaged, create one
	    if (!(item = this.items.find(key))) {
	      item = new CacheItem({
	        key: key,
	        maxAge: Date.now() + this.maxAge
	      });
	      this.add(item);
	    }
	    //save value
	    STORAGE[item.level].setItem(this.prefix + '-' + item.storageKey, JSON.stringify(
	      val));
	    this.saveConfig();
	    return this;
	  };
	
	  LruStorage.prototype.get = function get(key, opt) {
	    var item;
	    //check if there is a cacheItem storaged yet
	    if (!(item = this.items.find(key))) return ({}).undefined;
	    if (item.isStale()) {
	      this.remove(this.items.indexOf(key));
	      return null;
	    }
	
	    return JSON.parse(STORAGE[item.level].getItem(this.prefix + '-' + item.storageKey));
	  };
	
	  LruStorage.prototype.remove = function(index) {
	    var item = this.items.arr[index];
	
	    if (typeof this.onStale == 'function') {
	      if (this.onStale(JSON.parse(STORAGE[item.level].getItem(this.prefix +
	          '-' + item.storageKey)), this.useSession)) return;
	    }
	    // console.log(this.useSession, index);
	    if (this.useSession) {
	      if (item.level == 'local') {
	        item.level = 'session';
	        STORAGE.local.removeItem(this.prefix + '-' + item.storageKey);
	        STORAGE.session.setItem(this.prefix + '-' + item.storageKey,
	          STORAGE.local.getItem(this.prefix + '-' + item.storageKey));
	      }
	
	    } else {
	      STORAGE[item.level].removeItem(this.prefix + '-' + item.storageKey);
	      if (index == this.items.length - 1) {
	        this.items.pop();
	      } else {
	        this.items.splice(index, 1);
	      }
	    }
	    return this;
	  };
	
	  LruStorage.prototype.add = function(item) {
	    //remove the last one when items out of limit
	    if (this.items.length >= this.limit && this.items.length > 0) {
	      // console.log(this.items.length, this.limit);
	      for (var i = Math.max(0, this.limit - 1); i < this.items.length; i++) {
	        this.remove(i);
	      }
	    }
	    this.items.unshift(item);
	    return this;
	  };
	
	  LruStorage.prototype.saveConfig = function saveConfig() {
	    var json = {
	      _items: []
	    };
	    //stringify all items and config
	    this.items.forEach(function(v) {
	      var citem = {};
	      CacheItem.ATTRIBUTES.forEach(function(key) {
	        citem[key] = v[key];
	      });
	      json._items.push(citem);
	    }, this);
	    LruStorage.ATTRIBUTES.forEach(function(attr) {
	      json[attr] = this[attr];
	    }, this);
	    STORAGE.local.setItem(this.prefix + '-lruconfig', JSON.stringify(json));
	  };
	
	  return function(prefix, options) {
	    var oldConfig = STORAGE.local.getItem(prefix + '-lruconfig') ? JSON.parse(
	      STORAGE.local.getItem(prefix + '-lruconfig')) : {};
	    options = options || {};
	
	    oldConfig.maxAge = options.maxAge || oldConfig.maxAge || Infinity;
	    oldConfig.limit = options.limit || oldConfig.limit || 0;
	    oldConfig.useSession = ('useSession' in options) ? options.useSession :
	      (('useSession' in oldConfig) ? oldConfig.useSession : true);
	    oldConfig.onStale = options.onStale || null;
	
	    return new LruStorage(prefix, oldConfig);
	  };
	
	
	}, function() {
	
	  function CacheItem(obj) {
	    this.storageKey = obj.storageKey || obj.key || '';
	    this.maxAge = obj.maxAge || 0;
	    this.level = obj.level || 'local';
	
	    if (this.level != 'session' && this.level != 'local') {
	      throw 'there is no webstorage interface named ' + this.level +
	        'Storage';
	    }
	  }
	  CacheItem.ATTRIBUTES = ['storageKey', 'maxAge', 'level'];
	  //create by a json string
	  CacheItem.fromJSON = function parse(str) {
	    var ret = {};
	    try {
	      str = JSON.parse(str);
	
	      CacheItem.ATTRIBUTES.forEach(function(v) {
	        this[v] = str[v];
	      }, ret);
	    } catch (e) {}
	    return ret;
	  };
	
	  //check if out of date
	  CacheItem.prototype.isStale = function isStale() {
	    return Date.now() > this.maxAge;
	  };
	
	  return CacheItem;
	
	}, function() {
	  function LRUArray(idkey) {
	    this.arr = [];
	    this.idkey = typeof idkey == 'function' ? idkey : function(item) {
	      return item[idkey];
	    };
	
	    var self = this;
	    Object.defineProperty(this, 'length', {
	      get: function() {
	        return self.arr.length;
	      },
	      set: function() {
	
	      }
	    });
	  }
	  ['forEach', 'push', 'shift', 'unshift', 'pop', 'every', 'concat', 'splice']
	  .forEach(function(key) {
	    LRUArray.prototype[key] = function() {
	      return this.arr[key].apply(this.arr, arguments);
	    };
	  });
	  LRUArray.prototype.update = function(id) {
	    var index = this.indexOf(id);
	    if (index === -1) return;
	    this.updateByIndex(index);
	  };
	  LRUArray.prototype.updateByIndex = function(index) {
	    if (this.arr.length <= index || index == -1) return;
	    var item = this.arr[index];
	    this.arr.splice(index, 1);
	    this.arr.unshift(item);
	  };
	  LRUArray.prototype.indexOf = function(id) {
	    var ret = -1;
	    //TODO improve the finding algorithm?
	    this.every(function(item, index) {
	      if (this.idkey(item) == id) {
	        ret = index;
	        return false;
	      }
	      return true;
	    }, this);
	    return ret;
	  };
	  LRUArray.prototype.find = function(key, silent) {
	    var index = this.indexOf(key);
	    var item = this.arr[index];
	    if (!silent) {
	      this.updateByIndex(index);
	    }
	    return item;
	  };
	
	  return function(key) {
	    return new LRUArray(key);
	  };
	});


/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function(require, exports, module) {
	
	    var confirmPop = __webpack_require__(5);
	    var cityStorage = __webpack_require__(6);
	
	    var defaultLbsInfo = {
	            name : "深圳",
	            id : "440300"
	        },
	        selectedCity = {//用户选的城市
	            name : "",
	            id : ""
	        };
	     var  def = "";
	
	    var $mod = $("#mod_citys"),
	        $lbs = $mod.find(".__lbs");
	
	    $mod.on("click",".__close",function(event){//x掉浮层
	        event.preventDefault();
	        $mod.hide();
	    }).on("click",".__city",function(event){//选择了城市
	        event.preventDefault();
	        $mod.hide();
	        def.resolve({
	            name : $(this).text(),
	            id :$(this).attr("city-id")
	        });
	    });
	    $lbs.on("click",function(event){//点了定位
	        event.preventDefault();
	        if(defaultLbsInfo.id!=selectedCity.id){//二者不一样，出个提示框
	            confirmPop('系统定位您在' + defaultLbsInfo.name + '，是否切换？', '切换', '取消')
	                .then(function () {
	                    $mod.hide();
	                    cityStorage.remove();
	                    def.resolve(defaultLbsInfo);
	                });
	        }
	        else{
	            $mod.hide();
	            def.resolve(defaultLbsInfo);
	        }
	
	    });
	
	    function setInfo(lbs,userSelect,_def){
	        $.extend(defaultLbsInfo,lbs);
	        $.extend(selectedCity,userSelect);
	        def = _def;
	        $lbs.find("span").text(selectedCity.name || defaultLbsInfo.name);
	    }
	
	    //城市索引
	    $mod[0].querySelector('.filter_anchor').addEventListener('touchmove', onAnchor);
	    $mod[0].querySelector('.filter_anchor').addEventListener('click', onAnchor);
	    function onAnchor(e) {
	        var x = e.touches ? e.touches[0].pageX : e.pageX;
	        var y = e.touches ? e.touches[0].pageY : e.pageY;
	        e.preventDefault();
	
	        var $enter = document.elementFromPoint(x, y);
	        var alpha = $enter.innerHTML == '热' ? 'hot' : $enter.innerHTML;
	        if ($enter.className == 'anchor') {
	            $mod[0].querySelector('.__scroller').scrollTop = document.querySelector('#' + alpha).offsetTop - 49;
	            setTimeout(function () {
	                $mod[0].querySelector('.__scroller').style.opacity = 0.99 + Math.random() / 100;
	            }, 0);
	        }
	    }
	
	    /**
	     * lbs城市信息{name:xxx,id:xxx}
	     * @param lbscityinfo
	     */
	    module.exports = function(lbscityinfo,selectedCity){
	        $mod.show();
	        var _def = $.Deferred();
	        setInfo(lbscityinfo,selectedCity,_def);
	        def.done(function(cityInfo){
	            var store = __webpack_require__(6);
	            store.set(cityInfo.id);
	        });
	        return def.promise();
	    };
	
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ })
/******/ ]);