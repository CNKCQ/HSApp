/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	var userDef = QQVideoBridge.getCookie({type:["tv"]}),
	    getList = __webpack_require__(22),
	    hotFilm = __webpack_require__(7);
	
	
	var template = __webpack_require__(9);
	template.helper('getText', function (status, code) {
	    switch (status) {
	        case 1://待支付
	            return "继续支付";
	        case 2://支付成功
	            return "等待出票";
	        case 3://出票成功
	
	            return "查看兑换码";//code ? (code) : "已出票";
	        case 4://出票失败
	            return "出票失败";
	        case 5://订单取消
	            return "订单取消";
	        default :
	            return "";
	    }
	});
	template.helper("https", function (url) {
	    return url.replace ? url.replace('http', 'https') : url;
	});
	
	function loadTicket(){
	    loadHot();
	    $("#loading").show();
	    userDef.done(function(res){
	        console.log(res);
	        if(res.state==0){
	            var tvcookie = res.data.result.tv,
	                reg = /vuserid=(\d+)\;vusession=(\w+)\;/;
	            reg.test(tvcookie);
	            var data = {
	                vuserid: RegExp.$1,
	                vusession :RegExp.$2
	            },listDef;
	
	            if(!data.vuserid || !data.vusession){
	                openLogin();
	                return;
	            }
	            listDef = getList(data).done(function(json){
	                if(json && json.order_list){
	                    var tpl = __webpack_require__(23);
	                    $("#ticket_list").html(tpl(json));
	                }
	                else{
	                    $("#empty").show();
	                    $("#ticket_list").hide();
	                }
	                $("#log").html("data from cgi:"+JSON.stringify(json));
	            }).fail(function(err){
	                if(err && err.retcode == -11){
	                    openLogin();
	                    return;
	                }
	                var error = __webpack_require__(24),
	                    msg = err&&err.errmsg?err.errmsg:"请检查网络连接是否出错",
	                    code = err&&err.retcode ? "错误码："+err.retcode:"错误码：233",
	                    def = error("我的电影票拉取失败了","点击重试",[msg,code].join(","));
	                def.done(loadTicket);
	            }).always(function(){
	                $("#loading").hide();
	            });
	
	        }
	        else{
	            console.log("js bridge is not available");
	        }
	    }).fail(function(){
	        alert("get user info failed");
	    });
	}
	
	var $hotlist = $('#hotlist');
	function loadHot() {
	    hotFilm().done(function(ret) {
	        var tpl = __webpack_require__(25);
	        ret.films.every(function(v, i) {
	            $hotlist.append(tpl(v));
	            return i < 5;
	        });
	    });
	}
	
	function openLogin(){
	    QQVideoBridge.loginTv().done(function(){
	        location.reload();
	    });
	}
	QQVideoBridge.setMoreInfo({"hasRefresh":true, "hasShare":false, "hasFollow":false});
	loadTicket();


/***/ }),
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

	var getData = __webpack_require__(8);
	
	module.exports = function (param) {
		return getData("wireless_hot_films", param);
	};

/***/ }),
/* 8 */
/***/ (function(module, exports) {

	function getData(cginame, data, def, isretry) {
		$.ajax({
			url: "https://ticketapi.video.qq.com/" + cginame + "?otype=json",
			data: data,
			timeout: 120000,
			dataType: "jsonp"
		}).done(function (res) {
			if (res.retcode == 0) {
				def.resolve(res);
			}
			else {
				if (!isretry) {
					getData(cginame, data, def, true)
				}
				else {
					def.reject(res);
				}
			}
		}).fail(function (res) {
			if (!isretry) {
				getData(cginame, data, def, true)
			}
			else {
				def.reject(res);
			}
		});
	}
	
	/**
	 *
	 * @param data {vuserid:xx,vusession:x,order_id:xx}
	 * @returns {*|Object}
	 */
	module.exports = function (cginame, data) {
		var def = $.Deferred();
		getData(cginame, data, def);
		return def.promise();
	}


/***/ }),
/* 9 */
/***/ (function(module, exports) {

	/*TMODJS:{}*/
	!function () {
		function a(a, b) {
			return (/string|function/.test(typeof b) ? h : g)(a, b)
		}
	
		function b(a, c) {
			return "string" != typeof a && (c = typeof a, "number" === c ? a += "" : a = "function" === c ? b(a.call(a)) : ""), a
		}
	
		function c(a) {
			return l[a]
		}
	
		function d(a) {
			return b(a).replace(/&(?![\w#]+;)|[<>"']/g, c)
		}
	
		function e(a, b) {
			if (m(a))for (var c = 0, d = a.length; d > c; c++)b.call(a, a[c], c, a); else for (c in a)b.call(a, a[c], c)
		}
	
		function f(a, b) {
			var c = /(\/)[^\/]+\1\.\.\1/, d = ("./" + a).replace(/[^\/]+$/, ""), e = d + b;
			for (e = e.replace(/\/\.\//g, "/"); e.match(c);)e = e.replace(c, "/");
			return e
		}
	
		function g(b, c) {
			var d = a.get(b) || i({filename: b, name: "Render Error", message: "Template not found"});
			return c ? d(c) : d
		}
	
		function h(a, b) {
			if ("string" == typeof b) {
				var c = b;
				b = function () {
					return new k(c)
				}
			}
			var d = j[a] = function (c) {
				try {
					return new b(c, a) + ""
				} catch (d) {
					return i(d)()
				}
			};
			return d.prototype = b.prototype = n, d.toString = function () {
				return b + ""
			}, d
		}
	
		function i(a) {
			var b = "{Template Error}", c = a.stack || "";
			if (c)c = c.split("\n").slice(0, 2).join("\n"); else for (var d in a)c += "<" + d + ">\n" + a[d] + "\n\n";
			return function () {
				return "object" == typeof console && console.error(b + "\n\n" + c), b
			}
		}
	
		var j = a.cache = {}, k = this.String, l = {
			"<": "&#60;",
			">": "&#62;",
			'"': "&#34;",
			"'": "&#39;",
			"&": "&#38;"
		}, m = Array.isArray || function (a) {
				return "[object Array]" === {}.toString.call(a)
			}, n = a.utils = {
			$helpers: {}, $include: function (a, b, c) {
				return a = f(c, a), g(a, b)
			}, $string: b, $escape: d, $each: e
		}, o = a.helpers = n.$helpers;
		a.get = function (a) {
			return j[a.replace(/^\.\//, "")]
		}, a.helper = function (a, b) {
			o[a] = b
		}, module.exports = a
	}();

/***/ }),
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */,
/* 14 */,
/* 15 */,
/* 16 */,
/* 17 */,
/* 18 */,
/* 19 */,
/* 20 */,
/* 21 */,
/* 22 */
/***/ (function(module, exports) {

	
	    function getData(data,def,isretry){
	        $.ajax({
	            url: "https://ticketapi.video.qq.com/wireless_my_tickets?otype=json",
	            data : data,
	            timeout:60000,
	            dataType: "jsonp"
	        }).done(function(res) {
	            if (res.retcode == 0) {
	                def.resolve(res);
	            }
	            else{
	                if(!isretry){
	                    getData(data,def,true)
	                }
	                else{
	                    def.reject(res);
	                }
	            }
	        }).fail(function(res) {
	            if(!isretry){
	                getData(data,def,true)
	            }
	            else{
	                def.reject(res);
	            }
	        });
	    }
	
	    module.exports = function(data){
	        var def = $.Deferred();
	        getData(data,def);
	        return def.promise();
	    }


/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

	var template=__webpack_require__(9);
	module.exports=template('tpl/myticket/list',function($data,$filename
	/*``*/) {
	'use strict';var $utils=this,$helpers=$utils.$helpers,$each=$utils.$each,order_list=$data.order_list,ticket=$data.ticket,index=$data.index,$escape=$utils.$escape,$out='';$each(order_list,function(ticket,index){
	$out+='<li class="item';
	if(ticket.order_status!=2 && ticket.order_status!=3){
	$out+=' item_unpass';
	}
	$out+='"> <div class="figure_ticket"> <a href="javascript:;" class="figure"><img alt="" src="';
	$out+=$escape($helpers. https(ticket.film_poster ));
	$out+='" /></a> <h5 class="title"><a href="javascript:;">';
	$out+=$escape(ticket.film_name);
	$out+='</a></h5> <p class="txt">';
	$out+=$escape(ticket.theater_name);
	$out+=' ';
	$out+=$escape(ticket.film_date.substr(5));
	$out+=' ';
	$out+=$escape(ticket.film_time);
	$out+='</p> <p class="txt">';
	$out+=$escape(ticket.theater_addr);
	$out+='</p> <p class="txt">接收兑换码手机号：';
	$out+=$escape(ticket.recv_phone);
	$out+='</p> </div> <div class="item_btm"> <a href="';
	if(ticket.order_status==1){
	$out+='pay.html';
	}else{
	$out+='result.html';
	}
	$out+='?order_id=';
	$out+=$escape(ticket.order_id);
	$out+='" class="btn_normal">';
	$out+=$escape($helpers. getText(ticket.order_status , ticket.order_exchangecode));
	$out+='</a> </div> </li>';
	});
	$out+=' ';
	return new String($out);
	});

/***/ }),
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function (require, e, module) {
	    var qs = function() {return document.querySelector.apply(document, arguments)};
	
	    var $error = qs('#error'),
	        $errorMsg = qs('#error_msg'),
	        $subTit = qs('#error_subtit'),
	        $retry = qs('#retry');
	
	    var defer;
	
	    var listener = function() {
	        defer.resolve();
	        $retry.removeEventListener('click', listener);
	        $error.style.display = 'none';
	    };
	
	    module.exports = function(msg, btnTxt, subTit, def) {
	        defer = def || $.Deferred();
	        $errorMsg.textContent = msg;
	        $retry.textContent = btnTxt;
	        subTit && ($subTit.textContent = subTit);
	        $error.style.display = 'block';
	        $retry.addEventListener('click', listener);
	        return typeof defer.promise == 'function' ? defer.promise() : defer.promise;
	    };
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

	var template=__webpack_require__(9);
	module.exports=template('tpl/myticket/hotlist',function($data,$filename
	/*``*/) {
	'use strict';var $utils=this,$helpers=$utils.$helpers,$escape=$utils.$escape,id=$data.id,poster=$data.poster,name=$data.name,score=$data.score,$out='';$out+='<li class="item"> <a href="./theater_list.html?film_id=';
	$out+=$escape(id);
	$out+='" class="figure"> <span class="figure_pic"> <img src="';
	$out+=$escape($helpers. https(poster ));
	$out+='" alt="';
	$out+=$escape(name);
	$out+='"> <span class="mark_ticket"><em class="mark_inner">购票</em></span> <span class="mask_scroe_single"><span class="mask_scroe">';
	$out+=$escape(score);
	$out+='</span></span> </span> <span class="figure_title figure_title_multirow">';
	$out+=$escape(name);
	$out+='</span> </a> </li> ';
	return new String($out);
	});

/***/ })
/******/ ]);