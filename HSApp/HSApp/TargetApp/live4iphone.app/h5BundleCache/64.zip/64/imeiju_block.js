// 场景： 浏览器可行，app 不确定
// 功能： 屏蔽 imeiju 播放器上方广告
(function() {
    'use strict';

    try {
        // 依赖浏览器创建 dom
        
        // app 弹窗，暂时未使用下方 id 或者 href 匹配方式
        var ad_nod = document.getElementById('gong')
        if (ad_nod) {
            ad_nod.hidden = true
        }

        // imeiju页面id不唯一，尽量少使用getElementById
        // 尝试屏蔽渲染之后的窗口
        var links = document.getElementsByTagName('a')
        for (var i = 0; i < links.length; i++) {
            var current_id = links[i].id
            if (current_id) {
                // qphf 日赚500
                // byhf 马云都佩服的微信赚钱秘籍
                // hghf 广告招租
                if ('qphf' == current_id
                    || 'byhf' == current_id
                    || 'hghf' == current_id) {
                    links[i].hidden = true
                }
            }
            else {
                var current_href = links[i].href
                // url 含义见具体网站内容
                if ('https://www.imeiju.cc/api/hezuo.html' == current_href
                    || 'http://www.520weicai.com/tg1/' == current_href ) {
                    links[i].hidden = true;
                }
            }
        }
    }
    catch(error) {
        // TODO 告警
    }
})();
