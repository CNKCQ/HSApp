// 功能： 屏蔽 pptv 播放器上方广告
// 注释：尝试过几种方法效果都不行，怀疑动态加载有延迟, 最终屏蔽整个模块
//       1. 更加广告11位长的id；2. 根据连接的href匹配
(function() {
    'use strict';

    try {
		var wraps = document.getElementsByClassName('main-wrap')
        if (1 == wraps.length) {
            var divs = wraps[0].getElementsByTagName('div')
            // 这里使用屏蔽整个模块的方法
            if (2 < divs.length) {
                divs[1].hidden = true
            }
        }
    }
    catch(error) {
        // TODO 告警
    }
})();
