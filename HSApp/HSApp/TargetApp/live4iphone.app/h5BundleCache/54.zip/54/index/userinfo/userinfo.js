/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./54/index/userinfo/userinfo.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./54/index/userinfo/userinfo.js":
/*!***************************************!*\
  !*** ./54/index/userinfo/userinfo.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nvar _stringify = __webpack_require__(/*! babel-runtime/core-js/json/stringify */ \"./node_modules/babel-runtime/core-js/json/stringify.js\");\n\nvar _stringify2 = _interopRequireDefault(_stringify);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nvar userinfoEvent = {\n    onSignInTap: function onSignInTap(params) {\n        console.log(\"onSignlayoutTap ===\");\n\n        if (QLVN.Login.isLogined()) {\n            UserCenter.onSignInTap(null);\n        } else {\n            QLVN.Login.doLogin();\n        }\n    },\n\n    onAvatarLayoutTap: function onAvatarLayoutTap(params) {\n        console.log(\"onUSerInfo Tap \");\n        UserCenter.onAvatarLayoutTap(null);\n    },\n    onTextAnimationEnd: function onTextAnimationEnd() {\n        console.log(\"onTextAnimationEnd  \");\n        UserCenter.onTextAnimationEnd();\n    },\n    startSignInLoading: function startSignInLoading() {\n        console.log(\"startProgress  \");\n        var progressbar = vn.dom.getElementById(\"progressbar\");\n        var signin_label = vn.dom.getElementById(\"signin_label\");\n        var signin_icon = vn.dom.getElementById('signin_icon');\n        if (signin_label != null) {\n            signin_label.setProperty(\"alpha\", 0);\n        }\n        if (signin_icon != null) {\n            signin_icon.setProperty(\"alpha\", 0);\n        }\n        if (progressbar != null) {\n            progressbar.setProperty(\"hidden\", false);\n            progressbar.startAnimation({\n                \"rotation\": 360,\n                \"pivot_x\": \"50%\",\n                \"pivot_y\": \"50%\",\n                repeat_count: 20,\n                \"duration\": 1000,\n                complete: function complete() {\n                    console.log(\"progress Bar Animation end \");\n                }\n            });\n        }\n    },\n    stopSignInLoading: function stopSignInLoading() {\n        console.log(\"stopProgress   \");\n        var progressbar = vn.dom.getElementById(\"progressbar\");\n        var signin_label = vn.dom.getElementById(\"signin_label\");\n        var signin_icon = vn.dom.getElementById('signin_icon');\n        if (signin_label != null) {\n            signin_label.setProperty(\"alpha\", 1);\n        }\n        if (signin_icon != null) {\n            signin_icon.setProperty(\"alpha\", 1);\n        }\n        if (progressbar != null) {\n            progressbar.setProperty(\"hidden\", true);\n            progressbar.stopAnimation();\n        }\n    },\n    startTextAnimation: function startTextAnimation() {\n        console.log(\"sstartTextAnimation \");\n        userinfoEvent.stopSignInLoading();\n        var resetanimation = function resetanimation(dom) {\n            dom.setScaleX(1);\n            dom.setTranslationX(0);\n        };\n        var signinLyaout = vn.dom.getElementById(\"signin_layout\");\n        console.log(\"signinLyaout \" + signinLyaout);\n        signinLyaout.stopAnimation();\n        var animationRollBack = {\n            \"scale_x\": 1,\n            \"duration\": 300,\n            \"translate_x\": \"0%\",\n            \"complete\": function complete() {\n                resetanimation(signinLyaout);\n            }\n        };\n        var scaleXAnimation = {\n            \"scale_x\": 0,\n            \"duration\": 600,\n            \"translate_x\": \"-50%\",\n            \"complete\": function complete() {\n                userinfoEvent.onTextAnimationEnd();\n                signinLyaout.startAnimation(animationRollBack);\n            }\n        };\n        signinLyaout.startAnimation(scaleXAnimation);\n    },\n\n    onDokiTap: function onDokiTap(params) {\n        // var actionpath = \"userInfo.dokiIcons[\" + params.dataset.index + \"].action\"\n        console.log('onDokiTap ' + (0, _stringify2.default)(params.dataset));\n        var action = params.dataset.action;\n        QLVN.doAction(action);\n    },\n\n    onSearchTap: function onSearchTap(params) {\n        // var actionpath = \"userInfo.dokiIcons[\" + params.dataset.index + \"].action\"\n        console.log('onSearchTap new');\n\n        var action = new Array();\n        action[\"url\"] = 'txvideo://v.qq.com/SearchPagerActivity';\n        action[\"reportKey\"] = 'userCenter_search_entry';\n        QLVN.doAction(action);\n\n        QLVN.reportEvents('user_center_action_click', [{ \"reportkey\": \"userCenter_search_entry\" }]);\n    }\n};\nexports.userinfoEvent = userinfoEvent;\n\n//# sourceURL=webpack:///./54/index/userinfo/userinfo.js?");

/***/ }),

/***/ "./node_modules/babel-runtime/core-js/json/stringify.js":
/*!**************************************************************!*\
  !*** ./node_modules/babel-runtime/core-js/json/stringify.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("module.exports = { \"default\": __webpack_require__(/*! core-js/library/fn/json/stringify */ \"./node_modules/core-js/library/fn/json/stringify.js\"), __esModule: true };\n\n//# sourceURL=webpack:///./node_modules/babel-runtime/core-js/json/stringify.js?");

/***/ }),

/***/ "./node_modules/core-js/library/fn/json/stringify.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/library/fn/json/stringify.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("var core = __webpack_require__(/*! ../../modules/_core */ \"./node_modules/core-js/library/modules/_core.js\");\nvar $JSON = core.JSON || (core.JSON = { stringify: JSON.stringify });\nmodule.exports = function stringify(it) { // eslint-disable-line no-unused-vars\n  return $JSON.stringify.apply($JSON, arguments);\n};\n\n\n//# sourceURL=webpack:///./node_modules/core-js/library/fn/json/stringify.js?");

/***/ }),

/***/ "./node_modules/core-js/library/modules/_core.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/library/modules/_core.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("var core = module.exports = { version: '2.6.9' };\nif (typeof __e == 'number') __e = core; // eslint-disable-line no-undef\n\n\n//# sourceURL=webpack:///./node_modules/core-js/library/modules/_core.js?");

/***/ })

/******/ });